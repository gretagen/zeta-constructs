/*
 * SPDX-FileCopyrightText: 2001, Critical Path
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

/**
 * @file    icalparameter_cxx.hpp
 * @author  fnguyen (12/10/01)
 * @brief   Definition of C++ Wrapper for icalparameter.c
 */

#ifndef ICALPARAMETER_CXX_H
#define ICALPARAMETER_CXX_H

#include "libical_ical_export.h"
#include "icptrholder_cxx.hpp"

extern "C" {
#include "icalparameter.h"
}

#include <string>
#include <vector>

namespace LibICal
{

/**
 * Class representing an icalparameter
 */
class LIBICAL_ICAL_EXPORT ICalParameter
{
public:
    /**
     * Construct an invalid ICalParameter.
     */
    ICalParameter();

    /**
     * Construct from another ICalParameter.
     */
    ICalParameter(const ICalParameter &);

    /**
     * Assignment operator.
     * @return a new ICalParameter cloned from the specified ICalParameter
     */
    ICalParameter &operator=(const ICalParameter &);

    /**
     * Destructor.
     */
    ~ICalParameter();

    explicit ICalParameter(icalparameter *v);

    // Create from string of form "PARAMNAME=VALUE"
    explicit ICalParameter(const std::string &str);

    // Create from just the value, the part after the "="
    explicit ICalParameter(const icalparameter_kind &kind);
    ICalParameter(const icalparameter_kind &kind, const std::string &str);

    operator icalparameter *()
    {
        return imp;
    }

    void detach();

    std::string as_ical_string();
    bool is_valid();
    icalparameter_kind isa();
    bool isa_parameter(void *param);

    /* Access the name of an X parameter */
    static void set_xname(ICalParameter &param, const std::string &v);
    static std::string get_xname(ICalParameter &param);
    static void set_xvalue(ICalParameter &param, const std::string &v);
    static std::string get_xvalue(ICalParameter &param);

    /* Convert enumerations */
    static std::string kind_to_string(const icalparameter_kind &kind);
    static icalparameter_kind string_to_kind(const std::string &str);

    /* DELEGATED-FROM */
    std::vector<std::string> get_delegatedfrom() const;
    void set_delegatedfrom(const std::vector<std::string> &v);

    /* RELATED */
    icalparameter_related get_related() const;
    void set_related(const icalparameter_related &v);

    /* SENT-BY */
    std::string get_sentby() const;
    void set_sentby(const std::string &v);

    /* LANGUAGE */
    std::string get_language() const;
    void set_language(const std::string &v);

    /* RELTYPE */
    icalparameter_reltype get_reltype() const;
    void set_reltype(const icalparameter_reltype &v);

    /* ENCODING */
    icalparameter_encoding get_encoding() const;
    void set_encoding(const icalparameter_encoding &v);

    /* ALTREP */
    std::string get_altrep() const;
    void set_altrep(const std::string &v);

    /* FMTTYPE */
    std::string get_fmttype() const;
    void set_fmttype(const std::string &v);

    /* FBTYPE */
    icalparameter_fbtype get_fbtype() const;
    void set_fbtype(const icalparameter_fbtype &v);

    /* RSVP */
    icalparameter_rsvp get_rsvp() const;
    void set_rsvp(const icalparameter_rsvp &v);

    /* RANGE */
    icalparameter_range get_range() const;
    void set_range(const icalparameter_range &v);

    /* DELEGATED-TO */
    std::vector<std::string> get_delegatedto() const;
    void set_delegatedto(const std::vector<std::string> &v);

    /* CN */
    std::string get_cn() const;
    void set_cn(const std::string &v);

    /* ROLE */
    icalparameter_role get_role() const;
    void set_role(const icalparameter_role &v);

    /* X-LIC-COMPARETYPE */
    icalparameter_xliccomparetype get_xliccomparetype() const;
    void set_xliccomparetype(const icalparameter_xliccomparetype &v);

    /* PARTSTAT */
    icalparameter_partstat get_partstat() const;
    void set_partstat(const icalparameter_partstat &v);

    /* X-LIC-ERRORTYPE */
    icalparameter_xlicerrortype get_xlicerrortype() const;
    void set_xlicerrortype(const icalparameter_xlicerrortype &v);

    /* MEMBER */
    std::vector<std::string> get_member() const;
    void set_member(const std::vector<std::string> &v);

    /* X */
    std::string get_x() const;
    void set_x(const std::string &v);

    /* CUTYPE */
    icalparameter_cutype get_cutype() const;
    void set_cutype(const icalparameter_cutype &v);

    /* TZID */
    std::string get_tzid() const;
    void set_tzid(const std::string &v);

    /* VALUE */
    icalparameter_value get_value() const;
    void set_value(const icalparameter_value &v);

    /* DIR */
    std::string get_dir() const;
    void set_dir(const std::string &v);

private:
    icalparameter *imp;
};

} // namespace LibICal

#endif
