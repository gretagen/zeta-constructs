#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ical" for configuration "Release"
set_property(TARGET ical APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ical PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libical.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libical.so.4.0"
  )

list(APPEND _cmake_import_check_targets ical )
list(APPEND _cmake_import_check_files_for_ical "${_IMPORT_PREFIX}/lib/libical.so.4.0.7" )

# Import target "ical_cxx" for configuration "Release"
set_property(TARGET ical_cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ical_cxx PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libical_cxx.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libical_cxx.so.4.0"
  )

list(APPEND _cmake_import_check_targets ical_cxx )
list(APPEND _cmake_import_check_files_for_ical_cxx "${_IMPORT_PREFIX}/lib/libical_cxx.so.4.0.7" )

# Import target "icalss" for configuration "Release"
set_property(TARGET icalss APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalss PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libicalss.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libicalss.so.4.0"
  )

list(APPEND _cmake_import_check_targets icalss )
list(APPEND _cmake_import_check_files_for_icalss "${_IMPORT_PREFIX}/lib/libicalss.so.4.0.7" )

# Import target "icalss_cxx" for configuration "Release"
set_property(TARGET icalss_cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalss_cxx PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libicalss_cxx.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libicalss_cxx.so.4.0"
  )

list(APPEND _cmake_import_check_targets icalss_cxx )
list(APPEND _cmake_import_check_files_for_icalss_cxx "${_IMPORT_PREFIX}/lib/libicalss_cxx.so.4.0.7" )

# Import target "icalvcal" for configuration "Release"
set_property(TARGET icalvcal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalvcal PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libicalvcal.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libicalvcal.so.4.0"
  )

list(APPEND _cmake_import_check_targets icalvcal )
list(APPEND _cmake_import_check_files_for_icalvcal "${_IMPORT_PREFIX}/lib/libicalvcal.so.4.0.7" )

# Import target "ical-glib" for configuration "Release"
set_property(TARGET ical-glib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ical-glib PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "ical;icalvcard"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libical-glib.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libical-glib.so.4.0"
  )

list(APPEND _cmake_import_check_targets ical-glib )
list(APPEND _cmake_import_check_files_for_ical-glib "${_IMPORT_PREFIX}/lib/libical-glib.so.4.0.7" )

# Import target "icalvcard" for configuration "Release"
set_property(TARGET icalvcard APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalvcard PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libicalvcard.so.4.0.7"
  IMPORTED_SONAME_RELEASE "libicalvcard.so.4.0"
  )

list(APPEND _cmake_import_check_targets icalvcard )
list(APPEND _cmake_import_check_files_for_icalvcard "${_IMPORT_PREFIX}/lib/libicalvcard.so.4.0.7" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
