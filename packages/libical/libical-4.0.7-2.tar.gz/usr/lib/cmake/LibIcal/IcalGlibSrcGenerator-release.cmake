#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "native-ical-glib-src-generator" for configuration "Release"
set_property(TARGET native-ical-glib-src-generator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(native-ical-glib-src-generator PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/libexec/libical/ical-glib-src-generator"
  )

list(APPEND _cmake_import_check_targets native-ical-glib-src-generator )
list(APPEND _cmake_import_check_files_for_native-ical-glib-src-generator "${_IMPORT_PREFIX}/libexec/libical/ical-glib-src-generator" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
