/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_PROP_ITER_H
#define I_CAL_PROP_ITER_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_TYPE_PROP_ITER \
    (i_cal_prop_iter_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalPropIter, i_cal_prop_iter, I_CAL, PROP_ITER, ICalObject)

/**
 * ICalPropIter:
 *
 * This is the ICalPropIter instance.
 */

/**
 * ICalPropIterClass:
 *
 * This is the ICalPropIter class.
 */
struct _ICalPropIterClass {
    /*< private >*/
    ICalObjectClass parent;
};

G_END_DECLS

#endif /* I_CAL_PROP_ITER_H */

//NOLINTEND
