/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_DERIVED_PROPERTY_H
#define I_CAL_VCARD_DERIVED_PROPERTY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>
#include <libical-glib/i-cal-vcard-derived-value.h>

G_BEGIN_DECLS

typedef enum {
	I_CAL_VCARD_ANY_PROPERTY = VCARD_ANY_PROPERTY,
	I_CAL_VCARD_ADR_PROPERTY = VCARD_ADR_PROPERTY,
	I_CAL_VCARD_AGENT_PROPERTY = VCARD_AGENT_PROPERTY,
	I_CAL_VCARD_ANNIVERSARY_PROPERTY = VCARD_ANNIVERSARY_PROPERTY,
	I_CAL_VCARD_BDAY_PROPERTY = VCARD_BDAY_PROPERTY,
	I_CAL_VCARD_BEGIN_PROPERTY = VCARD_BEGIN_PROPERTY,
	I_CAL_VCARD_BIRTHPLACE_PROPERTY = VCARD_BIRTHPLACE_PROPERTY,
	I_CAL_VCARD_CALADRURI_PROPERTY = VCARD_CALADRURI_PROPERTY,
	I_CAL_VCARD_CALURI_PROPERTY = VCARD_CALURI_PROPERTY,
	I_CAL_VCARD_CATEGORIES_PROPERTY = VCARD_CATEGORIES_PROPERTY,
	I_CAL_VCARD_CLASS_PROPERTY = VCARD_CLASS_PROPERTY,
	I_CAL_VCARD_CLIENTPIDMAP_PROPERTY = VCARD_CLIENTPIDMAP_PROPERTY,
	I_CAL_VCARD_CONTACTURI_PROPERTY = VCARD_CONTACTURI_PROPERTY,
	I_CAL_VCARD_CREATED_PROPERTY = VCARD_CREATED_PROPERTY,
	I_CAL_VCARD_DEATHDATE_PROPERTY = VCARD_DEATHDATE_PROPERTY,
	I_CAL_VCARD_DEATHPLACE_PROPERTY = VCARD_DEATHPLACE_PROPERTY,
	I_CAL_VCARD_EMAIL_PROPERTY = VCARD_EMAIL_PROPERTY,
	I_CAL_VCARD_END_PROPERTY = VCARD_END_PROPERTY,
	I_CAL_VCARD_EXPERTISE_PROPERTY = VCARD_EXPERTISE_PROPERTY,
	I_CAL_VCARD_FBURL_PROPERTY = VCARD_FBURL_PROPERTY,
	I_CAL_VCARD_FN_PROPERTY = VCARD_FN_PROPERTY,
	I_CAL_VCARD_GENDER_PROPERTY = VCARD_GENDER_PROPERTY,
	I_CAL_VCARD_GEO_PROPERTY = VCARD_GEO_PROPERTY,
	I_CAL_VCARD_GRAMGENDER_PROPERTY = VCARD_GRAMGENDER_PROPERTY,
	I_CAL_VCARD_HOBBY_PROPERTY = VCARD_HOBBY_PROPERTY,
	I_CAL_VCARD_IMPP_PROPERTY = VCARD_IMPP_PROPERTY,
	I_CAL_VCARD_INTEREST_PROPERTY = VCARD_INTEREST_PROPERTY,
	I_CAL_VCARD_JSPROP_PROPERTY = VCARD_JSPROP_PROPERTY,
	I_CAL_VCARD_KEY_PROPERTY = VCARD_KEY_PROPERTY,
	I_CAL_VCARD_KIND_PROPERTY = VCARD_KIND_PROPERTY,
	I_CAL_VCARD_LABEL_PROPERTY = VCARD_LABEL_PROPERTY,
	I_CAL_VCARD_LANG_PROPERTY = VCARD_LANG_PROPERTY,
	I_CAL_VCARD_LANGUAGE_PROPERTY = VCARD_LANGUAGE_PROPERTY,
	I_CAL_VCARD_LOGO_PROPERTY = VCARD_LOGO_PROPERTY,
	I_CAL_VCARD_MAILER_PROPERTY = VCARD_MAILER_PROPERTY,
	I_CAL_VCARD_MEMBER_PROPERTY = VCARD_MEMBER_PROPERTY,
	I_CAL_VCARD_N_PROPERTY = VCARD_N_PROPERTY,
	I_CAL_VCARD_NAME_PROPERTY = VCARD_NAME_PROPERTY,
	I_CAL_VCARD_NICKNAME_PROPERTY = VCARD_NICKNAME_PROPERTY,
	I_CAL_VCARD_NOTE_PROPERTY = VCARD_NOTE_PROPERTY,
	I_CAL_VCARD_ORG_PROPERTY = VCARD_ORG_PROPERTY,
	I_CAL_VCARD_ORGDIRECTORY_PROPERTY = VCARD_ORGDIRECTORY_PROPERTY,
	I_CAL_VCARD_PHOTO_PROPERTY = VCARD_PHOTO_PROPERTY,
	I_CAL_VCARD_PRODID_PROPERTY = VCARD_PRODID_PROPERTY,
	I_CAL_VCARD_PRONOUNS_PROPERTY = VCARD_PRONOUNS_PROPERTY,
	I_CAL_VCARD_RELATED_PROPERTY = VCARD_RELATED_PROPERTY,
	I_CAL_VCARD_REV_PROPERTY = VCARD_REV_PROPERTY,
	I_CAL_VCARD_ROLE_PROPERTY = VCARD_ROLE_PROPERTY,
	I_CAL_VCARD_SOCIALPROFILE_PROPERTY = VCARD_SOCIALPROFILE_PROPERTY,
	I_CAL_VCARD_SORTSTRING_PROPERTY = VCARD_SORTSTRING_PROPERTY,
	I_CAL_VCARD_SOUND_PROPERTY = VCARD_SOUND_PROPERTY,
	I_CAL_VCARD_SOURCE_PROPERTY = VCARD_SOURCE_PROPERTY,
	I_CAL_VCARD_TEL_PROPERTY = VCARD_TEL_PROPERTY,
	I_CAL_VCARD_TITLE_PROPERTY = VCARD_TITLE_PROPERTY,
	I_CAL_VCARD_TZ_PROPERTY = VCARD_TZ_PROPERTY,
	I_CAL_VCARD_UID_PROPERTY = VCARD_UID_PROPERTY,
	I_CAL_VCARD_URL_PROPERTY = VCARD_URL_PROPERTY,
	I_CAL_VCARD_VERSION_PROPERTY = VCARD_VERSION_PROPERTY,
	I_CAL_VCARD_X_PROPERTY = VCARD_X_PROPERTY,
	I_CAL_VCARD_XLICERROR_PROPERTY = VCARD_XLICERROR_PROPERTY,
	I_CAL_VCARD_XML_PROPERTY = VCARD_XML_PROPERTY,
	I_CAL_VCARD_NO_PROPERTY = VCARD_NO_PROPERTY
} ICalVcardPropertyKind;


LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_adr	(const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_property_get_adr	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_adr	(ICalVcardProperty *self,
						 const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_agent	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_agent	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_agent	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_anniversary
						(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_property_get_anniversary
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_anniversary
						(ICalVcardProperty *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_bday	(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_property_get_bday	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_bday	(ICalVcardProperty *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_birthplace
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_birthplace
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_birthplace
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_caladruri
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_caladruri
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_caladruri
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_caluri	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_caluri	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_caluri	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_categories
						(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_property_get_categories
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_categories
						(ICalVcardProperty *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_class	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_class	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_class	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_clientpidmap
						(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_property_get_clientpidmap
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_clientpidmap
						(ICalVcardProperty *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_contacturi
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_contacturi
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_contacturi
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_created
						(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_property_get_created
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_created
						(ICalVcardProperty *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_deathdate
						(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_property_get_deathdate
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_deathdate
						(ICalVcardProperty *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_deathplace
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_deathplace
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_deathplace
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_email	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_email	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_email	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_expertise
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_expertise
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_expertise
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_fburl	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_fburl	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_fburl	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_fn	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_fn	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_fn	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_gender	(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_property_get_gender	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_gender	(ICalVcardProperty *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_geo	(const ICalVcardGeo *value);

LIBICAL_ICAL_EXPORT
ICalVcardGeo *	i_cal_vcard_property_get_geo	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_geo	(ICalVcardProperty *self,
						 const ICalVcardGeo *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_gramgender
						(ICalVcardPropertyGramgender value);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyGramgender 
		i_cal_vcard_property_get_gramgender
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_gramgender
						(ICalVcardProperty *self,
						 ICalVcardPropertyGramgender value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_hobby	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_hobby	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_hobby	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_impp	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_impp	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_impp	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_interest
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_interest
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_interest
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_jsprop	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_jsprop	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_jsprop	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_key	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_key	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_key	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_kind	(ICalVcardPropertyKindenum value);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyKindenum 
		i_cal_vcard_property_get_kind	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_kind	(ICalVcardProperty *self,
						 ICalVcardPropertyKindenum value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_label	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_label	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_label	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_lang	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_lang	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_lang	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_language
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_language
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_language
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_logo	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_logo	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_logo	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_mailer	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_mailer	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_mailer	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_member	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_member	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_member	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_n	(const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_property_get_n	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_n	(ICalVcardProperty *self,
						 const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_name	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_name	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_name	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_nickname
						(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_property_get_nickname
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_nickname
						(ICalVcardProperty *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_note	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_note	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_note	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_org	(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_property_get_org	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_org	(ICalVcardProperty *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_orgdirectory
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_orgdirectory
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_orgdirectory
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_photo	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_photo	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_photo	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_prodid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_prodid	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_prodid	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_pronouns
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_pronouns
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_pronouns
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_related
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_related
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_related
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_rev	(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_property_get_rev	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_rev	(ICalVcardProperty *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_role	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_role	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_role	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_socialprofile
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_socialprofile
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_socialprofile
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_sortstring
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_sortstring
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_sortstring
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_sound	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_sound	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_sound	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_source	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_source	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_source	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_tel	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_tel	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_tel	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_title	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_title	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_title	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_tz	(const ICalVcardTz *value);

LIBICAL_ICAL_EXPORT
ICalVcardTz *	i_cal_vcard_property_get_tz	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_tz	(ICalVcardProperty *self,
						 const ICalVcardTz *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_uid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_uid	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_uid	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_url	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_url	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_url	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_version
						(ICalVcardPropertyVersion value);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyVersion 
		i_cal_vcard_property_get_version
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_version
						(ICalVcardProperty *self,
						 ICalVcardPropertyVersion value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_x	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_x	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_x	(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_xlicerror
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_xlicerror
						(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_xlicerror
						(ICalVcardProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_xml	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_xml	(const ICalVcardProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_xml	(ICalVcardProperty *self,
						 const gchar *value);

G_END_DECLS

#endif /* I_CAL_VCARD_DERIVED_PROPERTY_H */

//NOLINTEND
