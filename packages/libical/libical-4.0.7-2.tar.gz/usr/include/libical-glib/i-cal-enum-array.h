/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_ENUM_ARRAY_H
#define I_CAL_ENUM_ARRAY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_TYPE_ENUM_ARRAY \
    (i_cal_enum_array_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalEnumArray, i_cal_enum_array, I_CAL, ENUM_ARRAY, ICalObject)

/**
 * ICalEnumArray:
 *
 * This is the ICalEnumArray instance.
 */

/**
 * ICalEnumArrayClass:
 *
 * This is the ICalEnumArray class.
 */
struct _ICalEnumArrayClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalEnumArray *	i_cal_enum_array_new		(gint increment_size);

LIBICAL_ICAL_EXPORT
ICalEnumArray *	i_cal_enumarray_clone		(ICalEnumArray *array);

LIBICAL_ICAL_EXPORT
void		i_cal_enumarray_free		(ICalEnumArray *array);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_element_append_value
						(ICalEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_element_append_x_value
						(ICalEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_element_add_value
						(ICalEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_element_add_x_value
						(ICalEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_enumarray_remove_element_at
						(ICalEnumArray *array,
						 gint position);

LIBICAL_ICAL_EXPORT
gint 		i_cal_enum_array_element_get_value_at
						(ICalEnumArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_enum_array_element_get_xvalue_at
						(ICalEnumArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_enum_array_size		(ICalEnumArray *array);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_enum_array_find_value	(ICalEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_enum_array_find_x_value	(ICalEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_append_value	(ICalEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_append_x_value	(ICalEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_add_value	(ICalEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_add_x_value	(ICalEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_remove_element_at
						(ICalEnumArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_remove_value	(ICalEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_remove_x_value	(ICalEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_free		(ICalEnumArray *array);

LIBICAL_ICAL_EXPORT
void		i_cal_enum_array_sort		(ICalEnumArray *array);

LIBICAL_ICAL_EXPORT
ICalEnumArray *	i_cal_enum_array_clone		(ICalEnumArray *array);

G_END_DECLS

#endif /* I_CAL_ENUM_ARRAY_H */

//NOLINTEND
