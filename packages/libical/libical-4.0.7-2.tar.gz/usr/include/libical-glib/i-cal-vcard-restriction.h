/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_RESTRICTION_H
#define I_CAL_VCARD_RESTRICTION_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

typedef enum {
	I_CAL_VCARD_RESTRICTION_NONE = VCARD_RESTRICTION_NONE,
	I_CAL_VCARD_RESTRICTION_ZERO = VCARD_RESTRICTION_ZERO,
	I_CAL_VCARD_RESTRICTION_ONE = VCARD_RESTRICTION_ONE,
	I_CAL_VCARD_RESTRICTION_ZEROPLUS = VCARD_RESTRICTION_ZEROPLUS,
	I_CAL_VCARD_RESTRICTION_ONEPLUS = VCARD_RESTRICTION_ONEPLUS,
	I_CAL_VCARD_RESTRICTION_ZEROORONE = VCARD_RESTRICTION_ZEROORONE,
	I_CAL_VCARD_RESTRICTION_ONEEXCLUSIVE = VCARD_RESTRICTION_ONEEXCLUSIVE,
	I_CAL_VCARD_RESTRICTION_ONEMUTUAL = VCARD_RESTRICTION_ONEMUTUAL,
	I_CAL_VCARD_RESTRICTION_UNKNOWN = VCARD_RESTRICTION_UNKNOWN
} ICalVcardRestrictionKind;


LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_restriction_compare	(ICalVcardRestrictionKind restr,
						 gint count);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_restriction_check	(ICalVcardComponent *comp);

G_END_DECLS

#endif /* I_CAL_VCARD_RESTRICTION_H */

//NOLINTEND
