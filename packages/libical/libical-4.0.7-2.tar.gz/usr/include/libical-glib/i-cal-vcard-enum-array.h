/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_ENUM_ARRAY_H
#define I_CAL_VCARD_ENUM_ARRAY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_ENUM_ARRAY \
    (i_cal_vcard_enum_array_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardEnumArray, i_cal_vcard_enum_array, I_CAL_VCARD, ENUM_ARRAY, ICalObject)

/**
 * ICalVcardEnumArray:
 *
 * This is the ICalVcardEnumArray instance.
 */

/**
 * ICalVcardEnumArrayClass:
 *
 * This is the ICalVcardEnumArray class.
 */
struct _ICalVcardEnumArrayClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalVcardEnumArray *
		i_cal_vcard_enum_array_new	(gint increment_size);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_enum_array_get_value_at
						(ICalVcardEnumArray *array,
						 gint position);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_enum_array_get_xvalue_at
						(ICalVcardEnumArray *array,
						 gint position);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_enum_array_size	(ICalVcardEnumArray *array);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_enum_array_find_value
						(ICalVcardEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_enum_array_find_x_value
						(ICalVcardEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_append_value
						(ICalVcardEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_append_x_value
						(ICalVcardEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_add_value
						(ICalVcardEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_add_x_value
						(ICalVcardEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_remove_element_at
						(ICalVcardEnumArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_remove_value
						(ICalVcardEnumArray *array,
						 gint value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_remove_x_value
						(ICalVcardEnumArray *array,
						 const gchar *xvalue);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_free	(ICalVcardEnumArray *array);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_enum_array_sort	(ICalVcardEnumArray *array);

LIBICAL_ICAL_EXPORT
ICalVcardEnumArray *
		i_cal_vcard_enum_array_clone	(ICalVcardEnumArray *array);

G_END_DECLS

#endif /* I_CAL_VCARD_ENUM_ARRAY_H */

//NOLINTEND
