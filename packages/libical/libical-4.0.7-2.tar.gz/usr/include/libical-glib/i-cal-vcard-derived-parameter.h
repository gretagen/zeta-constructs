/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_DERIVED_PARAMETER_H
#define I_CAL_VCARD_DERIVED_PARAMETER_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

typedef enum {
	I_CAL_VCARD_ANY_PARAMETER = VCARD_ANY_PARAMETER,
	I_CAL_VCARD_ALTID_PARAMETER = VCARD_ALTID_PARAMETER,
	I_CAL_VCARD_AUTHOR_PARAMETER = VCARD_AUTHOR_PARAMETER,
	I_CAL_VCARD_AUTHORNAME_PARAMETER = VCARD_AUTHORNAME_PARAMETER,
	I_CAL_VCARD_CALSCALE_PARAMETER = VCARD_CALSCALE_PARAMETER,
	I_CAL_VCARD_CC_PARAMETER = VCARD_CC_PARAMETER,
	I_CAL_VCARD_CONTEXT_PARAMETER = VCARD_CONTEXT_PARAMETER,
	I_CAL_VCARD_CREATED_PARAMETER = VCARD_CREATED_PARAMETER,
	I_CAL_VCARD_DERIVED_PARAMETER = VCARD_DERIVED_PARAMETER,
	I_CAL_VCARD_ENCODING_PARAMETER = VCARD_ENCODING_PARAMETER,
	I_CAL_VCARD_GEO_PARAMETER = VCARD_GEO_PARAMETER,
	I_CAL_VCARD_IANA_PARAMETER = VCARD_IANA_PARAMETER,
	I_CAL_VCARD_INDEX_PARAMETER = VCARD_INDEX_PARAMETER,
	I_CAL_VCARD_JSCOMPS_PARAMETER = VCARD_JSCOMPS_PARAMETER,
	I_CAL_VCARD_JSPTR_PARAMETER = VCARD_JSPTR_PARAMETER,
	I_CAL_VCARD_LABEL_PARAMETER = VCARD_LABEL_PARAMETER,
	I_CAL_VCARD_LANGUAGE_PARAMETER = VCARD_LANGUAGE_PARAMETER,
	I_CAL_VCARD_LEVEL_PARAMETER = VCARD_LEVEL_PARAMETER,
	I_CAL_VCARD_MEDIATYPE_PARAMETER = VCARD_MEDIATYPE_PARAMETER,
	I_CAL_VCARD_PHONETIC_PARAMETER = VCARD_PHONETIC_PARAMETER,
	I_CAL_VCARD_PID_PARAMETER = VCARD_PID_PARAMETER,
	I_CAL_VCARD_PREF_PARAMETER = VCARD_PREF_PARAMETER,
	I_CAL_VCARD_PROPID_PARAMETER = VCARD_PROPID_PARAMETER,
	I_CAL_VCARD_SCRIPT_PARAMETER = VCARD_SCRIPT_PARAMETER,
	I_CAL_VCARD_SERVICETYPE_PARAMETER = VCARD_SERVICETYPE_PARAMETER,
	I_CAL_VCARD_SORTAS_PARAMETER = VCARD_SORTAS_PARAMETER,
	I_CAL_VCARD_TYPE_PARAMETER = VCARD_TYPE_PARAMETER,
	I_CAL_VCARD_TZ_PARAMETER = VCARD_TZ_PARAMETER,
	I_CAL_VCARD_USERNAME_PARAMETER = VCARD_USERNAME_PARAMETER,
	I_CAL_VCARD_VALUE_PARAMETER = VCARD_VALUE_PARAMETER,
	I_CAL_VCARD_X_PARAMETER = VCARD_X_PARAMETER,
	I_CAL_VCARD_XLICCOMPARETYPE_PARAMETER = VCARD_XLICCOMPARETYPE_PARAMETER,
	I_CAL_VCARD_XLICERRORTYPE_PARAMETER = VCARD_XLICERRORTYPE_PARAMETER,
	I_CAL_VCARD_NO_PARAMETER = VCARD_NO_PARAMETER
} ICalVcardParameterKind;

typedef enum {
	I_CAL_VCARD_CALSCALE_X = VCARD_CALSCALE_X,
	I_CAL_VCARD_CALSCALE_GREGORIAN = VCARD_CALSCALE_GREGORIAN,
	I_CAL_VCARD_CALSCALE_NONE = VCARD_CALSCALE_NONE
} ICalVcardParameterCalscale;

typedef enum {
	I_CAL_VCARD_DERIVED_X = VCARD_DERIVED_X,
	I_CAL_VCARD_DERIVED_TRUE = VCARD_DERIVED_TRUE,
	I_CAL_VCARD_DERIVED_FALSE = VCARD_DERIVED_FALSE,
	I_CAL_VCARD_DERIVED_NONE = VCARD_DERIVED_NONE
} ICalVcardParameterDerived;

typedef enum {
	I_CAL_VCARD_ENCODING_X = VCARD_ENCODING_X,
	I_CAL_VCARD_ENCODING_B = VCARD_ENCODING_B,
	I_CAL_VCARD_ENCODING_NONE = VCARD_ENCODING_NONE
} ICalVcardParameterEncoding;

typedef enum {
	I_CAL_VCARD_LEVEL_X = VCARD_LEVEL_X,
	I_CAL_VCARD_LEVEL_BEGINNER = VCARD_LEVEL_BEGINNER,
	I_CAL_VCARD_LEVEL_AVERAGE = VCARD_LEVEL_AVERAGE,
	I_CAL_VCARD_LEVEL_EXPERT = VCARD_LEVEL_EXPERT,
	I_CAL_VCARD_LEVEL_HIGH = VCARD_LEVEL_HIGH,
	I_CAL_VCARD_LEVEL_MEDIUM = VCARD_LEVEL_MEDIUM,
	I_CAL_VCARD_LEVEL_LOW = VCARD_LEVEL_LOW,
	I_CAL_VCARD_LEVEL_NONE = VCARD_LEVEL_NONE
} ICalVcardParameterLevel;

typedef enum {
	I_CAL_VCARD_PHONETIC_X = VCARD_PHONETIC_X,
	I_CAL_VCARD_PHONETIC_IPA = VCARD_PHONETIC_IPA,
	I_CAL_VCARD_PHONETIC_PINY = VCARD_PHONETIC_PINY,
	I_CAL_VCARD_PHONETIC_JYUT = VCARD_PHONETIC_JYUT,
	I_CAL_VCARD_PHONETIC_SCRIPT = VCARD_PHONETIC_SCRIPT,
	I_CAL_VCARD_PHONETIC_NONE = VCARD_PHONETIC_NONE
} ICalVcardParameterPhonetic;

typedef enum {
	I_CAL_VCARD_TYPE_X = VCARD_TYPE_X,
	I_CAL_VCARD_TYPE_WORK = VCARD_TYPE_WORK,
	I_CAL_VCARD_TYPE_HOME = VCARD_TYPE_HOME,
	I_CAL_VCARD_TYPE_TEXT = VCARD_TYPE_TEXT,
	I_CAL_VCARD_TYPE_VOICE = VCARD_TYPE_VOICE,
	I_CAL_VCARD_TYPE_FAX = VCARD_TYPE_FAX,
	I_CAL_VCARD_TYPE_CELL = VCARD_TYPE_CELL,
	I_CAL_VCARD_TYPE_VIDEO = VCARD_TYPE_VIDEO,
	I_CAL_VCARD_TYPE_PAGER = VCARD_TYPE_PAGER,
	I_CAL_VCARD_TYPE_TEXTPHONE = VCARD_TYPE_TEXTPHONE,
	I_CAL_VCARD_TYPE_CONTACT = VCARD_TYPE_CONTACT,
	I_CAL_VCARD_TYPE_ACQUAINTANCE = VCARD_TYPE_ACQUAINTANCE,
	I_CAL_VCARD_TYPE_FRIEND = VCARD_TYPE_FRIEND,
	I_CAL_VCARD_TYPE_MET = VCARD_TYPE_MET,
	I_CAL_VCARD_TYPE_COWORKER = VCARD_TYPE_COWORKER,
	I_CAL_VCARD_TYPE_COLLEAGUE = VCARD_TYPE_COLLEAGUE,
	I_CAL_VCARD_TYPE_CORESIDENT = VCARD_TYPE_CORESIDENT,
	I_CAL_VCARD_TYPE_NEIGHBOR = VCARD_TYPE_NEIGHBOR,
	I_CAL_VCARD_TYPE_CHILD = VCARD_TYPE_CHILD,
	I_CAL_VCARD_TYPE_PARENT = VCARD_TYPE_PARENT,
	I_CAL_VCARD_TYPE_SIBLING = VCARD_TYPE_SIBLING,
	I_CAL_VCARD_TYPE_SPOUSE = VCARD_TYPE_SPOUSE,
	I_CAL_VCARD_TYPE_KIN = VCARD_TYPE_KIN,
	I_CAL_VCARD_TYPE_MUSE = VCARD_TYPE_MUSE,
	I_CAL_VCARD_TYPE_CRUSH = VCARD_TYPE_CRUSH,
	I_CAL_VCARD_TYPE_DATE = VCARD_TYPE_DATE,
	I_CAL_VCARD_TYPE_SWEETHEART = VCARD_TYPE_SWEETHEART,
	I_CAL_VCARD_TYPE_ME = VCARD_TYPE_ME,
	I_CAL_VCARD_TYPE_AGENT = VCARD_TYPE_AGENT,
	I_CAL_VCARD_TYPE_EMERGENCY = VCARD_TYPE_EMERGENCY,
	I_CAL_VCARD_TYPE_PREF = VCARD_TYPE_PREF,
	I_CAL_VCARD_TYPE_MAINNUMBER = VCARD_TYPE_MAINNUMBER,
	I_CAL_VCARD_TYPE_BILLING = VCARD_TYPE_BILLING,
	I_CAL_VCARD_TYPE_DELIVERY = VCARD_TYPE_DELIVERY,
	I_CAL_VCARD_TYPE_NONE = VCARD_TYPE_NONE
} ICalVcardParameterType;

typedef enum {
	I_CAL_VCARD_VALUE_X = VCARD_VALUE_X,
	I_CAL_VCARD_VALUE_TEXT = VCARD_VALUE_TEXT,
	I_CAL_VCARD_VALUE_URI = VCARD_VALUE_URI,
	I_CAL_VCARD_VALUE_DATE = VCARD_VALUE_DATE,
	I_CAL_VCARD_VALUE_TIME = VCARD_VALUE_TIME,
	I_CAL_VCARD_VALUE_DATETIME = VCARD_VALUE_DATETIME,
	I_CAL_VCARD_VALUE_DATEANDORTIME = VCARD_VALUE_DATEANDORTIME,
	I_CAL_VCARD_VALUE_TIMESTAMP = VCARD_VALUE_TIMESTAMP,
	I_CAL_VCARD_VALUE_BOOLEAN = VCARD_VALUE_BOOLEAN,
	I_CAL_VCARD_VALUE_INTEGER = VCARD_VALUE_INTEGER,
	I_CAL_VCARD_VALUE_FLOAT = VCARD_VALUE_FLOAT,
	I_CAL_VCARD_VALUE_UTCOFFSET = VCARD_VALUE_UTCOFFSET,
	I_CAL_VCARD_VALUE_LANGUAGETAG = VCARD_VALUE_LANGUAGETAG,
	I_CAL_VCARD_VALUE_STRUCTURED = VCARD_VALUE_STRUCTURED,
	I_CAL_VCARD_VALUE_NONE = VCARD_VALUE_NONE
} ICalVcardParameterValue;

typedef enum {
	I_CAL_VCARD_XLICCOMPARETYPE_X = VCARD_XLICCOMPARETYPE_X,
	I_CAL_VCARD_XLICCOMPARETYPE_EQUAL = VCARD_XLICCOMPARETYPE_EQUAL,
	I_CAL_VCARD_XLICCOMPARETYPE_NOTEQUAL = VCARD_XLICCOMPARETYPE_NOTEQUAL,
	I_CAL_VCARD_XLICCOMPARETYPE_LESS = VCARD_XLICCOMPARETYPE_LESS,
	I_CAL_VCARD_XLICCOMPARETYPE_GREATER = VCARD_XLICCOMPARETYPE_GREATER,
	I_CAL_VCARD_XLICCOMPARETYPE_LESSEQUAL = VCARD_XLICCOMPARETYPE_LESSEQUAL,
	I_CAL_VCARD_XLICCOMPARETYPE_GREATEREQUAL = VCARD_XLICCOMPARETYPE_GREATEREQUAL,
	I_CAL_VCARD_XLICCOMPARETYPE_REGEX = VCARD_XLICCOMPARETYPE_REGEX,
	I_CAL_VCARD_XLICCOMPARETYPE_ISNULL = VCARD_XLICCOMPARETYPE_ISNULL,
	I_CAL_VCARD_XLICCOMPARETYPE_ISNOTNULL = VCARD_XLICCOMPARETYPE_ISNOTNULL,
	I_CAL_VCARD_XLICCOMPARETYPE_NONE = VCARD_XLICCOMPARETYPE_NONE
} ICalVcardParameterXliccomparetype;

typedef enum {
	I_CAL_VCARD_XLICERRORTYPE_X = VCARD_XLICERRORTYPE_X,
	I_CAL_VCARD_XLICERRORTYPE_COMPONENTPARSEERROR = VCARD_XLICERRORTYPE_COMPONENTPARSEERROR,
	I_CAL_VCARD_XLICERRORTYPE_PROPERTYPARSEERROR = VCARD_XLICERRORTYPE_PROPERTYPARSEERROR,
	I_CAL_VCARD_XLICERRORTYPE_PARAMETERNAMEPARSEERROR = VCARD_XLICERRORTYPE_PARAMETERNAMEPARSEERROR,
	I_CAL_VCARD_XLICERRORTYPE_PARAMETERVALUEPARSEERROR = VCARD_XLICERRORTYPE_PARAMETERVALUEPARSEERROR,
	I_CAL_VCARD_XLICERRORTYPE_VALUEPARSEERROR = VCARD_XLICERRORTYPE_VALUEPARSEERROR,
	I_CAL_VCARD_XLICERRORTYPE_RESTRICTIONCHECK = VCARD_XLICERRORTYPE_RESTRICTIONCHECK,
	I_CAL_VCARD_XLICERRORTYPE_NONE = VCARD_XLICERRORTYPE_NONE
} ICalVcardParameterXlicerrortype;


LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_enum_to_string
						(gint e);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_parameter_enum_from_string
						(const gchar *str);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_altid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_altid	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_altid	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_author
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_author
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_author
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_authorname
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_authorname
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_authorname
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_calscale
						(ICalVcardParameterCalscale value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterCalscale 
		i_cal_vcard_parameter_get_calscale
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_calscale
						(ICalVcardParameter *self,
						 ICalVcardParameterCalscale value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_cc	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_cc	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_cc	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_context
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_context
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_context
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_created
						(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_parameter_get_created
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_created
						(ICalVcardParameter *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_derived
						(ICalVcardParameterDerived value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterDerived 
		i_cal_vcard_parameter_get_derived
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_derived
						(ICalVcardParameter *self,
						 ICalVcardParameterDerived value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_encoding
						(ICalVcardParameterEncoding value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterEncoding 
		i_cal_vcard_parameter_get_encoding
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_encoding
						(ICalVcardParameter *self,
						 ICalVcardParameterEncoding value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_geo	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_geo	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_geo	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_iana	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_iana	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_iana	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_index	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_parameter_get_index	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_index	(ICalVcardParameter *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_jscomps
						(const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_parameter_get_jscomps
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_jscomps
						(ICalVcardParameter *self,
						 const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_jsptr	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_jsptr	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_jsptr	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_label	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_label	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_label	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_language
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_language
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_language
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_level	(ICalVcardParameterLevel value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterLevel 
		i_cal_vcard_parameter_get_level	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_level	(ICalVcardParameter *self,
						 ICalVcardParameterLevel value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_mediatype
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_mediatype
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_mediatype
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_phonetic
						(ICalVcardParameterPhonetic value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterPhonetic 
		i_cal_vcard_parameter_get_phonetic
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_phonetic
						(ICalVcardParameter *self,
						 ICalVcardParameterPhonetic value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_pid	(const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_pid_list
						(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_parameter_get_pid	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_pid	(ICalVcardParameter *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_parameter_get_pid_size
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_pid_nth
						(const ICalVcardParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_add_pid	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_remove_pid
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_pref	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_parameter_get_pref	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_pref	(ICalVcardParameter *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_propid
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_propid
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_propid
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_script
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_script
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_script
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_servicetype
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_servicetype
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_servicetype
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_sortas
						(const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_sortas_list
						(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_parameter_get_sortas
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_sortas
						(ICalVcardParameter *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_parameter_get_sortas_size
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_sortas_nth
						(const ICalVcardParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_add_sortas
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_remove_sortas
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_type	(ICalVcardParameterType value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_type_list
						(const ICalVcardEnumArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardEnumArray *
		i_cal_vcard_parameter_get_type_value
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_type_value
						(ICalVcardParameter *self,
						 const ICalVcardEnumArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_parameter_get_type_size
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
ICalVcardParameterType 
		i_cal_vcard_parameter_get_type_nth
						(const ICalVcardParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_add_type	(ICalVcardParameter *self,
						 ICalVcardParameterType value,
						 const gchar *x_value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_remove_type
						(ICalVcardParameter *self,
						 ICalVcardParameterType value,
						 const gchar *x_value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_tz	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_tz	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_tz	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_username
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_username
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_username
						(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_value	(ICalVcardParameterValue value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterValue 
		i_cal_vcard_parameter_get_value	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_value	(ICalVcardParameter *self,
						 ICalVcardParameterValue value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_x	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_x	(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_x	(ICalVcardParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_xliccomparetype
						(ICalVcardParameterXliccomparetype value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterXliccomparetype 
		i_cal_vcard_parameter_get_xliccomparetype
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_xliccomparetype
						(ICalVcardParameter *self,
						 ICalVcardParameterXliccomparetype value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_xlicerrortype
						(ICalVcardParameterXlicerrortype value);

LIBICAL_ICAL_EXPORT
ICalVcardParameterXlicerrortype 
		i_cal_vcard_parameter_get_xlicerrortype
						(const ICalVcardParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_xlicerrortype
						(ICalVcardParameter *self,
						 ICalVcardParameterXlicerrortype value);

G_END_DECLS

#endif /* I_CAL_VCARD_DERIVED_PARAMETER_H */

//NOLINTEND
