/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_STR_ARRAY_H
#define I_CAL_STR_ARRAY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_TYPE_STR_ARRAY \
    (i_cal_str_array_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalStrArray, i_cal_str_array, I_CAL, STR_ARRAY, ICalObject)

/**
 * ICalStrArray:
 *
 * This is the ICalStrArray instance.
 */

/**
 * ICalStrArrayClass:
 *
 * This is the ICalStrArray class.
 */
struct _ICalStrArrayClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalStrArray *	i_cal_str_array_new		(gint increment_size);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_str_array_get_element_at	(ICalStrArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_str_array_size		(ICalStrArray *array);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_str_array_find		(ICalStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_str_array_append		(ICalStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_str_array_add		(ICalStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_str_array_remove_element_at
						(ICalStrArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_str_array_remove		(ICalStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_str_array_free		(ICalStrArray *array);

LIBICAL_ICAL_EXPORT
void		i_cal_str_array_sort		(ICalStrArray *array);

LIBICAL_ICAL_EXPORT
ICalStrArray *	i_cal_str_array_clone		(ICalStrArray *array);

G_END_DECLS

#endif /* I_CAL_STR_ARRAY_H */

//NOLINTEND
