/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_PROPERTY_H
#define I_CAL_VCARD_PROPERTY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>
#include <libical-glib/i-cal-vcard-derived-value.h>
#include <libical-glib/i-cal-vcard-derived-parameter.h>
#include <libical-glib/i-cal-vcard-derived-property.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_PROPERTY \
    (i_cal_vcard_property_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardProperty, i_cal_vcard_property, I_CAL_VCARD, PROPERTY, ICalObject)

/**
 * ICalVcardProperty:
 *
 * This is the ICalVcardProperty instance.
 */

/**
 * ICalVcardPropertyClass:
 *
 * This is the ICalVcardProperty class.
 */
struct _ICalVcardPropertyClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new	(ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_clone	(const ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_property_new_from_string
						(const gchar *str);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_property_as_vcard_string
						(ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_free	(ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyKind 
		i_cal_vcard_property_isa	(ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_property_isa_property
						(ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_add_parameter
						(ICalVcardProperty *prop,
						 ICalVcardParameter *parameter);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_take_parameter
						(ICalVcardProperty *prop,
						 ICalVcardParameter *parameter);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_parameter
						(ICalVcardProperty *prop,
						 ICalVcardParameter *parameter);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_parameter_from_string
						(ICalVcardProperty *prop,
						 const gchar *name,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_property_get_parameter_as_string
						(ICalVcardProperty *prop,
						 const gchar *name);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_remove_parameter_by_kind
						(ICalVcardProperty *prop,
						 ICalVcardParameterKind kind);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_remove_parameter_by_name
						(ICalVcardProperty *prop,
						 const gchar *name);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_remove_parameter_by_ref
						(ICalVcardProperty *prop,
						 ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_property_count_parameters
						(const ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_property_get_first_parameter
						(ICalVcardProperty *prop,
						 ICalVcardParameterKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_property_get_next_parameter
						(ICalVcardProperty *prop,
						 ICalVcardParameterKind kind);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_value	(ICalVcardProperty *prop,
						 ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_take_value	(ICalVcardProperty *prop,
						 ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_value_from_string
						(ICalVcardProperty *prop,
						 const gchar *value,
						 const gchar *kind);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_property_get_value	(const ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_property_get_value_as_string
						(const ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_parent	(ICalVcardValue *value,
						 ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_value_get_parent	(const ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_x_name	(ICalVcardProperty *prop,
						 const gchar *name);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_x_name	(ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_group	(ICalVcardProperty *prop,
						 const gchar *group);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_get_group	(ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_property_get_property_name
						(const ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
ICalVcardValueKind 
		i_cal_vcard_parameter_value_to_value_kind
						(ICalVcardParameterValue value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_parent
						(ICalVcardParameter *param,
						 ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_parameter_get_parent
						(ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
ICalVcardValueKind 
		i_cal_vcard_property_kind_to_value_kind
						(ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyKind 
		i_cal_vcard_value_kind_to_property_kind
						(ICalVcardValueKind kind);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_property_kind_to_string
						(ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyKind 
		i_cal_vcard_property_kind_from_string
						(const gchar *string);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_property_kind_is_valid
						(ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_property_enum_to_string
						(int e);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_property_kind_and_string_to_enum
						(int kind,
						 const gchar *str);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_property_enum_belongs_to_property
						(ICalVcardPropertyKind kind,
						 int e);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_normalize	(ICalVcardProperty *prop);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_property_kind_is_structured
						(ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_property_kind_is_multivalued
						(ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_add_type_parameter
						(ICalVcardProperty *prop,
						 ICalVcardParameterType type_param);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_add_type_x_parameter
						(ICalVcardProperty *prop,
						 const gchar *type_param);

G_END_DECLS

#endif /* I_CAL_VCARD_PROPERTY_H */

//NOLINTEND
