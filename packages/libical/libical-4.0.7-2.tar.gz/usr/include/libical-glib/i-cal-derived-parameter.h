/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_DERIVED_PARAMETER_H
#define I_CAL_DERIVED_PARAMETER_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

typedef enum {
	I_CAL_ANY_PARAMETER = ICAL_ANY_PARAMETER,
	I_CAL_ACTIONPARAM_PARAMETER = ICAL_ACTIONPARAM_PARAMETER,
	I_CAL_ALTREP_PARAMETER = ICAL_ALTREP_PARAMETER,
	I_CAL_CHARSET_PARAMETER = ICAL_CHARSET_PARAMETER,
	I_CAL_CN_PARAMETER = ICAL_CN_PARAMETER,
	I_CAL_CUTYPE_PARAMETER = ICAL_CUTYPE_PARAMETER,
	I_CAL_DELEGATEDFROM_PARAMETER = ICAL_DELEGATEDFROM_PARAMETER,
	I_CAL_DELEGATEDTO_PARAMETER = ICAL_DELEGATEDTO_PARAMETER,
	I_CAL_DERIVED_PARAMETER = ICAL_DERIVED_PARAMETER,
	I_CAL_DIR_PARAMETER = ICAL_DIR_PARAMETER,
	I_CAL_DISPLAY_PARAMETER = ICAL_DISPLAY_PARAMETER,
	I_CAL_EMAIL_PARAMETER = ICAL_EMAIL_PARAMETER,
	I_CAL_ENABLE_PARAMETER = ICAL_ENABLE_PARAMETER,
	I_CAL_ENCODING_PARAMETER = ICAL_ENCODING_PARAMETER,
	I_CAL_FBTYPE_PARAMETER = ICAL_FBTYPE_PARAMETER,
	I_CAL_FEATURE_PARAMETER = ICAL_FEATURE_PARAMETER,
	I_CAL_FILENAME_PARAMETER = ICAL_FILENAME_PARAMETER,
	I_CAL_FMTTYPE_PARAMETER = ICAL_FMTTYPE_PARAMETER,
	I_CAL_GAP_PARAMETER = ICAL_GAP_PARAMETER,
	I_CAL_IANA_PARAMETER = ICAL_IANA_PARAMETER,
	I_CAL_ID_PARAMETER = ICAL_ID_PARAMETER,
	I_CAL_LABEL_PARAMETER = ICAL_LABEL_PARAMETER,
	I_CAL_LANGUAGE_PARAMETER = ICAL_LANGUAGE_PARAMETER,
	I_CAL_LATENCY_PARAMETER = ICAL_LATENCY_PARAMETER,
	I_CAL_LINKREL_PARAMETER = ICAL_LINKREL_PARAMETER,
	I_CAL_LOCAL_PARAMETER = ICAL_LOCAL_PARAMETER,
	I_CAL_LOCALIZE_PARAMETER = ICAL_LOCALIZE_PARAMETER,
	I_CAL_MANAGEDID_PARAMETER = ICAL_MANAGEDID_PARAMETER,
	I_CAL_MEMBER_PARAMETER = ICAL_MEMBER_PARAMETER,
	I_CAL_MODIFIED_PARAMETER = ICAL_MODIFIED_PARAMETER,
	I_CAL_OPTIONS_PARAMETER = ICAL_OPTIONS_PARAMETER,
	I_CAL_ORDER_PARAMETER = ICAL_ORDER_PARAMETER,
	I_CAL_PARTSTAT_PARAMETER = ICAL_PARTSTAT_PARAMETER,
	I_CAL_PATCHACTION_PARAMETER = ICAL_PATCHACTION_PARAMETER,
	I_CAL_PUBLICCOMMENT_PARAMETER = ICAL_PUBLICCOMMENT_PARAMETER,
	I_CAL_RANGE_PARAMETER = ICAL_RANGE_PARAMETER,
	I_CAL_REASON_PARAMETER = ICAL_REASON_PARAMETER,
	I_CAL_RELATED_PARAMETER = ICAL_RELATED_PARAMETER,
	I_CAL_RELTYPE_PARAMETER = ICAL_RELTYPE_PARAMETER,
	I_CAL_REQUIRED_PARAMETER = ICAL_REQUIRED_PARAMETER,
	I_CAL_RESPONSE_PARAMETER = ICAL_RESPONSE_PARAMETER,
	I_CAL_ROLE_PARAMETER = ICAL_ROLE_PARAMETER,
	I_CAL_RSVP_PARAMETER = ICAL_RSVP_PARAMETER,
	I_CAL_SCHEDULEAGENT_PARAMETER = ICAL_SCHEDULEAGENT_PARAMETER,
	I_CAL_SCHEDULEFORCESEND_PARAMETER = ICAL_SCHEDULEFORCESEND_PARAMETER,
	I_CAL_SCHEDULESTATUS_PARAMETER = ICAL_SCHEDULESTATUS_PARAMETER,
	I_CAL_SCHEMA_PARAMETER = ICAL_SCHEMA_PARAMETER,
	I_CAL_SENTBY_PARAMETER = ICAL_SENTBY_PARAMETER,
	I_CAL_SIZE_PARAMETER = ICAL_SIZE_PARAMETER,
	I_CAL_STAYINFORMED_PARAMETER = ICAL_STAYINFORMED_PARAMETER,
	I_CAL_SUBSTATE_PARAMETER = ICAL_SUBSTATE_PARAMETER,
	I_CAL_TZID_PARAMETER = ICAL_TZID_PARAMETER,
	I_CAL_VALUE_PARAMETER = ICAL_VALUE_PARAMETER,
	I_CAL_X_PARAMETER = ICAL_X_PARAMETER,
	I_CAL_XLICCOMPARETYPE_PARAMETER = ICAL_XLICCOMPARETYPE_PARAMETER,
	I_CAL_XLICERRORTYPE_PARAMETER = ICAL_XLICERRORTYPE_PARAMETER,
	I_CAL_NO_PARAMETER = ICAL_NO_PARAMETER
} ICalParameterKind;

typedef enum {
	I_CAL_ACTIONPARAM_X = ICAL_ACTIONPARAM_X,
	I_CAL_ACTIONPARAM_ASK = ICAL_ACTIONPARAM_ASK,
	I_CAL_ACTIONPARAM_ABORT = ICAL_ACTIONPARAM_ABORT,
	I_CAL_ACTIONPARAM_NONE = ICAL_ACTIONPARAM_NONE
} ICalParameterAction;

typedef enum {
	I_CAL_CUTYPE_X = ICAL_CUTYPE_X,
	I_CAL_CUTYPE_INDIVIDUAL = ICAL_CUTYPE_INDIVIDUAL,
	I_CAL_CUTYPE_GROUP = ICAL_CUTYPE_GROUP,
	I_CAL_CUTYPE_RESOURCE = ICAL_CUTYPE_RESOURCE,
	I_CAL_CUTYPE_ROOM = ICAL_CUTYPE_ROOM,
	I_CAL_CUTYPE_UNKNOWN = ICAL_CUTYPE_UNKNOWN,
	I_CAL_CUTYPE_NONE = ICAL_CUTYPE_NONE
} ICalParameterCutype;

typedef enum {
	I_CAL_DERIVED_X = ICAL_DERIVED_X,
	I_CAL_DERIVED_TRUE = ICAL_DERIVED_TRUE,
	I_CAL_DERIVED_FALSE = ICAL_DERIVED_FALSE,
	I_CAL_DERIVED_NONE = ICAL_DERIVED_NONE
} ICalParameterDerived;

typedef enum {
	I_CAL_DISPLAY_X = ICAL_DISPLAY_X,
	I_CAL_DISPLAY_BADGE = ICAL_DISPLAY_BADGE,
	I_CAL_DISPLAY_GRAPHIC = ICAL_DISPLAY_GRAPHIC,
	I_CAL_DISPLAY_FULLSIZE = ICAL_DISPLAY_FULLSIZE,
	I_CAL_DISPLAY_THUMBNAIL = ICAL_DISPLAY_THUMBNAIL,
	I_CAL_DISPLAY_NONE = ICAL_DISPLAY_NONE
} ICalParameterDisplay;

typedef enum {
	I_CAL_ENABLE_X = ICAL_ENABLE_X,
	I_CAL_ENABLE_TRUE = ICAL_ENABLE_TRUE,
	I_CAL_ENABLE_FALSE = ICAL_ENABLE_FALSE,
	I_CAL_ENABLE_NONE = ICAL_ENABLE_NONE
} ICalParameterEnable;

typedef enum {
	I_CAL_ENCODING_X = ICAL_ENCODING_X,
	I_CAL_ENCODING_8BIT = ICAL_ENCODING_8BIT,
	I_CAL_ENCODING_BASE64 = ICAL_ENCODING_BASE64,
	I_CAL_ENCODING_NONE = ICAL_ENCODING_NONE
} ICalParameterEncoding;

typedef enum {
	I_CAL_FBTYPE_X = ICAL_FBTYPE_X,
	I_CAL_FBTYPE_FREE = ICAL_FBTYPE_FREE,
	I_CAL_FBTYPE_BUSY = ICAL_FBTYPE_BUSY,
	I_CAL_FBTYPE_BUSYUNAVAILABLE = ICAL_FBTYPE_BUSYUNAVAILABLE,
	I_CAL_FBTYPE_BUSYTENTATIVE = ICAL_FBTYPE_BUSYTENTATIVE,
	I_CAL_FBTYPE_NONE = ICAL_FBTYPE_NONE
} ICalParameterFbtype;

typedef enum {
	I_CAL_FEATURE_X = ICAL_FEATURE_X,
	I_CAL_FEATURE_AUDIO = ICAL_FEATURE_AUDIO,
	I_CAL_FEATURE_CHAT = ICAL_FEATURE_CHAT,
	I_CAL_FEATURE_FEED = ICAL_FEATURE_FEED,
	I_CAL_FEATURE_MODERATOR = ICAL_FEATURE_MODERATOR,
	I_CAL_FEATURE_PHONE = ICAL_FEATURE_PHONE,
	I_CAL_FEATURE_SCREEN = ICAL_FEATURE_SCREEN,
	I_CAL_FEATURE_VIDEO = ICAL_FEATURE_VIDEO,
	I_CAL_FEATURE_NONE = ICAL_FEATURE_NONE
} ICalParameterFeature;

typedef enum {
	I_CAL_LOCAL_X = ICAL_LOCAL_X,
	I_CAL_LOCAL_TRUE = ICAL_LOCAL_TRUE,
	I_CAL_LOCAL_FALSE = ICAL_LOCAL_FALSE,
	I_CAL_LOCAL_NONE = ICAL_LOCAL_NONE
} ICalParameterLocal;

typedef enum {
	I_CAL_PARTSTAT_X = ICAL_PARTSTAT_X,
	I_CAL_PARTSTAT_NEEDSACTION = ICAL_PARTSTAT_NEEDSACTION,
	I_CAL_PARTSTAT_ACCEPTED = ICAL_PARTSTAT_ACCEPTED,
	I_CAL_PARTSTAT_DECLINED = ICAL_PARTSTAT_DECLINED,
	I_CAL_PARTSTAT_TENTATIVE = ICAL_PARTSTAT_TENTATIVE,
	I_CAL_PARTSTAT_DELEGATED = ICAL_PARTSTAT_DELEGATED,
	I_CAL_PARTSTAT_COMPLETED = ICAL_PARTSTAT_COMPLETED,
	I_CAL_PARTSTAT_INPROCESS = ICAL_PARTSTAT_INPROCESS,
	I_CAL_PARTSTAT_FAILED = ICAL_PARTSTAT_FAILED,
	I_CAL_PARTSTAT_NONE = ICAL_PARTSTAT_NONE
} ICalParameterPartstat;

typedef enum {
	I_CAL_PATCHACTION_X = ICAL_PATCHACTION_X,
	I_CAL_PATCHACTION_CREATE = ICAL_PATCHACTION_CREATE,
	I_CAL_PATCHACTION_BYNAME = ICAL_PATCHACTION_BYNAME,
	I_CAL_PATCHACTION_BYVALUE = ICAL_PATCHACTION_BYVALUE,
	I_CAL_PATCHACTION_BYPARAM = ICAL_PATCHACTION_BYPARAM,
	I_CAL_PATCHACTION_NONE = ICAL_PATCHACTION_NONE
} ICalParameterPatchaction;

typedef enum {
	I_CAL_RANGE_X = ICAL_RANGE_X,
	I_CAL_RANGE_THISANDPRIOR = ICAL_RANGE_THISANDPRIOR,
	I_CAL_RANGE_THISANDFUTURE = ICAL_RANGE_THISANDFUTURE,
	I_CAL_RANGE_NONE = ICAL_RANGE_NONE
} ICalParameterRange;

typedef enum {
	I_CAL_RELATED_X = ICAL_RELATED_X,
	I_CAL_RELATED_START = ICAL_RELATED_START,
	I_CAL_RELATED_END = ICAL_RELATED_END,
	I_CAL_RELATED_NONE = ICAL_RELATED_NONE
} ICalParameterRelated;

typedef enum {
	I_CAL_RELTYPE_X = ICAL_RELTYPE_X,
	I_CAL_RELTYPE_PARENT = ICAL_RELTYPE_PARENT,
	I_CAL_RELTYPE_CHILD = ICAL_RELTYPE_CHILD,
	I_CAL_RELTYPE_SIBLING = ICAL_RELTYPE_SIBLING,
	I_CAL_RELTYPE_POLL = ICAL_RELTYPE_POLL,
	I_CAL_RELTYPE_SNOOZE = ICAL_RELTYPE_SNOOZE,
	I_CAL_RELTYPE_CONCEPT = ICAL_RELTYPE_CONCEPT,
	I_CAL_RELTYPE_DEPENDSON = ICAL_RELTYPE_DEPENDSON,
	I_CAL_RELTYPE_FINISHTOFINISH = ICAL_RELTYPE_FINISHTOFINISH,
	I_CAL_RELTYPE_FINISHTOSTART = ICAL_RELTYPE_FINISHTOSTART,
	I_CAL_RELTYPE_FIRST = ICAL_RELTYPE_FIRST,
	I_CAL_RELTYPE_NEXT = ICAL_RELTYPE_NEXT,
	I_CAL_RELTYPE_REFID = ICAL_RELTYPE_REFID,
	I_CAL_RELTYPE_STARTTOFINISH = ICAL_RELTYPE_STARTTOFINISH,
	I_CAL_RELTYPE_STARTTOSTART = ICAL_RELTYPE_STARTTOSTART,
	I_CAL_RELTYPE_NONE = ICAL_RELTYPE_NONE
} ICalParameterReltype;

typedef enum {
	I_CAL_REQUIRED_X = ICAL_REQUIRED_X,
	I_CAL_REQUIRED_TRUE = ICAL_REQUIRED_TRUE,
	I_CAL_REQUIRED_FALSE = ICAL_REQUIRED_FALSE,
	I_CAL_REQUIRED_NONE = ICAL_REQUIRED_NONE
} ICalParameterRequired;

typedef enum {
	I_CAL_ROLE_X = ICAL_ROLE_X,
	I_CAL_ROLE_CHAIR = ICAL_ROLE_CHAIR,
	I_CAL_ROLE_REQPARTICIPANT = ICAL_ROLE_REQPARTICIPANT,
	I_CAL_ROLE_OPTPARTICIPANT = ICAL_ROLE_OPTPARTICIPANT,
	I_CAL_ROLE_NONPARTICIPANT = ICAL_ROLE_NONPARTICIPANT,
	I_CAL_ROLE_NONE = ICAL_ROLE_NONE
} ICalParameterRole;

typedef enum {
	I_CAL_RSVP_X = ICAL_RSVP_X,
	I_CAL_RSVP_TRUE = ICAL_RSVP_TRUE,
	I_CAL_RSVP_FALSE = ICAL_RSVP_FALSE,
	I_CAL_RSVP_NONE = ICAL_RSVP_NONE
} ICalParameterRsvp;

typedef enum {
	I_CAL_SCHEDULEAGENT_X = ICAL_SCHEDULEAGENT_X,
	I_CAL_SCHEDULEAGENT_SERVER = ICAL_SCHEDULEAGENT_SERVER,
	I_CAL_SCHEDULEAGENT_CLIENT = ICAL_SCHEDULEAGENT_CLIENT,
	I_CAL_SCHEDULEAGENT_NONE = ICAL_SCHEDULEAGENT_NONE
} ICalParameterScheduleagent;

typedef enum {
	I_CAL_SCHEDULEFORCESEND_X = ICAL_SCHEDULEFORCESEND_X,
	I_CAL_SCHEDULEFORCESEND_REQUEST = ICAL_SCHEDULEFORCESEND_REQUEST,
	I_CAL_SCHEDULEFORCESEND_REPLY = ICAL_SCHEDULEFORCESEND_REPLY,
	I_CAL_SCHEDULEFORCESEND_NONE = ICAL_SCHEDULEFORCESEND_NONE
} ICalParameterScheduleforcesend;

typedef enum {
	I_CAL_STAYINFORMED_X = ICAL_STAYINFORMED_X,
	I_CAL_STAYINFORMED_TRUE = ICAL_STAYINFORMED_TRUE,
	I_CAL_STAYINFORMED_FALSE = ICAL_STAYINFORMED_FALSE,
	I_CAL_STAYINFORMED_NONE = ICAL_STAYINFORMED_NONE
} ICalParameterStayinformed;

typedef enum {
	I_CAL_SUBSTATE_X = ICAL_SUBSTATE_X,
	I_CAL_SUBSTATE_OK = ICAL_SUBSTATE_OK,
	I_CAL_SUBSTATE_ERROR = ICAL_SUBSTATE_ERROR,
	I_CAL_SUBSTATE_SUSPENDED = ICAL_SUBSTATE_SUSPENDED,
	I_CAL_SUBSTATE_NONE = ICAL_SUBSTATE_NONE
} ICalParameterSubstate;

typedef enum {
	I_CAL_VALUE_X = ICAL_VALUE_X,
	I_CAL_VALUE_BINARY = ICAL_VALUE_BINARY,
	I_CAL_VALUE_BOOLEAN = ICAL_VALUE_BOOLEAN,
	I_CAL_VALUE_DATE = ICAL_VALUE_DATE,
	I_CAL_VALUE_DURATION = ICAL_VALUE_DURATION,
	I_CAL_VALUE_FLOAT = ICAL_VALUE_FLOAT,
	I_CAL_VALUE_INTEGER = ICAL_VALUE_INTEGER,
	I_CAL_VALUE_PERIOD = ICAL_VALUE_PERIOD,
	I_CAL_VALUE_RECUR = ICAL_VALUE_RECUR,
	I_CAL_VALUE_TEXT = ICAL_VALUE_TEXT,
	I_CAL_VALUE_URI = ICAL_VALUE_URI,
	I_CAL_VALUE_ERROR = ICAL_VALUE_ERROR,
	I_CAL_VALUE_DATETIME = ICAL_VALUE_DATETIME,
	I_CAL_VALUE_UTCOFFSET = ICAL_VALUE_UTCOFFSET,
	I_CAL_VALUE_CALADDRESS = ICAL_VALUE_CALADDRESS,
	I_CAL_VALUE_UID = ICAL_VALUE_UID,
	I_CAL_VALUE_XMLREFERENCE = ICAL_VALUE_XMLREFERENCE,
	I_CAL_VALUE_NONE = ICAL_VALUE_NONE
} ICalParameterValue;

typedef enum {
	I_CAL_XLICCOMPARETYPE_X = ICAL_XLICCOMPARETYPE_X,
	I_CAL_XLICCOMPARETYPE_EQUAL = ICAL_XLICCOMPARETYPE_EQUAL,
	I_CAL_XLICCOMPARETYPE_NOTEQUAL = ICAL_XLICCOMPARETYPE_NOTEQUAL,
	I_CAL_XLICCOMPARETYPE_LESS = ICAL_XLICCOMPARETYPE_LESS,
	I_CAL_XLICCOMPARETYPE_GREATER = ICAL_XLICCOMPARETYPE_GREATER,
	I_CAL_XLICCOMPARETYPE_LESSEQUAL = ICAL_XLICCOMPARETYPE_LESSEQUAL,
	I_CAL_XLICCOMPARETYPE_GREATEREQUAL = ICAL_XLICCOMPARETYPE_GREATEREQUAL,
	I_CAL_XLICCOMPARETYPE_REGEX = ICAL_XLICCOMPARETYPE_REGEX,
	I_CAL_XLICCOMPARETYPE_ISNULL = ICAL_XLICCOMPARETYPE_ISNULL,
	I_CAL_XLICCOMPARETYPE_ISNOTNULL = ICAL_XLICCOMPARETYPE_ISNOTNULL,
	I_CAL_XLICCOMPARETYPE_NONE = ICAL_XLICCOMPARETYPE_NONE
} ICalParameterXliccomparetype;

typedef enum {
	I_CAL_XLICERRORTYPE_X = ICAL_XLICERRORTYPE_X,
	I_CAL_XLICERRORTYPE_COMPONENTPARSEERROR = ICAL_XLICERRORTYPE_COMPONENTPARSEERROR,
	I_CAL_XLICERRORTYPE_PROPERTYPARSEERROR = ICAL_XLICERRORTYPE_PROPERTYPARSEERROR,
	I_CAL_XLICERRORTYPE_PARAMETERNAMEPARSEERROR = ICAL_XLICERRORTYPE_PARAMETERNAMEPARSEERROR,
	I_CAL_XLICERRORTYPE_PARAMETERVALUEPARSEERROR = ICAL_XLICERRORTYPE_PARAMETERVALUEPARSEERROR,
	I_CAL_XLICERRORTYPE_VALUEPARSEERROR = ICAL_XLICERRORTYPE_VALUEPARSEERROR,
	I_CAL_XLICERRORTYPE_INVALIDITIP = ICAL_XLICERRORTYPE_INVALIDITIP,
	I_CAL_XLICERRORTYPE_UNKNOWNVCALPROPERROR = ICAL_XLICERRORTYPE_UNKNOWNVCALPROPERROR,
	I_CAL_XLICERRORTYPE_MIMEPARSEERROR = ICAL_XLICERRORTYPE_MIMEPARSEERROR,
	I_CAL_XLICERRORTYPE_VCALPROPPARSEERROR = ICAL_XLICERRORTYPE_VCALPROPPARSEERROR,
	I_CAL_XLICERRORTYPE_NONE = ICAL_XLICERRORTYPE_NONE
} ICalParameterXlicerrortype;


LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_enum_to_string	(gint e);

LIBICAL_ICAL_EXPORT
gint 		i_cal_parameter_enum_from_string
						(const gchar *str);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_actionparam	(ICalParameterAction value);

LIBICAL_ICAL_EXPORT
ICalParameterAction 
		i_cal_parameter_get_actionparam	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_actionparam	(ICalParameter *self,
						 ICalParameterAction value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_altrep	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_altrep	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_altrep	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_charset	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_charset	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_charset	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_cn		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_cn		(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_cn		(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_cutype	(ICalParameterCutype value);

LIBICAL_ICAL_EXPORT
ICalParameterCutype 
		i_cal_parameter_get_cutype	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_cutype	(ICalParameter *self,
						 ICalParameterCutype value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_delegatedfrom
						(const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_delegatedfrom_list
						(const ICalStrArray *value);

LIBICAL_ICAL_EXPORT
ICalStrArray *	i_cal_parameter_get_delegatedfrom
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_delegatedfrom
						(ICalParameter *self,
						 const ICalStrArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_parameter_get_delegatedfrom_size
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_delegatedfrom_nth
						(const ICalParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_add_delegatedfrom
						(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_remove_delegatedfrom
						(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_delegatedto	(const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_delegatedto_list
						(const ICalStrArray *value);

LIBICAL_ICAL_EXPORT
ICalStrArray *	i_cal_parameter_get_delegatedto	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_delegatedto	(ICalParameter *self,
						 const ICalStrArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_parameter_get_delegatedto_size
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_delegatedto_nth
						(const ICalParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_add_delegatedto	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_remove_delegatedto
						(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_derived	(ICalParameterDerived value);

LIBICAL_ICAL_EXPORT
ICalParameterDerived 
		i_cal_parameter_get_derived	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_derived	(ICalParameter *self,
						 ICalParameterDerived value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_dir		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_dir		(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_dir		(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_display	(ICalParameterDisplay value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_display_list
						(const ICalEnumArray *value);

LIBICAL_ICAL_EXPORT
ICalEnumArray *	i_cal_parameter_get_display	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_display	(ICalParameter *self,
						 const ICalEnumArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_parameter_get_display_size
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
ICalParameterDisplay 
		i_cal_parameter_get_display_nth	(const ICalParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_add_display	(ICalParameter *self,
						 ICalParameterDisplay value,
						 const gchar *x_value);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_remove_display	(ICalParameter *self,
						 ICalParameterDisplay value,
						 const gchar *x_value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_email	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_email	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_email	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_enable	(ICalParameterEnable value);

LIBICAL_ICAL_EXPORT
ICalParameterEnable 
		i_cal_parameter_get_enable	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_enable	(ICalParameter *self,
						 ICalParameterEnable value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_encoding	(ICalParameterEncoding value);

LIBICAL_ICAL_EXPORT
ICalParameterEncoding 
		i_cal_parameter_get_encoding	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_encoding	(ICalParameter *self,
						 ICalParameterEncoding value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_fbtype	(ICalParameterFbtype value);

LIBICAL_ICAL_EXPORT
ICalParameterFbtype 
		i_cal_parameter_get_fbtype	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_fbtype	(ICalParameter *self,
						 ICalParameterFbtype value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_feature	(ICalParameterFeature value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_feature_list
						(const ICalEnumArray *value);

LIBICAL_ICAL_EXPORT
ICalEnumArray *	i_cal_parameter_get_feature	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_feature	(ICalParameter *self,
						 const ICalEnumArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_parameter_get_feature_size
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
ICalParameterFeature 
		i_cal_parameter_get_feature_nth	(const ICalParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_add_feature	(ICalParameter *self,
						 ICalParameterFeature value,
						 const gchar *x_value);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_remove_feature	(ICalParameter *self,
						 ICalParameterFeature value,
						 const gchar *x_value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_filename	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_filename	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_filename	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_fmttype	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_fmttype	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_fmttype	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_gap		(const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalDuration *	i_cal_parameter_get_gap		(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_gap		(ICalParameter *self,
						 const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_iana	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_iana	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_iana	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_id		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_id		(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_id		(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_label	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_label	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_label	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_language	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_language	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_language	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_latency	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_latency	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_latency	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_linkrel	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_linkrel	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_linkrel	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_local	(ICalParameterLocal value);

LIBICAL_ICAL_EXPORT
ICalParameterLocal 
		i_cal_parameter_get_local	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_local	(ICalParameter *self,
						 ICalParameterLocal value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_localize	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_localize	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_localize	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_managedid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_managedid	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_managedid	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_member	(const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_member_list	(const ICalStrArray *value);

LIBICAL_ICAL_EXPORT
ICalStrArray *	i_cal_parameter_get_member	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_member	(ICalParameter *self,
						 const ICalStrArray *value);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_parameter_get_member_size	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_member_nth	(const ICalParameter *self,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_add_member	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_remove_member	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_modified	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_modified	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_modified	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_options	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_options	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_options	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_order	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_parameter_get_order	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_order	(ICalParameter *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_partstat	(ICalParameterPartstat value);

LIBICAL_ICAL_EXPORT
ICalParameterPartstat 
		i_cal_parameter_get_partstat	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_partstat	(ICalParameter *self,
						 ICalParameterPartstat value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_patchaction	(ICalParameterPatchaction value);

LIBICAL_ICAL_EXPORT
ICalParameterPatchaction 
		i_cal_parameter_get_patchaction	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_patchaction	(ICalParameter *self,
						 ICalParameterPatchaction value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_publiccomment
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_publiccomment
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_publiccomment
						(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_range	(ICalParameterRange value);

LIBICAL_ICAL_EXPORT
ICalParameterRange 
		i_cal_parameter_get_range	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_range	(ICalParameter *self,
						 ICalParameterRange value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_reason	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_reason	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_reason	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_related	(ICalParameterRelated value);

LIBICAL_ICAL_EXPORT
ICalParameterRelated 
		i_cal_parameter_get_related	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_related	(ICalParameter *self,
						 ICalParameterRelated value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_reltype	(ICalParameterReltype value);

LIBICAL_ICAL_EXPORT
ICalParameterReltype 
		i_cal_parameter_get_reltype	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_reltype	(ICalParameter *self,
						 ICalParameterReltype value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_required	(ICalParameterRequired value);

LIBICAL_ICAL_EXPORT
ICalParameterRequired 
		i_cal_parameter_get_required	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_required	(ICalParameter *self,
						 ICalParameterRequired value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_response	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_parameter_get_response	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_response	(ICalParameter *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_role	(ICalParameterRole value);

LIBICAL_ICAL_EXPORT
ICalParameterRole 
		i_cal_parameter_get_role	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_role	(ICalParameter *self,
						 ICalParameterRole value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_rsvp	(ICalParameterRsvp value);

LIBICAL_ICAL_EXPORT
ICalParameterRsvp 
		i_cal_parameter_get_rsvp	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_rsvp	(ICalParameter *self,
						 ICalParameterRsvp value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_scheduleagent
						(ICalParameterScheduleagent value);

LIBICAL_ICAL_EXPORT
ICalParameterScheduleagent 
		i_cal_parameter_get_scheduleagent
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_scheduleagent
						(ICalParameter *self,
						 ICalParameterScheduleagent value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_scheduleforcesend
						(ICalParameterScheduleforcesend value);

LIBICAL_ICAL_EXPORT
ICalParameterScheduleforcesend 
		i_cal_parameter_get_scheduleforcesend
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_scheduleforcesend
						(ICalParameter *self,
						 ICalParameterScheduleforcesend value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_schedulestatus
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_schedulestatus
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_schedulestatus
						(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_schema	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_schema	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_schema	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_sentby	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_sentby	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_sentby	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_size	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_size	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_size	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_stayinformed
						(ICalParameterStayinformed value);

LIBICAL_ICAL_EXPORT
ICalParameterStayinformed 
		i_cal_parameter_get_stayinformed
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_stayinformed
						(ICalParameter *self,
						 ICalParameterStayinformed value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_substate	(ICalParameterSubstate value);

LIBICAL_ICAL_EXPORT
ICalParameterSubstate 
		i_cal_parameter_get_substate	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_substate	(ICalParameter *self,
						 ICalParameterSubstate value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_tzid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_tzid	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_tzid	(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_value	(ICalParameterValue value);

LIBICAL_ICAL_EXPORT
ICalParameterValue 
		i_cal_parameter_get_value	(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_value	(ICalParameter *self,
						 ICalParameterValue value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_x		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_parameter_get_x		(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_x		(ICalParameter *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_xliccomparetype
						(ICalParameterXliccomparetype value);

LIBICAL_ICAL_EXPORT
ICalParameterXliccomparetype 
		i_cal_parameter_get_xliccomparetype
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_xliccomparetype
						(ICalParameter *self,
						 ICalParameterXliccomparetype value);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_parameter_new_xlicerrortype
						(ICalParameterXlicerrortype value);

LIBICAL_ICAL_EXPORT
ICalParameterXlicerrortype 
		i_cal_parameter_get_xlicerrortype
						(const ICalParameter *self);

LIBICAL_ICAL_EXPORT
void		i_cal_parameter_set_xlicerrortype
						(ICalParameter *self,
						 ICalParameterXlicerrortype value);

G_END_DECLS

#endif /* I_CAL_DERIVED_PARAMETER_H */

//NOLINTEND
