/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_PARAMETER_H
#define I_CAL_VCARD_PARAMETER_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>
#include <libical-glib/i-cal-vcard-derived-value.h>
#include <libical-glib/i-cal-vcard-derived-parameter.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_PARAMETER \
    (i_cal_vcard_parameter_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardParameter, i_cal_vcard_parameter, I_CAL_VCARD, PARAMETER, ICalObject)

/**
 * ICalVcardParameter:
 *
 * This is the ICalVcardParameter instance.
 */

/**
 * ICalVcardParameterClass:
 *
 * This is the ICalVcardParameter class.
 */
struct _ICalVcardParameterClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new	(ICalVcardParameterKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_clone	(const ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_from_string
						(const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardParameter *
		i_cal_vcard_parameter_new_from_value_string
						(ICalVcardParameterKind kind,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_value_from_string
						(ICalVcardParameter *param,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_add_value_from_string
						(ICalVcardParameter *param,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_free	(ICalVcardParameter *parameter);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_parameter_as_vcard_string
						(ICalVcardParameter *parameter);

LIBICAL_ICAL_EXPORT
ICalVcardParameterKind 
		i_cal_vcard_parameter_isa	(ICalVcardParameter *parameter);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_parameter_isa_parameter
						(ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_xname	(ICalVcardParameter *param,
						 const gchar *v);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_xname	(ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_xvalue
						(ICalVcardParameter *param,
						 const gchar *v);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_xvalue
						(ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_iana_name
						(ICalVcardParameter *param,
						 const gchar *v);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_iana_name
						(ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parameter_set_iana_value
						(ICalVcardParameter *param,
						 const gchar *v);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_get_iana_value
						(ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_parameter_has_same_name
						(ICalVcardParameter *param1,
						 ICalVcardParameter *param2);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_parameter_kind_to_string
						(ICalVcardParameterKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardParameterKind 
		i_cal_vcard_parameter_string_to_kind
						(const gchar *string);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_parameter_kind_is_valid
						(const ICalVcardParameterKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardValueKind 
		i_cal_vcard_parameter_kind_value_kind
						(ICalVcardParameterKind kind,
						 gboolean *out_is_multivalued);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_parameter_is_multivalued
						(const ICalVcardParameter *param);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_parameter_is_structured
						(const ICalVcardParameter *param);

G_END_DECLS

#endif /* I_CAL_VCARD_PARAMETER_H */

//NOLINTEND
