/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_GEO_H
#define I_CAL_VCARD_GEO_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_GEO \
    (i_cal_vcard_geo_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardGeo, i_cal_vcard_geo, I_CAL_VCARD, GEO, ICalObject)

/**
 * ICalVcardGeo:
 *
 * This is the ICalVcardGeo instance.
 */

/**
 * ICalVcardGeoClass:
 *
 * This is the ICalVcardGeo class.
 */
struct _ICalVcardGeoClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
vcardgeotype 	priv_i_cal_vcard_null_geo	(void);

LIBICAL_ICAL_EXPORT
ICalVcardGeo *	i_cal_vcard_geo_new_uri		(const gchar *uri);

LIBICAL_ICAL_EXPORT
ICalVcardGeo *	i_cal_vcard_geo_new_coords	(const gchar *lat,
						 const gchar *lon);

LIBICAL_ICAL_EXPORT
ICalVcardGeo *	i_cal_vcard_geo_clone		(const ICalVcardGeo *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_geo_get_uri		(const ICalVcardGeo *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_geo_set_uri		(ICalVcardGeo *self,
						 const gchar *uri);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_geo_get_coords	(const ICalVcardGeo *self,
						 const gchar **out_lat,
						 const gchar **out_lon);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_geo_get_coord_lat	(const ICalVcardGeo *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_geo_get_coord_lon	(const ICalVcardGeo *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_geo_set_coords	(ICalVcardGeo *self,
						 const gchar *lat,
						 const gchar *lon);

G_END_DECLS

#endif /* I_CAL_VCARD_GEO_H */

//NOLINTEND
