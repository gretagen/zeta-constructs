/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_TIME_H
#define I_CAL_VCARD_TIME_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_TIME \
    (i_cal_vcard_time_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardTime, i_cal_vcard_time, I_CAL_VCARD, TIME, ICalObject)

/**
 * ICalVcardTime:
 *
 * This is the ICalVcardTime instance.
 */

/**
 * ICalVcardTimeClass:
 *
 * This is the ICalVcardTime class.
 */
struct _ICalVcardTimeClass {
    /*< private >*/
    ICalObjectClass parent;
};
typedef enum {
	I_CAL_VCARD_TIME_BARE_TIME = VCARDTIME_BARE_TIME,
	I_CAL_VCARD_TIME_AS_V4 = VCARDTIME_AS_V4
} ICalVcardTimeConvertFlags;


LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new		(void);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_clone		(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new_null_date	(void);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new_null_time	(void);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new_null_timestamp
						(void);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new_null_datetime
						(void);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new_current_utc_time
						(void);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_null_datetime
						(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_time	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_date	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_datetime	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_timestamp	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_utc		(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_leap_year	(gint year);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_time_is_valid_time	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_time_as_vcard_string
						(const ICalVcardTime *self,
						 guint flags);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_time_new_from_string
						(const gchar *str,
						 gboolean is_bare_time);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_year	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_year	(ICalVcardTime *self,
						 gint year);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_month	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_month	(ICalVcardTime *self,
						 gint month);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_day	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_day	(ICalVcardTime *self,
						 gint day);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_hour	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_hour	(ICalVcardTime *self,
						 gint hour);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_minute	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_minute	(ICalVcardTime *self,
						 gint minute);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_second	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_second	(ICalVcardTime *self,
						 gint second);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_time_get_utc_offset	(const ICalVcardTime *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_utc_offset	(ICalVcardTime *self,
						 gint utc_offset);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_get_date	(const ICalVcardTime *self,
						 gint *year,
						 gint *month,
						 gint *day);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_date	(ICalVcardTime *self,
						 gint year,
						 gint month,
						 gint day);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_get_time	(const ICalVcardTime *self,
						 gint *hour,
						 gint *minute,
						 gint *second);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_time_set_time	(ICalVcardTime *self,
						 gint hour,
						 gint minute,
						 gint second);

G_END_DECLS

#endif /* I_CAL_VCARD_TIME_H */

//NOLINTEND
