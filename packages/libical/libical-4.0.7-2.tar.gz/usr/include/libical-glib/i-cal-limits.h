/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_LIMITS_H
#define I_CAL_LIMITS_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

/**
 * ICalLimitsKind:
 * The types of limits
 */
typedef enum {
	I_CAL_LIMIT_PARSE_FAILURES = ICAL_LIMIT_PARSE_FAILURES,
	I_CAL_LIMIT_PARSE_SEARCH = ICAL_LIMIT_PARSE_SEARCH,
	I_CAL_LIMIT_PARSE_FAILURE_ERROR_MESSAGES = ICAL_LIMIT_PARSE_FAILURE_ERROR_MESSAGES,
	I_CAL_LIMIT_PROPERTIES = ICAL_LIMIT_PROPERTIES,
	I_CAL_LIMIT_PARAMETERS = ICAL_LIMIT_PARAMETERS,
	I_CAL_LIMIT_VALUE_CHARS = ICAL_LIMIT_VALUE_CHARS,
	I_CAL_LIMIT_PROPERTY_VALUES = ICAL_LIMIT_PROPERTY_VALUES,
	I_CAL_LIMIT_RECURRENCE_SEARCH = ICAL_LIMIT_RECURRENCE_SEARCH,
	I_CAL_LIMIT_RECURRENCE_TIME_STANDING_STILL = ICAL_LIMIT_RECURRENCE_TIME_STANDING_STILL,
	I_CAL_LIMIT_RRULE_SEARCH = ICAL_LIMIT_RRULE_SEARCH
} ICalLimitsKind;


LIBICAL_ICAL_EXPORT
void		i_cal_limit_set			(ICalLimitsKind kind,
						 size_t limit);

LIBICAL_ICAL_EXPORT
size_t 		i_cal_limit_get			(ICalLimitsKind kind);

G_END_DECLS

#endif /* I_CAL_LIMITS_H */

//NOLINTEND
