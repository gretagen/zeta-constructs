/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_PARSER_H
#define I_CAL_VCARD_PARSER_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

typedef vcardvalue_kind (*ICalVcardXpropValueKindFunc)(const char *name, gpointer data);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_parser_parse_string	(const char *str);

LIBICAL_ICAL_EXPORT
const char *	i_cal_vcard_parser_errstr	(int err);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_parser_set_xprop_value_kind
						(ICalVcardXpropValueKindFunc callback,
						 gpointer data);

G_END_DECLS

#endif /* I_CAL_VCARD_PARSER_H */

//NOLINTEND
