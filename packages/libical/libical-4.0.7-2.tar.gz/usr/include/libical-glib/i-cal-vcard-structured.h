/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_STRUCTURED_H
#define I_CAL_VCARD_STRUCTURED_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_STRUCTURED \
    (i_cal_vcard_structured_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardStructured, i_cal_vcard_structured, I_CAL_VCARD, STRUCTURED, ICalObject)

/**
 * ICalVcardStructured:
 *
 * This is the ICalVcardStructured instance.
 */

/**
 * ICalVcardStructuredClass:
 *
 * This is the ICalVcardStructured class.
 */
struct _ICalVcardStructuredClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_structured_new	(guint num_fields);

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_structured_new_from_string
						(const gchar *str);

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_structured_clone	(const ICalVcardStructured *self);

LIBICAL_ICAL_EXPORT
guint 		i_cal_vcard_structured_get_num_fields
						(const ICalVcardStructured *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_structured_set_num_fields
						(ICalVcardStructured *self,
						 guint num_fields);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_structured_get_field_at
						(ICalVcardStructured *self,
						 guint position);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_structured_set_field_at
						(ICalVcardStructured *self,
						 guint position,
						 const ICalVcardStrArray *field);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_structured_as_vcard_string
						(ICalVcardStructured *self,
						 gboolean is_param);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_structured_ref	(ICalVcardStructured *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_structured_unref	(ICalVcardStructured *self);

G_END_DECLS

#endif /* I_CAL_VCARD_STRUCTURED_H */

//NOLINTEND
