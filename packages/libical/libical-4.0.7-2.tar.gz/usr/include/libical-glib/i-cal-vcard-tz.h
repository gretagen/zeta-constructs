/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_TZ_H
#define I_CAL_VCARD_TZ_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_TZ \
    (i_cal_vcard_tz_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardTz, i_cal_vcard_tz, I_CAL_VCARD, TZ, ICalObject)

/**
 * ICalVcardTz:
 *
 * This is the ICalVcardTz instance.
 */

/**
 * ICalVcardTzClass:
 *
 * This is the ICalVcardTz class.
 */
struct _ICalVcardTzClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
vcardtztype 	priv_i_cal_vcard_null_tz	(void);

LIBICAL_ICAL_EXPORT
ICalVcardTz *	i_cal_vcard_tz_new_tzid		(const gchar *tzid);

LIBICAL_ICAL_EXPORT
ICalVcardTz *	i_cal_vcard_tz_new_uri		(const gchar *uri);

LIBICAL_ICAL_EXPORT
ICalVcardTz *	i_cal_vcard_tz_new_utc_offset	(gint utc_offset);

LIBICAL_ICAL_EXPORT
ICalVcardTz *	i_cal_vcard_tz_clone		(const ICalVcardTz *self);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_tz_get_tzid		(const ICalVcardTz *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_tz_set_tzid		(ICalVcardTz *self,
						 const gchar *tzid);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_tz_get_uri		(const ICalVcardTz *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_tz_set_uri		(ICalVcardTz *self,
						 const gchar *uri);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_tz_get_utc_offset	(const ICalVcardTz *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_tz_set_utc_offset	(ICalVcardTz *self,
						 gint utc_offset);

G_END_DECLS

#endif /* I_CAL_VCARD_TZ_H */

//NOLINTEND
