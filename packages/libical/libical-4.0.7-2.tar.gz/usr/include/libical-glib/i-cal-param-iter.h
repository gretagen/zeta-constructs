/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_PARAM_ITER_H
#define I_CAL_PARAM_ITER_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_TYPE_PARAM_ITER \
    (i_cal_param_iter_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalParamIter, i_cal_param_iter, I_CAL, PARAM_ITER, ICalObject)

/**
 * ICalParamIter:
 *
 * This is the ICalParamIter instance.
 */

/**
 * ICalParamIterClass:
 *
 * This is the ICalParamIter class.
 */
struct _ICalParamIterClass {
    /*< private >*/
    ICalObjectClass parent;
};

G_END_DECLS

#endif /* I_CAL_PARAM_ITER_H */

//NOLINTEND
