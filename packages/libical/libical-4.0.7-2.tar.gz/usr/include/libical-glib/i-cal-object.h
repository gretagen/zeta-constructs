/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_OBJECT_H
#define I_CAL_OBJECT_H

#include <stdio.h>
#include <glib.h>
#include <glib-object.h>
#include <libical/ical.h>
#include <libical/libical_ical_export.h>
#if defined(LIBICAL_GLIB_COMPILATION)
#include "libicalvcard/vcard.h"
#include "libicalvcard/libical_vcard_export.h"
#else
#include <libical/vcard.h>
#include <libical/libical_vcard_export.h>
#endif
#include <libical/icaltime_p.h>

#define I_CAL_TYPE_OBJECT \
    (i_cal_object_get_type ())
LIBICAL_ICAL_EXPORT
G_DECLARE_DERIVABLE_TYPE(ICalObject, i_cal_object, I_CAL, OBJECT, GObject)

/* it's the same as G_DECLARE_DERIVABLE_TYPE() (as of glib 2.82), only without
   typedef for the ModuleObjName, because it's in the i-cal-forward-declarations.h */
#define I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ModuleObjName, module_obj_name, MODULE, OBJ_NAME, ParentName) \
  GType module_obj_name##_get_type (void);                                                               \
  G_GNUC_BEGIN_IGNORE_DEPRECATIONS                                                                       \
  /*typedef struct _##ModuleObjName ModuleObjName;*/                                                     \
  typedef struct _##ModuleObjName##Class ModuleObjName##Class;                                           \
  struct _##ModuleObjName { ParentName parent_instance; };                                               \
                                                                                                         \
  _GLIB_DEFINE_AUTOPTR_CHAINUP (ModuleObjName, ParentName)                                               \
  G_DEFINE_AUTOPTR_CLEANUP_FUNC (ModuleObjName##Class, g_type_class_unref)                               \
                                                                                                         \
  G_GNUC_UNUSED static inline ModuleObjName * MODULE##_##OBJ_NAME (gpointer ptr) {                       \
    return G_TYPE_CHECK_INSTANCE_CAST (ptr, module_obj_name##_get_type (), ModuleObjName); }             \
  G_GNUC_UNUSED static inline ModuleObjName##Class * MODULE##_##OBJ_NAME##_CLASS (gpointer ptr) {        \
    return G_TYPE_CHECK_CLASS_CAST (ptr, module_obj_name##_get_type (), ModuleObjName##Class); }         \
  G_GNUC_UNUSED static inline gboolean MODULE##_IS_##OBJ_NAME (gpointer ptr) {                           \
    return G_TYPE_CHECK_INSTANCE_TYPE (ptr, module_obj_name##_get_type ()); }                            \
  G_GNUC_UNUSED static inline gboolean MODULE##_IS_##OBJ_NAME##_CLASS (gpointer ptr) {                   \
    return G_TYPE_CHECK_CLASS_TYPE (ptr, module_obj_name##_get_type ()); }                               \
  G_GNUC_UNUSED static inline ModuleObjName##Class * MODULE##_##OBJ_NAME##_GET_CLASS (gpointer ptr) {    \
    return G_TYPE_INSTANCE_GET_CLASS (ptr, module_obj_name##_get_type (), ModuleObjName##Class); }       \
  G_GNUC_END_IGNORE_DEPRECATIONS

G_BEGIN_DECLS
/**
 * ICalObject:
 *
 * This is an ICalObject instance struct.
 */

/**
 * ICalObjectClass:
 *
 * This is an ICalObject class struct.
 */

struct _ICalObjectClass
{
    /*< private > */
    GObjectClass parent_class;
};

LIBICAL_ICAL_EXPORT gpointer i_cal_object_construct(GType object_type,
                                                    gpointer native,
                                                    GDestroyNotify native_destroy_func,
                                                    gboolean is_global_memory, GObject *owner);

LIBICAL_ICAL_EXPORT gpointer i_cal_object_get_native(ICalObject *iobject);

LIBICAL_ICAL_EXPORT gpointer i_cal_object_steal_native(ICalObject *iobject);

LIBICAL_ICAL_EXPORT gboolean i_cal_object_get_is_global_memory(ICalObject *iobject);

LIBICAL_ICAL_EXPORT GDestroyNotify i_cal_object_get_native_destroy_func(ICalObject *iobject);

LIBICAL_ICAL_EXPORT void i_cal_object_set_native_destroy_func(ICalObject *iobject,
                                                              GDestroyNotify native_destroy_func);

LIBICAL_ICAL_EXPORT void i_cal_object_set_owner(ICalObject *iobject, GObject *owner);

LIBICAL_ICAL_EXPORT GObject *i_cal_object_ref_owner(ICalObject *iobject);

LIBICAL_ICAL_EXPORT void i_cal_object_remove_owner(ICalObject *iobject);

LIBICAL_ICAL_EXPORT void i_cal_object_add_depender(ICalObject *iobject, GObject *depender);

LIBICAL_ICAL_EXPORT void i_cal_object_remove_depender(ICalObject *iobject, GObject *depender);

LIBICAL_ICAL_EXPORT void i_cal_object_set_always_destroy(ICalObject *iobject, gboolean value);

LIBICAL_ICAL_EXPORT gboolean i_cal_object_get_always_destroy(ICalObject *iobject);

LIBICAL_ICAL_EXPORT void i_cal_object_free_global_objects(void);

G_END_DECLS
#endif /* I_CAL_OBJECT_H */
