/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_COMPONENT_H
#define I_CAL_VCARD_COMPONENT_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-vcard-parameter.h>
#include <libical-glib/i-cal-object.h>
#include <libical-glib/i-cal-vcard-derived-value.h>
#include <libical-glib/i-cal-vcard-derived-property.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_COMPONENT \
    (i_cal_vcard_component_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardComponent, i_cal_vcard_component, I_CAL_VCARD, COMPONENT, ICalObject)

/**
 * ICalVcardComponent:
 *
 * This is the ICalVcardComponent instance.
 */

/**
 * ICalVcardComponentClass:
 *
 * This is the ICalVcardComponent class.
 */
struct _ICalVcardComponentClass {
    /*< private >*/
    ICalObjectClass parent;
};
typedef enum {
	I_CAL_VCARD_NO_COMPONENT = VCARD_NO_COMPONENT,
	I_CAL_VCARD_ANY_COMPONENT = VCARD_ANY_COMPONENT,
	I_CAL_VCARD_XROOT_COMPONENT = VCARD_XROOT_COMPONENT,
	I_CAL_VCARD_VCARD_COMPONENT = VCARD_VCARD_COMPONENT,
	I_CAL_VCARD_NUM_COMPONENT_TYPES = VCARD_NUM_COMPONENT_TYPES
} ICalVcardComponentKind;


LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_component_new	(ICalVcardComponentKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_component_clone	(const ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_component_new_from_string
						(const gchar *str);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_free	(ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_component_as_vcard_string
						(ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_component_is_valid	(ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
ICalVcardComponentKind 
		i_cal_vcard_component_isa	(const ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_component_isa_component
						(ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_add_property
						(ICalVcardComponent *component,
						 ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_take_property
						(ICalVcardComponent *component,
						 ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_remove_property
						(ICalVcardComponent *component,
						 ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_component_count_properties
						(ICalVcardComponent *component,
						 ICalVcardPropertyKind kind,
						 gboolean ignore_alts);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_add_component
						(ICalVcardComponent *parent,
						 ICalVcardComponent *child);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_take_component
						(ICalVcardComponent *parent,
						 ICalVcardComponent *child);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_remove_component
						(ICalVcardComponent *parent,
						 ICalVcardComponent *child);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_component_count_components
						(ICalVcardComponent *component,
						 ICalVcardComponentKind kind);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_component_kind_is_valid
						(ICalVcardComponentKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardComponentKind 
		i_cal_vcard_component_kind_from_string
						(const gchar *string);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_component_kind_to_string
						(ICalVcardComponentKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_component_get_current_component
						(ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_component_get_first_component
						(ICalVcardComponent *component,
						 ICalVcardComponentKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_component_get_next_component
						(ICalVcardComponent *component,
						 ICalVcardComponentKind kind);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_property_set_parent	(ICalVcardProperty *property,
						 ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
ICalVcardComponent *
		i_cal_vcard_property_get_parent	(ICalVcardProperty *property);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_component_get_current_property
						(ICalVcardComponent *component);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_component_get_first_property
						(ICalVcardComponent *component,
						 ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardProperty *
		i_cal_vcard_component_get_next_property
						(ICalVcardComponent *component,
						 ICalVcardPropertyKind kind);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_component_check_restrictions
						(ICalVcardComponent *comp);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_component_count_errors
						(ICalVcardComponent *comp);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_strip_errors
						(ICalVcardComponent *comp);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_normalize	(ICalVcardComponent *comp);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_component_transform	(ICalVcardComponent *comp,
						 ICalVcardPropertyVersion version);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyVersion 
		i_cal_vcard_component_get_version
						(ICalVcardComponent *comp);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_component_get_uid	(ICalVcardComponent *comp);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_component_get_fn	(ICalVcardComponent *comp);

G_END_DECLS

#endif /* I_CAL_VCARD_COMPONENT_H */

//NOLINTEND
