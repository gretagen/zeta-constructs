/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_VALUE_H
#define I_CAL_VCARD_VALUE_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <string.h>
#include <libical-glib/i-cal-object.h>
#include <libical-glib/i-cal-vcard-derived-value.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_VALUE \
    (i_cal_vcard_value_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardValue, i_cal_vcard_value, I_CAL_VCARD, VALUE, ICalObject)

/**
 * ICalVcardValue:
 *
 * This is the ICalVcardValue instance.
 */

/**
 * ICalVcardValueClass:
 *
 * This is the ICalVcardValue class.
 */
struct _ICalVcardValueClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new		(ICalVcardValueKind kind);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_clone		(const ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_from_string
						(ICalVcardValueKind kind,
						 const gchar *str);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_free		(ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_value_is_valid	(const ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_value_as_vcard_string
						(const ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
ICalVcardValueKind 
		i_cal_vcard_value_isa		(const ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_value_isa_value	(ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
ICalVcardValueKind 
		i_cal_vcard_value_kind_from_string
						(const gchar *str);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_value_kind_to_string
						(ICalVcardValueKind kind);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_value_kind_is_valid	(ICalVcardValueKind kind);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_reset_kind	(ICalVcardValue *value);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_vcard_value_dequote_text	(const gchar **text,
						 const gchar *separators);

G_END_DECLS

#endif /* I_CAL_VCARD_VALUE_H */

//NOLINTEND
