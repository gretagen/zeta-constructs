/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_STR_ARRAY_H
#define I_CAL_VCARD_STR_ARRAY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


#define I_CAL_VCARD_TYPE_STR_ARRAY \
    (i_cal_vcard_str_array_get_type ())
LIBICAL_ICAL_EXPORT
I_CAL_GLIB_DECLARE_DERIVABLE_TYPE(ICalVcardStrArray, i_cal_vcard_str_array, I_CAL_VCARD, STR_ARRAY, ICalObject)

/**
 * ICalVcardStrArray:
 *
 * This is the ICalVcardStrArray instance.
 */

/**
 * ICalVcardStrArrayClass:
 *
 * This is the ICalVcardStrArray class.
 */
struct _ICalVcardStrArrayClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_str_array_new	(gint increment_size);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_str_array_get_element_at
						(ICalVcardStrArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_str_array_size	(ICalVcardStrArray *array);

LIBICAL_ICAL_EXPORT
gsize 		i_cal_vcard_str_array_find	(ICalVcardStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_str_array_append	(ICalVcardStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_str_array_add	(ICalVcardStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_str_array_remove_element_at
						(ICalVcardStrArray *array,
						 gsize position);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_str_array_remove	(ICalVcardStrArray *array,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_str_array_free	(ICalVcardStrArray *array);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_str_array_sort	(ICalVcardStrArray *array);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_str_array_clone	(ICalVcardStrArray *array);

G_END_DECLS

#endif /* I_CAL_VCARD_STR_ARRAY_H */

//NOLINTEND
