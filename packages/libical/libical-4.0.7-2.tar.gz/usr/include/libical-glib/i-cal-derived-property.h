/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_DERIVED_PROPERTY_H
#define I_CAL_DERIVED_PROPERTY_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>
#include <libical-glib/i-cal-derived-value.h>

G_BEGIN_DECLS

typedef enum {
	I_CAL_ANY_PROPERTY = ICAL_ANY_PROPERTY,
	I_CAL_ACCEPTRESPONSE_PROPERTY = ICAL_ACCEPTRESPONSE_PROPERTY,
	I_CAL_ACKNOWLEDGED_PROPERTY = ICAL_ACKNOWLEDGED_PROPERTY,
	I_CAL_ACTION_PROPERTY = ICAL_ACTION_PROPERTY,
	I_CAL_ALLOWCONFLICT_PROPERTY = ICAL_ALLOWCONFLICT_PROPERTY,
	I_CAL_ATTACH_PROPERTY = ICAL_ATTACH_PROPERTY,
	I_CAL_ATTENDEE_PROPERTY = ICAL_ATTENDEE_PROPERTY,
	I_CAL_BUSYTYPE_PROPERTY = ICAL_BUSYTYPE_PROPERTY,
	I_CAL_CALENDARADDRESS_PROPERTY = ICAL_CALENDARADDRESS_PROPERTY,
	I_CAL_CALID_PROPERTY = ICAL_CALID_PROPERTY,
	I_CAL_CALMASTER_PROPERTY = ICAL_CALMASTER_PROPERTY,
	I_CAL_CALSCALE_PROPERTY = ICAL_CALSCALE_PROPERTY,
	I_CAL_CAPVERSION_PROPERTY = ICAL_CAPVERSION_PROPERTY,
	I_CAL_CARLEVEL_PROPERTY = ICAL_CARLEVEL_PROPERTY,
	I_CAL_CARID_PROPERTY = ICAL_CARID_PROPERTY,
	I_CAL_CATEGORIES_PROPERTY = ICAL_CATEGORIES_PROPERTY,
	I_CAL_CLASS_PROPERTY = ICAL_CLASS_PROPERTY,
	I_CAL_CMD_PROPERTY = ICAL_CMD_PROPERTY,
	I_CAL_COLOR_PROPERTY = ICAL_COLOR_PROPERTY,
	I_CAL_COMMENT_PROPERTY = ICAL_COMMENT_PROPERTY,
	I_CAL_COMPLETED_PROPERTY = ICAL_COMPLETED_PROPERTY,
	I_CAL_COMPONENTS_PROPERTY = ICAL_COMPONENTS_PROPERTY,
	I_CAL_CONFERENCE_PROPERTY = ICAL_CONFERENCE_PROPERTY,
	I_CAL_CONCEPT_PROPERTY = ICAL_CONCEPT_PROPERTY,
	I_CAL_CONTACT_PROPERTY = ICAL_CONTACT_PROPERTY,
	I_CAL_CREATED_PROPERTY = ICAL_CREATED_PROPERTY,
	I_CAL_CSID_PROPERTY = ICAL_CSID_PROPERTY,
	I_CAL_DATEMAX_PROPERTY = ICAL_DATEMAX_PROPERTY,
	I_CAL_DATEMIN_PROPERTY = ICAL_DATEMIN_PROPERTY,
	I_CAL_DECREED_PROPERTY = ICAL_DECREED_PROPERTY,
	I_CAL_DEFAULTCHARSET_PROPERTY = ICAL_DEFAULTCHARSET_PROPERTY,
	I_CAL_DEFAULTLOCALE_PROPERTY = ICAL_DEFAULTLOCALE_PROPERTY,
	I_CAL_DEFAULTTZID_PROPERTY = ICAL_DEFAULTTZID_PROPERTY,
	I_CAL_DEFAULTVCARS_PROPERTY = ICAL_DEFAULTVCARS_PROPERTY,
	I_CAL_DENY_PROPERTY = ICAL_DENY_PROPERTY,
	I_CAL_DESCRIPTION_PROPERTY = ICAL_DESCRIPTION_PROPERTY,
	I_CAL_DTEND_PROPERTY = ICAL_DTEND_PROPERTY,
	I_CAL_DTSTAMP_PROPERTY = ICAL_DTSTAMP_PROPERTY,
	I_CAL_DTSTART_PROPERTY = ICAL_DTSTART_PROPERTY,
	I_CAL_DUE_PROPERTY = ICAL_DUE_PROPERTY,
	I_CAL_DURATION_PROPERTY = ICAL_DURATION_PROPERTY,
	I_CAL_ESTIMATEDDURATION_PROPERTY = ICAL_ESTIMATEDDURATION_PROPERTY,
	I_CAL_EXDATE_PROPERTY = ICAL_EXDATE_PROPERTY,
	I_CAL_EXPAND_PROPERTY = ICAL_EXPAND_PROPERTY,
	I_CAL_EXRULE_PROPERTY = ICAL_EXRULE_PROPERTY,
	I_CAL_FREEBUSY_PROPERTY = ICAL_FREEBUSY_PROPERTY,
	I_CAL_GEO_PROPERTY = ICAL_GEO_PROPERTY,
	I_CAL_GRANT_PROPERTY = ICAL_GRANT_PROPERTY,
	I_CAL_IMAGE_PROPERTY = ICAL_IMAGE_PROPERTY,
	I_CAL_ITIPVERSION_PROPERTY = ICAL_ITIPVERSION_PROPERTY,
	I_CAL_LASTMODIFIED_PROPERTY = ICAL_LASTMODIFIED_PROPERTY,
	I_CAL_LINK_PROPERTY = ICAL_LINK_PROPERTY,
	I_CAL_LOCATION_PROPERTY = ICAL_LOCATION_PROPERTY,
	I_CAL_LOCATIONTYPE_PROPERTY = ICAL_LOCATIONTYPE_PROPERTY,
	I_CAL_MAXCOMPONENTSIZE_PROPERTY = ICAL_MAXCOMPONENTSIZE_PROPERTY,
	I_CAL_MAXDATE_PROPERTY = ICAL_MAXDATE_PROPERTY,
	I_CAL_MAXRESULTS_PROPERTY = ICAL_MAXRESULTS_PROPERTY,
	I_CAL_MAXRESULTSSIZE_PROPERTY = ICAL_MAXRESULTSSIZE_PROPERTY,
	I_CAL_METHOD_PROPERTY = ICAL_METHOD_PROPERTY,
	I_CAL_MINDATE_PROPERTY = ICAL_MINDATE_PROPERTY,
	I_CAL_MULTIPART_PROPERTY = ICAL_MULTIPART_PROPERTY,
	I_CAL_NAME_PROPERTY = ICAL_NAME_PROPERTY,
	I_CAL_ORGANIZER_PROPERTY = ICAL_ORGANIZER_PROPERTY,
	I_CAL_OWNER_PROPERTY = ICAL_OWNER_PROPERTY,
	I_CAL_PARTICIPANTTYPE_PROPERTY = ICAL_PARTICIPANTTYPE_PROPERTY,
	I_CAL_PATCHDELETE_PROPERTY = ICAL_PATCHDELETE_PROPERTY,
	I_CAL_PATCHORDER_PROPERTY = ICAL_PATCHORDER_PROPERTY,
	I_CAL_PATCHPARAMETER_PROPERTY = ICAL_PATCHPARAMETER_PROPERTY,
	I_CAL_PATCHTARGET_PROPERTY = ICAL_PATCHTARGET_PROPERTY,
	I_CAL_PATCHVERSION_PROPERTY = ICAL_PATCHVERSION_PROPERTY,
	I_CAL_PERCENTCOMPLETE_PROPERTY = ICAL_PERCENTCOMPLETE_PROPERTY,
	I_CAL_PERMISSION_PROPERTY = ICAL_PERMISSION_PROPERTY,
	I_CAL_POLLCOMPLETION_PROPERTY = ICAL_POLLCOMPLETION_PROPERTY,
	I_CAL_POLLITEMID_PROPERTY = ICAL_POLLITEMID_PROPERTY,
	I_CAL_POLLMODE_PROPERTY = ICAL_POLLMODE_PROPERTY,
	I_CAL_POLLPROPERTIES_PROPERTY = ICAL_POLLPROPERTIES_PROPERTY,
	I_CAL_POLLWINNER_PROPERTY = ICAL_POLLWINNER_PROPERTY,
	I_CAL_PRIORITY_PROPERTY = ICAL_PRIORITY_PROPERTY,
	I_CAL_PRODID_PROPERTY = ICAL_PRODID_PROPERTY,
	I_CAL_PROXIMITY_PROPERTY = ICAL_PROXIMITY_PROPERTY,
	I_CAL_QUERY_PROPERTY = ICAL_QUERY_PROPERTY,
	I_CAL_QUERYLEVEL_PROPERTY = ICAL_QUERYLEVEL_PROPERTY,
	I_CAL_QUERYID_PROPERTY = ICAL_QUERYID_PROPERTY,
	I_CAL_QUERYNAME_PROPERTY = ICAL_QUERYNAME_PROPERTY,
	I_CAL_RDATE_PROPERTY = ICAL_RDATE_PROPERTY,
	I_CAL_RECURACCEPTED_PROPERTY = ICAL_RECURACCEPTED_PROPERTY,
	I_CAL_RECUREXPAND_PROPERTY = ICAL_RECUREXPAND_PROPERTY,
	I_CAL_RECURLIMIT_PROPERTY = ICAL_RECURLIMIT_PROPERTY,
	I_CAL_RECURRENCEID_PROPERTY = ICAL_RECURRENCEID_PROPERTY,
	I_CAL_REFRESHINTERVAL_PROPERTY = ICAL_REFRESHINTERVAL_PROPERTY,
	I_CAL_REFID_PROPERTY = ICAL_REFID_PROPERTY,
	I_CAL_RELATEDTO_PROPERTY = ICAL_RELATEDTO_PROPERTY,
	I_CAL_RELCALID_PROPERTY = ICAL_RELCALID_PROPERTY,
	I_CAL_REPEAT_PROPERTY = ICAL_REPEAT_PROPERTY,
	I_CAL_REPLYURL_PROPERTY = ICAL_REPLYURL_PROPERTY,
	I_CAL_REQUESTSTATUS_PROPERTY = ICAL_REQUESTSTATUS_PROPERTY,
	I_CAL_RESOURCES_PROPERTY = ICAL_RESOURCES_PROPERTY,
	I_CAL_RESOURCETYPE_PROPERTY = ICAL_RESOURCETYPE_PROPERTY,
	I_CAL_RESPONSE_PROPERTY = ICAL_RESPONSE_PROPERTY,
	I_CAL_RESTRICTION_PROPERTY = ICAL_RESTRICTION_PROPERTY,
	I_CAL_RRULE_PROPERTY = ICAL_RRULE_PROPERTY,
	I_CAL_SCOPE_PROPERTY = ICAL_SCOPE_PROPERTY,
	I_CAL_SEQUENCE_PROPERTY = ICAL_SEQUENCE_PROPERTY,
	I_CAL_SOURCE_PROPERTY = ICAL_SOURCE_PROPERTY,
	I_CAL_STATUS_PROPERTY = ICAL_STATUS_PROPERTY,
	I_CAL_STORESEXPANDED_PROPERTY = ICAL_STORESEXPANDED_PROPERTY,
	I_CAL_STRUCTUREDDATA_PROPERTY = ICAL_STRUCTUREDDATA_PROPERTY,
	I_CAL_STYLEDDESCRIPTION_PROPERTY = ICAL_STYLEDDESCRIPTION_PROPERTY,
	I_CAL_SUMMARY_PROPERTY = ICAL_SUMMARY_PROPERTY,
	I_CAL_TARGET_PROPERTY = ICAL_TARGET_PROPERTY,
	I_CAL_TASKMODE_PROPERTY = ICAL_TASKMODE_PROPERTY,
	I_CAL_TRANSP_PROPERTY = ICAL_TRANSP_PROPERTY,
	I_CAL_TRIGGER_PROPERTY = ICAL_TRIGGER_PROPERTY,
	I_CAL_TZID_PROPERTY = ICAL_TZID_PROPERTY,
	I_CAL_TZIDALIASOF_PROPERTY = ICAL_TZIDALIASOF_PROPERTY,
	I_CAL_TZNAME_PROPERTY = ICAL_TZNAME_PROPERTY,
	I_CAL_TZOFFSETFROM_PROPERTY = ICAL_TZOFFSETFROM_PROPERTY,
	I_CAL_TZOFFSETTO_PROPERTY = ICAL_TZOFFSETTO_PROPERTY,
	I_CAL_TZUNTIL_PROPERTY = ICAL_TZUNTIL_PROPERTY,
	I_CAL_TZURL_PROPERTY = ICAL_TZURL_PROPERTY,
	I_CAL_UID_PROPERTY = ICAL_UID_PROPERTY,
	I_CAL_URL_PROPERTY = ICAL_URL_PROPERTY,
	I_CAL_VERSION_PROPERTY = ICAL_VERSION_PROPERTY,
	I_CAL_VOTER_PROPERTY = ICAL_VOTER_PROPERTY,
	I_CAL_X_PROPERTY = ICAL_X_PROPERTY,
	I_CAL_XLICCLASS_PROPERTY = ICAL_XLICCLASS_PROPERTY,
	I_CAL_XLICCLUSTERCOUNT_PROPERTY = ICAL_XLICCLUSTERCOUNT_PROPERTY,
	I_CAL_XLICERROR_PROPERTY = ICAL_XLICERROR_PROPERTY,
	I_CAL_XLICMIMECHARSET_PROPERTY = ICAL_XLICMIMECHARSET_PROPERTY,
	I_CAL_XLICMIMECID_PROPERTY = ICAL_XLICMIMECID_PROPERTY,
	I_CAL_XLICMIMECONTENTTYPE_PROPERTY = ICAL_XLICMIMECONTENTTYPE_PROPERTY,
	I_CAL_XLICMIMEENCODING_PROPERTY = ICAL_XLICMIMEENCODING_PROPERTY,
	I_CAL_XLICMIMEFILENAME_PROPERTY = ICAL_XLICMIMEFILENAME_PROPERTY,
	I_CAL_XLICMIMEOPTINFO_PROPERTY = ICAL_XLICMIMEOPTINFO_PROPERTY,
	I_CAL_IANA_PROPERTY = ICAL_IANA_PROPERTY,
	I_CAL_NO_PROPERTY = ICAL_NO_PROPERTY
} ICalPropertyKind;


LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_acceptresponse
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_acceptresponse
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_acceptresponse
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_acknowledged	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_acknowledged	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_acknowledged	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_action	(ICalPropertyAction value);

LIBICAL_ICAL_EXPORT
ICalPropertyAction 
		i_cal_property_get_action	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_action	(ICalProperty *self,
						 ICalPropertyAction value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_allowconflict
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_allowconflict
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_allowconflict
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_attach	(const ICalAttach *value);

LIBICAL_ICAL_EXPORT
ICalAttach *	i_cal_property_get_attach	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_attach	(ICalProperty *self,
						 const ICalAttach *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_attendee	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_attendee	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_attendee	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_busytype	(ICalPropertyBusytype value);

LIBICAL_ICAL_EXPORT
ICalPropertyBusytype 
		i_cal_property_get_busytype	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_busytype	(ICalProperty *self,
						 ICalPropertyBusytype value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_calendaraddress
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_calendaraddress
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_calendaraddress
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_calid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_calid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_calid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_calmaster	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_calmaster	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_calmaster	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_calscale	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_calscale	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_calscale	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_capversion	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_capversion	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_capversion	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_carlevel	(ICalPropertyCarlevel value);

LIBICAL_ICAL_EXPORT
ICalPropertyCarlevel 
		i_cal_property_get_carlevel	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_carlevel	(ICalProperty *self,
						 ICalPropertyCarlevel value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_carid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_carid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_carid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_categories	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_categories	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_categories	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_class	(ICalPropertyClassenum value);

LIBICAL_ICAL_EXPORT
ICalPropertyClassenum 
		i_cal_property_get_class	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_class	(ICalProperty *self,
						 ICalPropertyClassenum value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_cmd		(ICalPropertyCmd value);

LIBICAL_ICAL_EXPORT
ICalPropertyCmd 	i_cal_property_get_cmd		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_cmd		(ICalProperty *self,
						 ICalPropertyCmd value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_comment	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_comment	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_comment	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_color	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_color	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_color	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_completed	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_completed	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_completed	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_components	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_components	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_components	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_concept	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_concept	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_concept	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_conference	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_conference	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_conference	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_contact	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_contact	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_contact	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_created	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_created	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_created	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_csid		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_csid		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_csid		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_datemax	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_datemax	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_datemax	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_datemin	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_datemin	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_datemin	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_decreed	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_decreed	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_decreed	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_defaultcharset
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_defaultcharset
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_defaultcharset
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_defaultlocale
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_defaultlocale
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_defaultlocale
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_defaulttzid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_defaulttzid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_defaulttzid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_defaultvcars	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_defaultvcars	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_defaultvcars	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_deny		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_deny		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_deny		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_description	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_description	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_description	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_dtend	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_dtend	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_dtend	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_dtstamp	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_dtstamp	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_dtstamp	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_dtstart	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_dtstart	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_dtstart	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_due		(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_due		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_due		(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_duration	(const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalDuration *	i_cal_property_get_duration	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_duration	(ICalProperty *self,
						 const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_estimatedduration
						(const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalDuration *	i_cal_property_get_estimatedduration
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_estimatedduration
						(ICalProperty *self,
						 const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_exdate	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_exdate	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_exdate	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_expand	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_expand	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_expand	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_exrule	(const ICalRecurrence *value);

LIBICAL_ICAL_EXPORT
ICalRecurrence *
		i_cal_property_get_exrule	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_exrule	(ICalProperty *self,
						 const ICalRecurrence *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_freebusy	(const ICalPeriod *value);

LIBICAL_ICAL_EXPORT
ICalPeriod *	i_cal_property_get_freebusy	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_freebusy	(ICalProperty *self,
						 const ICalPeriod *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_geo		(const ICalGeo *value);

LIBICAL_ICAL_EXPORT
ICalGeo *	i_cal_property_get_geo		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_geo		(ICalProperty *self,
						 const ICalGeo *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_grant	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_grant	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_grant	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_iana		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_iana		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_iana		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_image	(const ICalAttach *value);

LIBICAL_ICAL_EXPORT
ICalAttach *	i_cal_property_get_image	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_image	(ICalProperty *self,
						 const ICalAttach *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_itipversion	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_itipversion	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_itipversion	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_lastmodified	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_lastmodified	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_lastmodified	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_link		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_link		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_link		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_location	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_location	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_location	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_locationtype	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_locationtype	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_locationtype	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_maxcomponentsize
						(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_maxcomponentsize
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_maxcomponentsize
						(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_maxdate	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_maxdate	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_maxdate	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_maxresults	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_maxresults	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_maxresults	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_maxresultssize
						(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_maxresultssize
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_maxresultssize
						(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_method	(ICalPropertyMethod value);

LIBICAL_ICAL_EXPORT
ICalPropertyMethod 
		i_cal_property_get_method	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_method	(ICalProperty *self,
						 ICalPropertyMethod value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_mindate	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_mindate	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_mindate	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_multipart	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_multipart	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_multipart	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_name		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_name		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_name		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_organizer	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_organizer	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_organizer	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_owner	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_owner	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_owner	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_participanttype
						(ICalPropertyParticipanttype value);

LIBICAL_ICAL_EXPORT
ICalPropertyParticipanttype 
		i_cal_property_get_participanttype
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_participanttype
						(ICalProperty *self,
						 ICalPropertyParticipanttype value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_patchdelete	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_patchdelete	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_patchdelete	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_patchorder	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_patchorder	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_patchorder	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_patchparameter
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_patchparameter
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_patchparameter
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_patchtarget	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_patchtarget	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_patchtarget	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_patchversion	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_patchversion	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_patchversion	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_percentcomplete
						(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_percentcomplete
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_percentcomplete
						(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_permission	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_permission	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_permission	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_pollcompletion
						(ICalPropertyPollcompletion value);

LIBICAL_ICAL_EXPORT
ICalPropertyPollcompletion 
		i_cal_property_get_pollcompletion
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_pollcompletion
						(ICalProperty *self,
						 ICalPropertyPollcompletion value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_pollitemid	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_pollitemid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_pollitemid	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_pollmode	(ICalPropertyPollmode value);

LIBICAL_ICAL_EXPORT
ICalPropertyPollmode 
		i_cal_property_get_pollmode	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_pollmode	(ICalProperty *self,
						 ICalPropertyPollmode value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_pollproperties
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_pollproperties
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_pollproperties
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_pollwinner	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_pollwinner	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_pollwinner	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_priority	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_priority	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_priority	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_prodid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_prodid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_prodid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_proximity	(ICalPropertyProximity value);

LIBICAL_ICAL_EXPORT
ICalPropertyProximity 
		i_cal_property_get_proximity	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_proximity	(ICalProperty *self,
						 ICalPropertyProximity value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_query	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_query	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_query	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_querylevel	(ICalPropertyQuerylevel value);

LIBICAL_ICAL_EXPORT
ICalPropertyQuerylevel 
		i_cal_property_get_querylevel	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_querylevel	(ICalProperty *self,
						 ICalPropertyQuerylevel value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_queryid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_queryid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_queryid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_queryname	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_queryname	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_queryname	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_rdate	(const ICalDatetimeperiod *value);

LIBICAL_ICAL_EXPORT
ICalDatetimeperiod *
		i_cal_property_get_rdate	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_rdate	(ICalProperty *self,
						 const ICalDatetimeperiod *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_recuraccepted
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_recuraccepted
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_recuraccepted
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_recurexpand	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_recurexpand	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_recurexpand	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_recurlimit	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_recurlimit	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_recurlimit	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_recurrenceid	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_recurrenceid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_recurrenceid	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_refid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_refid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_refid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_refreshinterval
						(const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalDuration *	i_cal_property_get_refreshinterval
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_refreshinterval
						(ICalProperty *self,
						 const ICalDuration *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_relatedto	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_relatedto	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_relatedto	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_relcalid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_relcalid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_relcalid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_repeat	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_repeat	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_repeat	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_replyurl	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_replyurl	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_replyurl	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_requeststatus
						(const ICalReqstat *value);

LIBICAL_ICAL_EXPORT
ICalReqstat *	i_cal_property_get_requeststatus
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_requeststatus
						(ICalProperty *self,
						 const ICalReqstat *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_resources	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_resources	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_resources	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_resourcetype	(ICalPropertyResourcetype value);

LIBICAL_ICAL_EXPORT
ICalPropertyResourcetype 
		i_cal_property_get_resourcetype	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_resourcetype	(ICalProperty *self,
						 ICalPropertyResourcetype value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_response	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_response	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_response	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_restriction	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_restriction	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_restriction	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_rrule	(const ICalRecurrence *value);

LIBICAL_ICAL_EXPORT
ICalRecurrence *
		i_cal_property_get_rrule	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_rrule	(ICalProperty *self,
						 const ICalRecurrence *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_scope	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_scope	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_scope	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_sequence	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_sequence	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_sequence	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_source	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_source	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_source	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_status	(ICalPropertyStatus value);

LIBICAL_ICAL_EXPORT
ICalPropertyStatus 
		i_cal_property_get_status	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_status	(ICalProperty *self,
						 ICalPropertyStatus value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_storesexpanded
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_storesexpanded
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_storesexpanded
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_structureddata
						(const ICalAttach *value);

LIBICAL_ICAL_EXPORT
ICalAttach *	i_cal_property_get_structureddata
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_structureddata
						(ICalProperty *self,
						 const ICalAttach *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_styleddescription
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_styleddescription
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_styleddescription
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_summary	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_summary	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_summary	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_target	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_target	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_target	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_taskmode	(ICalPropertyTaskmode value);

LIBICAL_ICAL_EXPORT
ICalPropertyTaskmode 
		i_cal_property_get_taskmode	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_taskmode	(ICalProperty *self,
						 ICalPropertyTaskmode value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_transp	(ICalPropertyTransp value);

LIBICAL_ICAL_EXPORT
ICalPropertyTransp 
		i_cal_property_get_transp	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_transp	(ICalProperty *self,
						 ICalPropertyTransp value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_trigger	(const ICalTrigger *value);

LIBICAL_ICAL_EXPORT
ICalTrigger *	i_cal_property_get_trigger	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_trigger	(ICalProperty *self,
						 const ICalTrigger *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzid		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_tzid		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzid		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzidaliasof	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_tzidaliasof	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzidaliasof	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzname	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_tzname	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzname	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzoffsetfrom	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_tzoffsetfrom	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzoffsetfrom	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzoffsetto	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_property_get_tzoffsetto	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzoffsetto	(ICalProperty *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzuntil	(const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalTime *	i_cal_property_get_tzuntil	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzuntil	(ICalProperty *self,
						 const ICalTime *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_tzurl	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_tzurl	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_tzurl	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_uid		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_uid		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_uid		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_url		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_url		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_url		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_version	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_version	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_version	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_voter	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_voter	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_voter	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_x		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_x		(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_x		(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicclass	(ICalPropertyXlicclass value);

LIBICAL_ICAL_EXPORT
ICalPropertyXlicclass 
		i_cal_property_get_xlicclass	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicclass	(ICalProperty *self,
						 ICalPropertyXlicclass value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicclustercount
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicclustercount
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicclustercount
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicerror	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicerror	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicerror	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicmimecharset
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicmimecharset
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicmimecharset
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicmimecid	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicmimecid	(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicmimecid	(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicmimecontenttype
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicmimecontenttype
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicmimecontenttype
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicmimeencoding
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicmimeencoding
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicmimeencoding
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicmimefilename
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicmimefilename
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicmimefilename
						(ICalProperty *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_property_new_xlicmimeoptinfo
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_property_get_xlicmimeoptinfo
						(const ICalProperty *self);

LIBICAL_ICAL_EXPORT
void		i_cal_property_set_xlicmimeoptinfo
						(ICalProperty *self,
						 const gchar *value);

G_END_DECLS

#endif /* I_CAL_DERIVED_PROPERTY_H */

//NOLINTEND
