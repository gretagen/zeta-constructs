/* Generated file (by generator) */

/*
 * SPDX-FileCopyrightText: 2015 William Yu <williamyu@gnome.org>
 *
 * SPDX-License-Identifier: LGPL-2.1-only OR MPL-2.0
 */

//NOLINTBEGIN

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_VCARD_DERIVED_VALUE_H
#define I_CAL_VCARD_DERIVED_VALUE_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

typedef enum {
	I_CAL_VCARD_N_FAMILY = VCARD_N_FAMILY,
	I_CAL_VCARD_N_GIVEN = VCARD_N_GIVEN,
	I_CAL_VCARD_N_ADDITIONAL = VCARD_N_ADDITIONAL,
	I_CAL_VCARD_N_PREFIX = VCARD_N_PREFIX,
	I_CAL_VCARD_N_SUFFIX = VCARD_N_SUFFIX,
	I_CAL_VCARD_N_SECONDARY = VCARD_N_SECONDARY,
	I_CAL_VCARD_N_GENERATION = VCARD_N_GENERATION,
	I_CAL_VCARD_NUM_N_FIELDS = VCARD_NUM_N_FIELDS
} ICalVcardNField;

typedef enum {
	I_CAL_VCARD_GENDER_SEX = VCARD_GENDER_SEX,
	I_CAL_VCARD_GENDER_TEXT = VCARD_GENDER_TEXT,
	I_CAL_VCARD_NUM_GENDER_FIELDS = VCARD_NUM_GENDER_FIELDS
} ICalVcardGenderField;

typedef enum {
	I_CAL_VCARD_ADR_PO_BOX = VCARD_ADR_PO_BOX,
	I_CAL_VCARD_ADR_EXTENDED = VCARD_ADR_EXTENDED,
	I_CAL_VCARD_ADR_STREET = VCARD_ADR_STREET,
	I_CAL_VCARD_ADR_LOCALITY = VCARD_ADR_LOCALITY,
	I_CAL_VCARD_ADR_REGION = VCARD_ADR_REGION,
	I_CAL_VCARD_ADR_POSTAL_CODE = VCARD_ADR_POSTAL_CODE,
	I_CAL_VCARD_ADR_COUNTRY = VCARD_ADR_COUNTRY,
	I_CAL_VCARD_ADR_ROOM = VCARD_ADR_ROOM,
	I_CAL_VCARD_ADR_APARTMENT = VCARD_ADR_APARTMENT,
	I_CAL_VCARD_ADR_FLOOR = VCARD_ADR_FLOOR,
	I_CAL_VCARD_ADR_STREET_NUMBER = VCARD_ADR_STREET_NUMBER,
	I_CAL_VCARD_ADR_STREET_NAME = VCARD_ADR_STREET_NAME,
	I_CAL_VCARD_ADR_BUILDING = VCARD_ADR_BUILDING,
	I_CAL_VCARD_ADR_BLOCK = VCARD_ADR_BLOCK,
	I_CAL_VCARD_ADR_SUBDISTRICT = VCARD_ADR_SUBDISTRICT,
	I_CAL_VCARD_ADR_DISTRICT = VCARD_ADR_DISTRICT,
	I_CAL_VCARD_ADR_LANDMARK = VCARD_ADR_LANDMARK,
	I_CAL_VCARD_ADR_DIRECTION = VCARD_ADR_DIRECTION,
	I_CAL_VCARD_NUM_ADR_FIELDS = VCARD_NUM_ADR_FIELDS
} ICalVcardAdrField;

typedef enum {
	I_CAL_VCARD_CLIENTPIDMAP_ID = VCARD_CLIENTPIDMAP_ID,
	I_CAL_VCARD_CLIENTPIDMAP_URI = VCARD_CLIENTPIDMAP_URI,
	I_CAL_VCARD_NUM_CLIENTPIDMAP_FIELDS = VCARD_NUM_CLIENTPIDMAP_FIELDS
} ICalVcardClientpidmapField;

typedef enum {
	I_CAL_VCARD_ANY_VALUE = VCARD_ANY_VALUE,
	I_CAL_VCARD_BOOLEAN_VALUE = VCARD_BOOLEAN_VALUE,
	I_CAL_VCARD_DATE_VALUE = VCARD_DATE_VALUE,
	I_CAL_VCARD_DATEANDORTIME_VALUE = VCARD_DATEANDORTIME_VALUE,
	I_CAL_VCARD_DATETIME_VALUE = VCARD_DATETIME_VALUE,
	I_CAL_VCARD_FLOAT_VALUE = VCARD_FLOAT_VALUE,
	I_CAL_VCARD_GEO_VALUE = VCARD_GEO_VALUE,
	I_CAL_VCARD_GRAMGENDER_VALUE = VCARD_GRAMGENDER_VALUE,
	I_CAL_VCARD_INTEGER_VALUE = VCARD_INTEGER_VALUE,
	I_CAL_VCARD_KIND_VALUE = VCARD_KIND_VALUE,
	I_CAL_VCARD_LANGUAGETAG_VALUE = VCARD_LANGUAGETAG_VALUE,
	I_CAL_VCARD_STRUCTURED_VALUE = VCARD_STRUCTURED_VALUE,
	I_CAL_VCARD_TEXT_VALUE = VCARD_TEXT_VALUE,
	I_CAL_VCARD_TEXTLIST_VALUE = VCARD_TEXTLIST_VALUE,
	I_CAL_VCARD_TIME_VALUE = VCARD_TIME_VALUE,
	I_CAL_VCARD_TIMESTAMP_VALUE = VCARD_TIMESTAMP_VALUE,
	I_CAL_VCARD_TZ_VALUE = VCARD_TZ_VALUE,
	I_CAL_VCARD_URI_VALUE = VCARD_URI_VALUE,
	I_CAL_VCARD_UTCOFFSET_VALUE = VCARD_UTCOFFSET_VALUE,
	I_CAL_VCARD_VERSION_VALUE = VCARD_VERSION_VALUE,
	I_CAL_VCARD_X_VALUE = VCARD_X_VALUE,
	I_CAL_VCARD_NO_VALUE = VCARD_NO_VALUE
} ICalVcardValueKind;

typedef enum {
	I_CAL_VCARD_GRAMGENDER_X = VCARD_GRAMGENDER_X,
	I_CAL_VCARD_GRAMGENDER_ANIMATE = VCARD_GRAMGENDER_ANIMATE,
	I_CAL_VCARD_GRAMGENDER_COMMON = VCARD_GRAMGENDER_COMMON,
	I_CAL_VCARD_GRAMGENDER_FEMININE = VCARD_GRAMGENDER_FEMININE,
	I_CAL_VCARD_GRAMGENDER_INANIMATE = VCARD_GRAMGENDER_INANIMATE,
	I_CAL_VCARD_GRAMGENDER_MASCULINE = VCARD_GRAMGENDER_MASCULINE,
	I_CAL_VCARD_GRAMGENDER_NEUTER = VCARD_GRAMGENDER_NEUTER,
	I_CAL_VCARD_GRAMGENDER_NONE = VCARD_GRAMGENDER_NONE
} ICalVcardPropertyGramgender;

typedef enum {
	I_CAL_VCARD_KIND_X = VCARD_KIND_X,
	I_CAL_VCARD_KIND_INDIVIDUAL = VCARD_KIND_INDIVIDUAL,
	I_CAL_VCARD_KIND_GROUP = VCARD_KIND_GROUP,
	I_CAL_VCARD_KIND_ORG = VCARD_KIND_ORG,
	I_CAL_VCARD_KIND_LOCATION = VCARD_KIND_LOCATION,
	I_CAL_VCARD_KIND_APPLICATION = VCARD_KIND_APPLICATION,
	I_CAL_VCARD_KIND_DEVICE = VCARD_KIND_DEVICE,
	I_CAL_VCARD_KIND_NONE = VCARD_KIND_NONE
} ICalVcardPropertyKindenum;

typedef enum {
	I_CAL_VCARD_VERSION_X = VCARD_VERSION_X,
	I_CAL_VCARD_VERSION_V21 = VCARD_VERSION_21,
	I_CAL_VCARD_VERSION_V30 = VCARD_VERSION_30,
	I_CAL_VCARD_VERSION_V40 = VCARD_VERSION_40,
	I_CAL_VCARD_VERSION_NONE = VCARD_VERSION_NONE
} ICalVcardPropertyVersion;


LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_x		(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_value_get_x		(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_x		(ICalVcardValue *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_structured
						(const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardStructured *
		i_cal_vcard_value_get_structured
						(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_structured
						(ICalVcardValue *self,
						 const ICalVcardStructured *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_geo	(const ICalVcardGeo *value);

LIBICAL_ICAL_EXPORT
ICalVcardGeo *	i_cal_vcard_value_get_geo	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_geo	(ICalVcardValue *self,
						 const ICalVcardGeo *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_tz	(const ICalVcardTz *value);

LIBICAL_ICAL_EXPORT
ICalVcardTz *	i_cal_vcard_value_get_tz	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_tz	(ICalVcardValue *self,
						 const ICalVcardTz *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_boolean	(gboolean value);

LIBICAL_ICAL_EXPORT
gboolean 	i_cal_vcard_value_get_boolean	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_boolean	(ICalVcardValue *self,
						 gboolean value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_date	(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_value_get_date	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_date	(ICalVcardValue *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_dateandortime
						(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_value_get_dateandortime
						(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_dateandortime
						(ICalVcardValue *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_datetime	(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_value_get_datetime	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_datetime	(ICalVcardValue *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_float	(gdouble value);

LIBICAL_ICAL_EXPORT
gdouble 		i_cal_vcard_value_get_float	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_float	(ICalVcardValue *self,
						 gdouble value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_gramgender
						(ICalVcardPropertyGramgender value);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyGramgender 
		i_cal_vcard_value_get_gramgender
						(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_gramgender
						(ICalVcardValue *self,
						 ICalVcardPropertyGramgender value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_integer	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_value_get_integer	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_integer	(ICalVcardValue *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_kind	(ICalVcardPropertyKindenum value);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyKindenum 
		i_cal_vcard_value_get_kind	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_kind	(ICalVcardValue *self,
						 ICalVcardPropertyKindenum value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_languagetag
						(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_value_get_languagetag
						(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_languagetag
						(ICalVcardValue *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_text	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_value_get_text	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_text	(ICalVcardValue *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_textlist	(const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardStrArray *
		i_cal_vcard_value_get_textlist	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_textlist	(ICalVcardValue *self,
						 const ICalVcardStrArray *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_time	(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_value_get_time	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_time	(ICalVcardValue *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_timestamp	(const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardTime *	i_cal_vcard_value_get_timestamp	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_timestamp	(ICalVcardValue *self,
						 const ICalVcardTime *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_uri	(const gchar *value);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_vcard_value_get_uri	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_uri	(ICalVcardValue *self,
						 const gchar *value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_utcoffset	(gint value);

LIBICAL_ICAL_EXPORT
gint 		i_cal_vcard_value_get_utcoffset	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_utcoffset	(ICalVcardValue *self,
						 gint value);

LIBICAL_ICAL_EXPORT
ICalVcardValue *
		i_cal_vcard_value_new_version	(ICalVcardPropertyVersion value);

LIBICAL_ICAL_EXPORT
ICalVcardPropertyVersion 
		i_cal_vcard_value_get_version	(const ICalVcardValue *self);

LIBICAL_ICAL_EXPORT
void		i_cal_vcard_value_set_version	(ICalVcardValue *self,
						 ICalVcardPropertyVersion value);

G_END_DECLS

#endif /* I_CAL_VCARD_DERIVED_VALUE_H */

//NOLINTEND
