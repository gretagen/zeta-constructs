#!/usr/bin/env python
# License: GPLv3 Copyright: 2026, Kovid Goyal <kovid at kovidgoyal.net>

import glob
import hashlib
import json
import os
import re
import runpy
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import types
from collections import OrderedDict
from contextlib import suppress
from enum import StrEnum, auto
from functools import lru_cache, partial
from itertools import chain, product
from types import MappingProxyType
from typing import Any, Callable, Iterable, Iterator, Literal, NamedTuple, Sequence, TypedDict, TypeGuard

from kitty.constants import config_dir, read_kitty_resource, shaders_dir, slangc
from kitty.fast_data_types import (
    ANIMATION_SAMPLE_WAIT,
    BGIMAGE_PROGRAM,
    BLINK,
    BLIT_PROGRAM,
    BORDERS_PROGRAM,
    CELL_BG_PROGRAM,
    CELL_FG_PROGRAM,
    CELL_PROGRAM,
    COLOR_IS_INDEX,
    COLOR_IS_RGB,
    COLOR_IS_SPECIAL,
    COLOR_NOT_SET,
    CUSTOM_END_PROGRAM,
    DECORATION,
    DECORATION_MASK,
    DIM,
    GLSL_VERSION,
    GRAPHICS_ALPHA_MASK_PROGRAM,
    GRAPHICS_INDEXED_PROGRAM,
    GRAPHICS_INDEXED_UNSCALED_PROGRAM,
    GRAPHICS_PREMULT_PROGRAM,
    GRAPHICS_PROGRAM,
    MARK,
    MARK_MASK,
    MAX_CUSTOM_SHADER_GROUPS,
    MAX_SHADER_ANIM_USER_EVENT_NAME_LEN,
    MAX_SHADER_ANIM_USER_EVENTS,
    NUM_INDEXED_IMAGE_SPECIAL_COLORS,
    PADDING_PROGRAM,
    POINTER_MAP_SIZE,
    REVERSE,
    ROUNDED_RECT_PROGRAM,
    SCREENSHOT_PROGRAM,
    STRIKETHROUGH,
    TINT_PROGRAM,
    TRAIL_PROGRAM,
    compile_program,
    get_options,
)
from kitty.options.types import Options, defaults
from kitty.options.utils import USER_ANIMATION_EVENT_PREFIX, EasingFunction, is_valid_user_animation_event_name
from kitty.types import run_once
from kitty.utils import expandvars, lock_with_file, log_error


@lru_cache(maxsize=64)
def get_shader_src(name: str) -> str:
    return read_kitty_resource(f'{name}.slang', 'kitty.shaders').decode()


@lru_cache(maxsize=64)
def get_custom_shader_src(name: str) -> bytes:
    return read_kitty_resource(f'{name}.slang', 'kitty.shaders.custom')


@lru_cache(maxsize=32)
def get_custom_pipeline_src(name: str) -> bytes:
    return read_kitty_resource(f'{name}.pipeline', 'kitty.shaders.custom')


@run_once
def slangc_version() -> str:
    return subprocess.check_output(list(slangc()) + ['-version'], stderr=subprocess.STDOUT).decode().strip()


def is_dir_ok(path: str, checks: dict[str, str]) -> bool:
    for fname, expected in checks.items():
        try:
            with open(os.path.join(path, fname)) as f:
                if f.read().strip() != expected:
                    return False
        except OSError:
            return False
    return True


def ensure_cache_dir(path: str) -> None:
    "Ensure the cache dir is for the current slangc version and slang.py version"
    os.makedirs(path, exist_ok=True)
    # slang IR is version dependent and the compiler often crashes when loading .slang-module from another version
    checks = {'slangc.version': slangc_version(), 'slangpy.version': get_hash_for_self()}
    if not is_dir_ok(path, checks):
        shutil.rmtree(path)
        os.makedirs(path)
        for fname, expected in checks.items():
            with open(os.path.join(path, fname), 'w') as f:
                f.write(expected)


class Stage(StrEnum):
    vertex = 'vertex'
    fragment = 'fragment'


class EntryPoint(NamedTuple):
    stage: Stage
    name: str

    def asdict(self) -> dict[str, str]:
        return {'stage': str(self.stage), 'name': self.name}

    @classmethod
    def fromdict(self, s: dict[str, str]) -> 'EntryPoint':
        return EntryPoint(Stage(s['stage']), s['name'])


class Specialization(NamedTuple):
    name: str
    variables: MappingProxyType[str, str]

    @property
    def filename_insert(self) -> str:
        return f'.{self.name}' if self.name else '.default-specialization'


def text_contrast_is_identity(strategy: str) -> bool:
    # Same numbers as text_composition_strategy() in kitty/options/to-c.h.
    # set_cell_uniforms() turns gamma 1 and contrast 0 into pow(alpha, 1) * 1.
    if strategy == 'legacy':
        return False
    if strategy == 'platform':
        return sys.platform != 'darwin'
    parts = strategy.split()
    if not parts or len(parts) > 2:
        return False
    try:
        gamma = float(parts[0])
        contrast = float(parts[1]) if len(parts) == 2 else 0.0
    except ValueError:
        return False
    gamma = max(gamma, 0.01)
    contrast = min(max(contrast, 0.0), 100.0)
    return gamma == 1.0 and contrast == 0.0


def cell_variant(opts: Options = defaults, program: int = CELL_PROGRAM) -> dict[str, str]:
    text_fg_override_threshold: float = opts.text_fg_override_threshold[0]
    algo = '0'
    match opts.text_fg_override_threshold[1]:
        case '%':
            text_fg_override_threshold = max(0, min(text_fg_override_threshold, 100.0)) * 0.01
            algo = '1'
        case 'ratio':
            text_fg_override_threshold = max(0, min(text_fg_override_threshold, 21.0))
            algo = '2'
    if not text_fg_override_threshold:
        algo = '0'
    render_mode = (CELL_PROGRAM, CELL_BG_PROGRAM, CELL_FG_PROGRAM).index(program)
    return {
        'FG_OVERRIDE_ALGO': algo,
        'TEXT_NEW_GAMMA': 'false' if opts.text_composition_strategy == 'legacy' else 'true',
        'TEXT_CONTRAST_IDENTITY': 'true' if text_contrast_is_identity(opts.text_composition_strategy) else 'false',
        'RENDER_MODE': str(render_mode),
    }


@lru_cache(maxsize=2)
def cell_variations() -> tuple[MappingProxyType[str, str], ...]:
    variations = {'FG_OVERRIDE_ALGO': ('0', '1', '2'), 'RENDER_MODE': ('0', '1', '2')}
    bool_variations = 'false', 'true'
    # TEXT_CONTRAST_IDENTITY is only read when TEXT_NEW_GAMMA is true.
    base_keys = [k for k in cell_variant() if k != 'TEXT_CONTRAST_IDENTITY']
    variants_dict = {k: variations.get(k, bool_variations) for k in base_keys}
    ans: list[MappingProxyType[str, str]] = []
    for comb in product(*variants_dict.values()):
        variant = dict(zip(variants_dict.keys(), comb))
        if variant['TEXT_NEW_GAMMA'] == 'true':
            for identity in bool_variations:
                ans.append(MappingProxyType({**variant, 'TEXT_CONTRAST_IDENTITY': identity}))
        else:
            ans.append(MappingProxyType({**variant, 'TEXT_CONTRAST_IDENTITY': 'false'}))
    return tuple(ans)


def variant_name(variant: dict[str, str], default: dict[str, str]) -> str:
    if variant == default:
        return ''
    data = ' '.join(f'{k}={variant[k]}' for k in sorted(default)).encode()
    key = hashlib.md5(data, usedforsecurity=False)
    return key.hexdigest()[:5]


def glsl_shaders(name: str, variant_name: str = '') -> tuple[str, str]:
    if variant_name:
        variant_name = '.' + variant_name
    with open(os.path.join(shaders_dir, f'{name}{variant_name}.vert.glsl')) as f:
        vert = f.read()
    with open(os.path.join(shaders_dir, f'{name}{variant_name}.frag.glsl')) as f:
        frag = f.read()
    return vert, frag


class LoadShaderPrograms:
    text_fg_override_threshold: tuple[float, Literal['%', 'ratio']] = 0, '%'
    text_old_gamma: bool = False
    text_contrast_identity: bool = text_contrast_is_identity('platform')
    custom_shaders: tuple[str, ...] = ()
    force_recompile_of_custom_shaders: bool = False

    opts: Options | None = None

    def __init__(self) -> None:
        # Per-instance because it is mutable: the sources most recently compiled
        # into each program, used to skip redundant recompiles.
        self.last_built_custom_shaders: dict[int, tuple[str, str, dict[str, Any]]] = {}
        # Errors from the most recent attempt to build the shaders named by the
        # custom_shaders option. A failure here disables the shader silently as
        # far as rendering is concerned, so the Boss displays these to the user.
        self.custom_shader_errors: list[str] = []

    def get_options(self) -> Options:
        try:
            return self.opts or get_options()
        except RuntimeError:
            return defaults

    @property
    def needs_recompile(self) -> bool:
        opts = self.get_options()
        return (
            bool(opts.text_fg_override_threshold[0]) != bool(self.text_fg_override_threshold[0])
            or opts.text_fg_override_threshold[1] != self.text_fg_override_threshold[1]
            or (opts.text_composition_strategy == 'legacy') != self.text_old_gamma
            or text_contrast_is_identity(opts.text_composition_strategy) != self.text_contrast_identity
        )

    def recompile_if_needed(self) -> None:
        if self.needs_recompile:
            self(allow_recompile=True)
        else:
            opts = self.get_options()
            if tuple(opts.custom_shaders) != self.custom_shaders or self.force_recompile_of_custom_shaders:
                self.compile_custom_shaders(allow_recompile=True)

    def __call__(self, allow_recompile: bool = False) -> None:
        default_cell_variant = cell_variant()
        opts = self.get_options()
        self.text_old_gamma = opts.text_composition_strategy == 'legacy'
        self.text_contrast_identity = text_contrast_is_identity(opts.text_composition_strategy)
        self.text_fg_override_threshold = opts.text_fg_override_threshold
        metadata = load_glsl_metadata()

        def cell(prog: int) -> None:
            v = cell_variant(opts, program=prog)
            vert, frag = glsl_shaders('cell', variant_name(v, default_cell_variant))
            compile_program(prog, (vert,), (frag,), metadata['cell'], allow_recompile)

        cell(CELL_PROGRAM), cell(CELL_BG_PROGRAM), cell(CELL_FG_PROGRAM)
        for prog, vname in {
            GRAPHICS_PROGRAM: '',
            GRAPHICS_ALPHA_MASK_PROGRAM: 'alpha_mask',
            GRAPHICS_PREMULT_PROGRAM: 'premult',
        }.items():
            vert, frag = glsl_shaders('graphics', vname)
            compile_program(prog, (vert,), (frag,), metadata['graphics'], allow_recompile)
        for prog, vname in {GRAPHICS_INDEXED_PROGRAM: '', GRAPHICS_INDEXED_UNSCALED_PROGRAM: 'unscaled'}.items():
            vert, frag = glsl_shaders('indexed_graphics', vname)
            compile_program(prog, (vert,), (frag,), metadata['indexed_graphics'], allow_recompile)
        for name, prog in {
            'bgimage': BGIMAGE_PROGRAM,
            'tint': TINT_PROGRAM,
            'trail': TRAIL_PROGRAM,
            'blit': BLIT_PROGRAM,
            'screenshot': SCREENSHOT_PROGRAM,
            'rounded_rect': ROUNDED_RECT_PROGRAM,
            'border': BORDERS_PROGRAM,
            'padding': PADDING_PROGRAM,
        }.items():
            vert, frag = glsl_shaders(name)
            compile_program(prog, (vert,), (frag,), metadata[name], allow_recompile)
        compile_program(-1, (), (), {})  # initialize programs
        self.compile_custom_shaders(allow_recompile)

    def compile_custom_shaders(self, allow_recompile: bool = False) -> None:
        self.force_recompile_of_custom_shaders = False
        opts = self.get_options()
        self.custom_shaders = tuple(opts.custom_shaders)
        self.custom_shader_errors = []

        def err(msg: str) -> None:
            # Record as well as log: a failure here leaves the shader disabled
            # with no visible difference from not setting custom_shaders at all,
            # so the Boss shows these to the user.
            log_error(msg)
            self.custom_shader_errors.append(msg)

        pmap: dict[str, list[Pipeline]] = {}
        for k in self.custom_shaders:
            try:
                d = parse_pipeline(k)
            except FileNotFoundError as pe:
                try:
                    custom_shader(k)
                except CustomFileNotFound as e:
                    # Report the pipeline locations searched as well, not just the shader ones
                    tried = (pe.tried if isinstance(pe, CustomFileNotFound) else ()) + e.tried
                    err(f'Failed to find custom shader or pipeline {k} with error: {CustomFileNotFound(k, tried)}')
                    continue
                except Exception as e:
                    err(f'Failed to read custom shader pipeline definition from {k} with error: {e}')
                    continue
                try:
                    d = parse_pipeline_definition(['startgroup', f'    shaders {k}', 'endgroup'], k)
                except Exception as e:
                    err(f'Failed to build minimal shader pipeline for {k} with error: {e}')
                    continue
            except Exception as e:
                err(f'Failed to read custom shader pipeline definition from {k} with error: {e}')
                continue
            pmap.setdefault(d['slot'], []).append(d)

        def disable(prog: int) -> None:
            # Forget the cached sources as well, otherwise re-enabling the same
            # shader later is a no-op because the sources compare equal while the
            # program itself is empty.
            compile_program(prog, (), (), {}, allow_recompile)
            self.last_built_custom_shaders.pop(prog, None)

        def do(prog: int, slot: str) -> None:
            slot_pipelines = pmap.get(slot)
            if not slot_pipelines:
                disable(prog)
            else:
                try:
                    pipeline = merge_pipelines(slot_pipelines)
                    vert, frag, metadata = build_custom_shader_pipeline_glsl(pipeline)
                    # print(vert, file=open('/tmp/sample.vert', 'w'))
                    # print(frag, file=open('/tmp/sample.frag', 'w'))
                except FileNotFoundError as e:
                    if e.filename == slangc()[0]:
                        # Without slangc no custom shader can be built at all, and
                        # a bare "No such file or directory" gives no hint as to why.
                        err(
                            f'Failed to build custom shader for slot {slot} because the slang shader compiler'
                            f' ({slangc()[0]}) was not found. Install shader-slang to use custom shaders.'
                        )
                    else:
                        err(f'Failed to build custom shader for slot {slot} with error: {e}')
                    disable(prog)
                except Exception as e:
                    err(f'Failed to build custom shader for slot {slot} with error: {e}')
                    disable(prog)
                else:
                    try:
                        if self.last_built_custom_shaders.get(prog) != (vert, frag, metadata):
                            compile_program(prog, (vert,), (frag,), metadata, allow_recompile)
                            self.last_built_custom_shaders[prog] = vert, frag, metadata
                    except Exception as e:
                        err(f'Failed to load custom shader for slot {slot} with error: {e}')
                        disable(prog)

        do(CUSTOM_END_PROGRAM, 'end')
        compile_program(-2, (), (), {})  # initialize programs


load_shader_programs = LoadShaderPrograms()


# Querying shader source {{{
# A lexer and a parser for just the top level declarations of Slang source, so
# that questions such as "does this shader define a function" are not fooled by
# comments, strings, formatting or the contents of function bodies.


class TokenType(StrEnum):
    identifier = auto()
    number = auto()
    string = auto()
    punctuation = auto()
    directive = auto()
    comment = auto()


class Token(NamedTuple):
    type: TokenType
    text: str
    start: int  # offsets into the source
    end: int


@run_once
def slang_token_pat() -> re.Pattern[str]:
    return re.compile(
        r"""
          (?P<ws>\s+)
        | (?P<comment>//[^\n]*|/\*[\s\S]*?(?:\*/|\Z))
        | (?P<directive>\#(?:\\\r?\n|[^\n])*)
        | (?P<string>"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')
        | (?P<number>(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?[A-Za-z0-9_]*)
        | (?P<identifier>[A-Za-z_][A-Za-z0-9_]*)
        | (?P<punctuation>::|->|.)
        """,
        re.VERBOSE,
    )


def tokenize_slang(src: str) -> Iterator[Token]:
    for m in slang_token_pat().finditer(src):
        kind = m.lastgroup
        if kind == 'ws':
            continue
        start, end = m.span()
        if kind == 'directive' and src[src.rfind('\n', 0, start) + 1 : start].strip():
            # A # that is not the first thing on its line is not a directive
            end = start + 1
            yield Token(TokenType.punctuation, '#', start, end)
            # Lex the rest of the line normally
            for t in tokenize_slang(src[end : m.end()]):
                yield t._replace(start=t.start + end, end=t.end + end)
            continue
        yield Token(TokenType(kind), src[start:end], start, end)


# Keywords that can precede the type in a declaration
DECLARATION_MODIFIERS = frozenset(
    (
        'public',
        'private',
        'internal',
        'static',
        'const',
        'extern',
        'export',
        'inline',
        'uniform',
        'groupshared',
        'precise',
        'nointerpolation',
        'in',
        'out',
        'inout',
    )
)
# Declarations whose body is not code
NON_CODE_DECLARATIONS = frozenset(('struct', 'class', 'enum', 'interface', 'extension', 'namespace', 'cbuffer', 'typedef', 'typealias', 'using', '__generic'))
CLOSING_BRACKETS = {'(': ')', '[': ']', '{': '}'}


class SlangAttribute(NamedTuple):
    name: str  # for example: shader
    args: tuple[str, ...]  # for example: ('vertex',) with string quotes removed


class SlangFunction(NamedTuple):
    name: str
    return_type: str  # without whitespace, for example: vector<float,2>
    modifiers: frozenset[str]
    attributes: tuple[SlangAttribute, ...]
    has_body: bool

    def returns(self, *types: str) -> bool:
        return self.return_type in types


class SlangVariable(NamedTuple):
    name: str
    type: str  # without whitespace
    modifiers: frozenset[str]
    declaration: str  # the source of the whole declaration
    type_start: int  # offset of the type in the source
    end: int  # offset of the terminating semi-colon in the source, or the end of the declaration if there is none


class SlangDeclarations(NamedTuple):
    module: str = ''
    imports: tuple[str, ...] = ()
    functions: tuple[SlangFunction, ...] = ()
    variables: tuple[SlangVariable, ...] = ()
    comments: tuple[str, ...] = ()

    def function(self, name: str) -> SlangFunction | None:
        for f in self.functions:
            if f.name == name and f.has_body:
                return f
        for f in self.functions:
            if f.name == name:
                return f
        return None

    def variable(self, name: str) -> SlangVariable | None:
        for v in self.variables:
            if v.name == name:
                return v
        return None


class _Item(NamedTuple):
    # A single token or a bracketed group of tokens at the top level of a declaration
    first: Token
    last: Token

    @property
    def text(self) -> str:
        return self.first.text

    @property
    def is_group(self) -> bool:
        return self.first is not self.last


def parse_slang_declarations(src: str) -> SlangDeclarations:
    """Parse the top level declarations in Slang source. Preprocessor directives
    are ignored, use SlangShaderQuery to see the source as the compiler does."""
    tokens: list[Token] = []
    comments: list[str] = []
    for t in tokenize_slang(src):
        if t.type is TokenType.comment:
            comments.append(t.text)
        elif t.type is not TokenType.directive:
            tokens.append(t)
    module = ''
    imports: list[str] = []
    functions: list[SlangFunction] = []
    variables: list[SlangVariable] = []

    def group_end(i: int) -> int:
        # Index of the token closing the bracket at i, or of the last token if unbalanced
        stack = [CLOSING_BRACKETS[tokens[i].text]]
        for j in range(i + 1, len(tokens)):
            text = tokens[j].text
            if tokens[j].type is TokenType.punctuation:
                if text in CLOSING_BRACKETS:
                    stack.append(CLOSING_BRACKETS[text])
                elif text == stack[-1]:
                    stack.pop()
                    if not stack:
                        return j
        return len(tokens) - 1

    def joined(items: Iterable[_Item]) -> str:
        return ''.join(''.join(src[it.first.start : it.last.end].split()) for it in items)

    def parse_attribute(start: int, end: int) -> SlangAttribute:
        inner = tokens[start + 1 : end]
        name = inner[0].text if inner and inner[0].type is TokenType.identifier else ''
        args = tuple(t.text[1:-1] if t.type is TokenType.string else t.text for t in inner[1:] if t.type is not TokenType.punctuation)
        return SlangAttribute(name, args)

    def finish(items: list[_Item], attributes: list[SlangAttribute], terminator: Token | None) -> None:
        nonlocal module
        if not items:
            return
        head = items[0].text
        if head == 'module':
            module = joined(items[1:])
            return
        if head in ('import', '__import'):
            imports.append(joined(items[1:]))
            return
        if head in NON_CODE_DECLARATIONS:
            return
        eq = next((i for i, it in enumerate(items) if not it.is_group and it.text == '='), len(items))
        paren = next((i for i, it in enumerate(items[:eq]) if it.is_group and it.text == '('), -1)
        if paren > 0:
            name_idx = paren - 1
            if items[name_idx].text == '>':  # generic function: name<T>(...)
                depth = 0
                while name_idx >= 0:
                    depth += {'>': 1, '<': -1}.get(items[name_idx].text, 0)
                    if depth == 0:
                        break
                    name_idx -= 1
                name_idx -= 1
            if name_idx < 0 or items[name_idx].first.type is not TokenType.identifier:
                return
            before = items[:name_idx]
            functions.append(
                SlangFunction(
                    items[name_idx].text,
                    joined(it for it in before if it.text not in DECLARATION_MODIFIERS),
                    frozenset(it.text for it in before if it.text in DECLARATION_MODIFIERS),
                    tuple(attributes),
                    any(it.is_group and it.text == '{' for it in items[paren + 1 :]),
                )
            )
            return
        name_idx = next((i for i in range(eq - 1, -1, -1) if items[i].first.type is TokenType.identifier), -1)
        if name_idx < 0:
            return
        type_items = [it for it in items[:name_idx] if it.text not in DECLARATION_MODIFIERS]
        if not type_items:
            return
        end = terminator.start if terminator else items[-1].last.end
        variables.append(
            SlangVariable(
                items[name_idx].text,
                joined(type_items),
                frozenset(it.text for it in items[:name_idx] if it.text in DECLARATION_MODIFIERS),
                src[items[0].first.start : terminator.end if terminator else end],
                type_items[0].first.start,
                end,
            )
        )

    items: list[_Item] = []
    attributes: list[SlangAttribute] = []
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t.type is TokenType.punctuation:
            if t.text == ';':
                finish(items, attributes, t)
                items, attributes = [], []
                i += 1
                continue
            if t.text in CLOSING_BRACKETS:
                j = group_end(i)
                if t.text == '[' and not items:
                    attributes.append(parse_attribute(i, j))
                else:
                    items.append(_Item(t, tokens[j]))
                i = j + 1
                if t.text == '{' and not any(not it.is_group and it.text == '=' for it in items):
                    # The end of a function or struct definition, as opposed to an initializer list
                    finish(items, attributes, None)
                    items, attributes = [], []
                    if i < len(tokens) and tokens[i].text == ';':
                        i += 1
                continue
            if t.text in (')', ']', '}'):  # unbalanced, ignore
                i += 1
                continue
        items.append(_Item(t, t))
        i += 1
    finish(items, attributes, None)
    return SlangDeclarations(module, tuple(imports), tuple(functions), tuple(variables), tuple(comments))


class SlangShaderQuery:
    """Answers questions about the declarations in a shader as the compiler sees
    them, that is, after preprocessing. Running the preprocessor needs slangc
    and so is done only when the answer could depend on it."""

    def __init__(self, src: bytes, name: str = '', include_dirs: Iterable[str] = (), invocation_tracker: set[tuple[str, ...]] | None = None):
        self.src, self.name, self.include_dirs, self.invocation_tracker = src, name, tuple(include_dirs), invocation_tracker
        self._identifiers: frozenset[str] | None = None
        self._preprocessed: SlangDeclarations | None = None

    @property
    def identifiers(self) -> frozenset[str]:
        "All identifiers in the source outside comments, including those in preprocessor directives"
        if self._identifiers is None:
            ans: set[str] = set()
            q = [self.src.decode()]
            while q:
                for t in tokenize_slang(q.pop()):
                    if t.type is TokenType.identifier:
                        ans.add(t.text)
                    elif t.type is TokenType.directive:
                        q.append(t.text[1:])
            self._identifiers = frozenset(ans)
        return self._identifiers

    @property
    def preprocessed(self) -> SlangDeclarations:
        if self._preprocessed is None:
            cmd = list(slangc()) + ['-lang', 'slang', '-E']
            for x in self.include_dirs:
                cmd += ['-I', x]
            cmd += ['--', '-']
            if self.invocation_tracker is not None:
                self.invocation_tracker.add(tuple(cmd))
            cp = subprocess.run(cmd, input=self.src, capture_output=True)
            if cp.returncode != 0:
                raise SlangFailed(self.name or 'shader', cp)
            self._preprocessed = parse_slang_declarations(cp.stdout.decode())
        return self._preprocessed

    def function(self, name: str) -> SlangFunction | None:
        "The function with the specified name defined at the top level of the shader, if any"
        if name not in self.identifiers:  # avoid running the preprocessor
            return None
        return self.preprocessed.function(name)


# }}}


class SlangFile(NamedTuple):
    path: str = ''
    text: str = ''
    imports: frozenset[str] = frozenset()
    entry_points: frozenset[EntryPoint] = frozenset()
    module: str = ''
    specializable_variables: MappingProxyType[str, str] = MappingProxyType({})
    disable_warnings: frozenset[str] = frozenset()

    def asdict(self, skip_source: bool = False) -> dict[str, Any]:
        "Return a dict useable for serialization to JSON"
        ans = self._asdict()
        ans['imports'] = tuple(ans['imports'])
        ans['entry_points'] = tuple(ep.asdict() for ep in ans['entry_points'])
        ans['specializable_variables'] = dict(ans['specializable_variables'])
        ans['disable_warnings'] = tuple(ans['disable_warnings'])
        if skip_source:
            ans['text'] = ''
            ans['path'] = os.path.basename(ans['path'])
        return ans

    @classmethod
    def fromdict(cls, s: dict[str, Any]) -> 'SlangFile':
        return SlangFile(
            s['path'],
            s['text'],
            frozenset(s['imports']),
            frozenset(EntryPoint.fromdict(x) for x in s['entry_points']),
            s['module'],
            MappingProxyType(s['specializable_variables']),
            frozenset(s['disable_warnings']),
        )

    @property
    def should_compile_to_ir(self) -> bool:
        return bool(self.module or self.entry_points)

    @property
    def defines(self) -> MappingProxyType[str, str]:
        ans = {}
        match os.path.basename(self.path):
            case 'background.slang' | 'cell.slang':
                ans['MARK_MASK'] = str(MARK_MASK)
                ans['NUM_INDEXED_IMAGE_SPECIAL_COLORS'] = str(NUM_INDEXED_IMAGE_SPECIAL_COLORS)
                ans['REVERSE_SHIFT'] = str(REVERSE)
                ans['STRIKE_SHIFT'] = str(STRIKETHROUGH)
                ans['DIM_SHIFT'] = str(DIM)
                ans['BLINK_SHIFT'] = str(BLINK)
                ans['DECORATION_SHIFT'] = str(DECORATION)
                ans['MARK_SHIFT'] = str(MARK)
                ans['DECORATION_MASK'] = str(DECORATION_MASK)
                ans['COLOR_NOT_SET'] = str(COLOR_NOT_SET)
                ans['COLOR_IS_SPECIAL'] = str(COLOR_IS_SPECIAL)
                ans['COLOR_IS_INDEX'] = str(COLOR_IS_INDEX)
                ans['COLOR_IS_RGB'] = str(COLOR_IS_RGB)
        return MappingProxyType(ans)

    @property
    def specializations(self) -> Iterator[Specialization]:
        def s(name: str = '', **kwargs: str) -> Specialization:
            return Specialization(name, MappingProxyType(kwargs))

        match os.path.basename(self.path):
            case 'graphics.slang':
                yield s()
                yield s('alpha_mask', is_alpha_mask='true')
                yield s('premult', texture_is_not_premultiplied='false')
            case 'indexed_graphics.slang':
                yield s()
                yield s('unscaled', is_scaled='false')
            case 'cell.slang':
                d = cell_variant()
                seen = set()
                for variant in cell_variations():
                    name = variant_name(dict(variant), d)
                    if name in seen:
                        raise Exception('Variant names for cell shader not unique')
                    seen.add(name)
                    yield s(name, **variant)
            case _:
                yield s()


def parse_slang_text(src_code: str, path: str = '') -> SlangFile:
    decls = parse_slang_declarations(src_code)
    entry_points = []
    for func in decls.functions:
        for attr in func.attributes:
            if attr.name == 'shader' and attr.args:
                match attr.args[0]:
                    case 'vertex':
                        entry_points.append(EntryPoint(Stage.vertex, func.name))
                    case 'fragment' | 'pixel':
                        entry_points.append(EntryPoint(Stage.fragment, func.name))
    specializable_variables = {v.name: v.declaration for v in decls.variables if {'extern', 'static', 'const'} <= v.modifiers}
    disable_warnings = []
    for comment in decls.comments:
        if comment.startswith('// warnings-disable: '):
            for word in comment.split()[2:]:
                disable_warnings.extend(word.split(','))
    return SlangFile(
        path,
        src_code,
        frozenset(decls.imports),
        frozenset(entry_points),
        decls.module,
        MappingProxyType(specializable_variables),
        frozenset(disable_warnings),
    )


@lru_cache(4096)
def parse_slang_file(path: str) -> SlangFile:
    with open(path) as f:
        text = f.read()
    return parse_slang_text(text, path)


def build_import_graph(dirpath: str) -> dict[str, SlangFile]:
    graph: dict[str, SlangFile] = {}
    exclude = os.path.abspath(os.path.join(dirpath, 'custom'))
    for root, _, files in os.walk(os.path.abspath(dirpath)):
        if root == exclude:
            continue
        for file in files:
            if file.endswith('.slang'):
                full_path = os.path.abspath(os.path.join(root, file))
                relpath = os.path.relpath(full_path, root)
                modname = os.path.splitext(relpath.replace(os.sep, '.'))[0]
                graph[modname] = parse_slang_file(full_path)
    return graph


def topological_sort(graph: dict[str, SlangFile]) -> list[str]:
    visited = set()
    order = []

    def visit(node: str) -> None:
        if node in visited or node not in graph:
            return
        for dep in graph[node].imports:
            visit(dep)
        visited.add(node)
        order.append(node)

    for node in graph:
        visit(node)
    return order


def topological_layers(graph: dict[str, SlangFile]) -> list[list[str]]:
    layer_of: dict[str, int] = {}

    def compute_layer(node: str) -> int:
        if node in layer_of:
            return layer_of[node]
        if node not in graph:
            return -1
        layer = max((compute_layer(dep) + 1 for dep in graph[node].imports), default=0)
        layer_of[node] = layer
        return layer

    for node in graph:
        compute_layer(node)

    if not layer_of:
        return []
    max_layer = max(layer_of.values())
    layers: list[list[str]] = [[] for _ in range(max_layer + 1)]
    for node, layer in layer_of.items():
        layers[layer].append(node)
    return layers


def get_ordered_sources_in_tree(dirpath: str) -> OrderedDict[str, SlangFile]:
    g = build_import_graph(dirpath)
    return OrderedDict({k: g[k] for k in topological_sort(g)})


def future() -> float:
    return time.time() + 1000000


def safe_mtime(path: str, defval: float = 0) -> float:
    with suppress(OSError):
        return os.path.getmtime(path)
    return defval if defval >= 0 else future()


def read_deps_file(path: str) -> Iterator[str]:
    with open(path) as f:
        for line in f:
            line = line.partition(':')[2].strip()
            yield from line.split()


def get_newest_dep_time(path: str) -> float:
    with suppress(OSError):
        ans = 0.0
        for deppath in read_deps_file(path):
            mtime = os.path.getmtime(deppath)
            ans = max(mtime, ans)
        return ans
    return future()


def sanitize_code_object(code_obj: types.CodeType) -> types.CodeType:
    """
    Recursively strips environmental metadata (like file paths and first line numbers)
    from a code object so the hash remains identical across different machines.
    """
    # Recursively process nested constants (inner functions/classes)
    new_consts = []
    for const in code_obj.co_consts:
        if isinstance(const, types.CodeType):
            new_consts.append(sanitize_code_object(const))
        else:
            new_consts.append(const)

    # Rebuild the code object with sanitized file names and line numbers
    # (Using replace() is safe and fully compatible with Python 3.8+)
    return code_obj.replace(
        co_filename='slang.py',  # Forces a uniform mock filename
        co_firstlineno=1,  # Standardizes the line number offsets
        co_consts=tuple(new_consts),
    )


@run_once
def get_hash_for_self() -> str:
    """
    Climbs to the module scope, sanitizes it, and returns a unique
    SHA-256 hash representing the entire executable structure.
    """
    import hashlib
    import importlib.util
    import marshal
    from importlib.abc import InspectLoader

    if __name__ == '__main__':
        with open(__file__, 'rb') as f:
            serialized_bytes = f.read()
    else:
        spec = importlib.util.find_spec(__name__)
        assert spec is not None and isinstance(spec.loader, InspectLoader)
        top_code_obj = spec.loader.get_code(__name__)
        assert top_code_obj is not None
        clean_code_obj = sanitize_code_object(top_code_obj)
        serialized_bytes = marshal.dumps(clean_code_obj)
    return hashlib.md5(serialized_bytes).hexdigest()


class Command(NamedTuple):
    needs_build: bool
    description: str
    cmd: list[str]


def commands_to_compile_dir_to_ir(sources: dict[str, SlangFile], src_dir: str, output_dirpath: str) -> Iterator[Command]:
    cmdbase = list(slangc()) + ['-warnings-as-errors', 'all']
    for name, sfile in sources.items():
        if sfile.should_compile_to_ir:
            parts = name.split('.')
            base_dest = os.path.join(output_dirpath, *parts)
            slang_module = f'{base_dest}.slang-module'
            deps_file = f'{base_dest}.deps'
            module_mtime = safe_mtime(slang_module)
            needs_build = module_mtime < get_newest_dep_time(deps_file)
            defines = [f'-D{k}={v}' for k, v in sfile.defines.items()]
            yield Command(
                needs_build,
                f'Compiling |{name}.slang| ...',
                cmdbase
                + defines
                + [
                    '-I',
                    output_dirpath,
                    '-I',
                    src_dir,
                    '-depfile',
                    deps_file,
                    '-target',
                    'none',
                    '-o',
                    slang_module,
                    '--',
                    sfile.path,
                ],
            )


def iter_entry_point_shaders(sources: dict[str, SlangFile], build_dir: str, dest_dir: str) -> Iterator[tuple[str, str, str, list[str], SlangFile]]:
    cmdbase = list(slangc()) + ['-warnings-as-errors', 'all']
    for name, sfile in sources.items():
        if not sfile.entry_points:
            continue
        parts = name.split('.')
        base_dest = os.path.join(dest_dir, *parts)
        base_build = os.path.join(build_dir, *parts)
        slang_module = f'{base_build}.slang-module'
        cmd = list(cmdbase)
        if sfile.disable_warnings:
            cmd += ['-warnings-disable', ','.join(sfile.disable_warnings)]
        cmd += ['-I', build_dir, slang_module]
        yield base_dest, base_build, slang_module, cmd, sfile


def serialize_source_metadata(sources: dict[str, SlangFile], dest_dir: str) -> None:
    for base_dest, _, _, _, sfile in iter_entry_point_shaders(sources, dest_dir, dest_dir):
        dest = f'{base_dest}.json'
        with open(dest, 'w') as f:
            f.write(json.dumps(sfile.asdict(skip_source=True), indent=2, sort_keys=True))


def commands_to_compile_to_spirv(sources: dict[str, SlangFile], build_dir: str, dest_dir: str, built_files: list[str]) -> Iterator[Command]:
    # glsl 450 is vulkan 1.1 and spirv 1.3 released 2008
    base_cmd = ['-target', 'spirv', '-profile', 'glsl_450', '-capability', 'vk_mem_model', '-fvk-use-entrypoint-name']
    for base_dest, base_build, slang_module, scmd, sfile in iter_entry_point_shaders(sources, build_dir, dest_dir):
        for x in sfile.specializations:
            cmd = list(scmd)
            dest = f'{base_dest}.{x.name}.spv' if x.name else f'{base_dest}.spv'
            if x.variables:
                cmd.insert(-1, f'{base_build}{x.filename_insert}.slang-module')
            cmd += base_cmd + ['-o', dest, '-reflection-json', dest + '.json']
            output_mtime = safe_mtime(dest)
            module_mtime = os.path.getmtime(slang_module)
            needs_build = output_mtime < module_mtime
            if needs_build:
                built_files.append(dest)
            yield Command(needs_build, f'Linking |{os.path.basename(dest)}| ...', cmd)


# GLSL {{{
glsl_version = max(150, GLSL_VERSION)  # slangc fails with glsl_140 https://github.com/shader-slang/slang/issues/11898


def commands_to_compile_to_glsl(sources: dict[str, SlangFile], build_dir: str, dest_dir: str, built_glsl_files: list[str]) -> Iterator[Command]:
    for base_dest, base_build, slang_module, cmd, sfile in iter_entry_point_shaders(sources, build_dir, dest_dir):
        module_mtime = os.path.getmtime(slang_module)
        extra_cmd = ['-line-directive-mode', 'none', '-target', 'glsl', '-profile', f'glsl_{glsl_version}']
        for ep in sfile.entry_points:
            for sp in sfile.specializations:
                v = {Stage.vertex: 'vert', Stage.fragment: 'frag'}[ep.stage]
                c = list(cmd)
                dest = f'{base_dest}{sp.filename_insert}.{v}.glsl' if sp.name else f'{base_dest}.{v}.glsl'
                if sp.variables:
                    c.insert(-1, f'{base_build}{sp.filename_insert}.slang-module')
                c += extra_cmd + ['-entry', ep.name, '-stage', ep.stage.name, '-o', dest]
                output_mtime = safe_mtime(dest)
                needs_build = output_mtime < module_mtime
                if needs_build:
                    built_glsl_files.append(dest)
                yield Command(needs_build, f'Linking |{os.path.basename(slang_module)}| to GLSL {ep.stage.value} shader ...', c)


class GLSLMetadata:
    loose_uniforms: dict[str, str]
    uniform_structs: dict[str, dict[str, str]]
    input_locations: dict[str, int]
    uniform_struct_names: dict[str, str]
    fragment_inputs: dict[int, str]

    def __init__(self) -> None:
        self.loose_uniforms = {}
        self.uniform_structs = {}
        self.input_locations = {}
        self.uniform_struct_names = {}
        self.fragment_inputs = {}

    def merge(self, other: 'GLSLMetadata') -> None:
        self.loose_uniforms.update(other.loose_uniforms)
        self.uniform_structs.update(other.uniform_structs)
        self.uniform_struct_names.update(other.uniform_struct_names)
        self.input_locations.update(other.input_locations)

    def asdict(self) -> dict[str, Any]:
        return {
            'loose_uniforms': self.loose_uniforms,
            'uniform_structs': self.uniform_structs,
            'input_locations': self.input_locations,
            'uniform_struct_names': self.uniform_struct_names,
            'fragment_inputs': self.fragment_inputs,
        }

    @classmethod
    def fromdict(cls, d: dict[str, Any]) -> 'GLSLMetadata':
        ans = GLSLMetadata()
        ans.loose_uniforms = d['loose_uniforms']
        ans.uniform_structs = d['uniform_structs']
        ans.input_locations = d['input_locations']
        ans.uniform_struct_names = d['uniform_struct_names']
        ans.fragment_inputs = d['fragment_inputs']
        return ans


# Uniform blocks that must be emitted as loose uniforms in the default uniform
# block instead of as a UBO. Uniform values are part of program object state,
# which the GL implementation is responsible for maintaining, whereas the data
# store of a buffer object belongs to us and some drivers, notably the macOS
# OpenGL on Metal layer waking from sleep, silently discard it. Anything we
# upload to a buffer once and never again then stays corrupt forever. Only
# suitable for blocks whose contents are compile time constants, since setting
# a loose uniform costs a GL call per program rather than one buffer write.
# See https://github.com/kovidgoyal/kitty/issues/10571
GLSL_LOOSE_UNIFORM_BLOCKS = frozenset({'GammaLUT'})


def fixup_opengl_code(glsl_code: str, shader_name: str, existing_metadata: GLSLMetadata | None) -> tuple[str, GLSLMetadata]:
    is_fragment_shader = existing_metadata is None
    shader_name += '.frag.glsl' if is_fragment_shader else '.vert.glsl'
    lines: list[str] = []
    in_uniform_block = False
    in_uniform_block_contents = False
    uniform_block_is_struct = False
    current_uniform_struct_members: dict[str, str] = {}
    current_uniform_struct_name: str = ''
    uniform_blocks = {}
    current_uniform_names: list[str] = []
    uniform_names: dict[str, str] = {}
    uniform_structs = {}
    uniform_struct_names = {}
    input_locations = {}
    named_interface_blocks = set()
    pipeline_io_vars: dict[int, str] = {}
    replacements = {
        'gl_VertexIndex': 'gl_VertexID',
        'gl_BaseVertex': '0',
        'gl_InstanceIndex': 'gl_InstanceID',
        'gl_BaseInstance': '0',
    }
    fragment_inputs = {} if existing_metadata is None else existing_metadata.fragment_inputs.copy()

    def register_pipeline_boundary_io(line: str, next_line: str) -> None:
        m = re.search(r'location = (\d+)', line)
        assert m is not None
        name = next_line.split()[-1].rstrip(';')
        location = int(m.group(1))
        if existing_metadata is None:
            if not next_line.startswith('out '):
                pipeline_io_vars[location] = name
        else:
            with suppress(KeyError):
                replacements[name] = fragment_inputs.pop(location)

    def add_uniform_name(name: str, uniform_names: dict[str, str] = uniform_names) -> str:
        name = name.rstrip(';')
        uniform_name = name.rpartition('_')[0]
        if uniform_name in uniform_names:
            raise KeyError(f'The uniform name {uniform_name} is used with multiple suffixes in {shader_name}')
        if '[' in name:
            name = name.partition('[')[0] + '[0]'
        uniform_names[uniform_name] = name
        return name

    src_lines = glsl_code.splitlines()

    for i, line in enumerate(src_lines):
        next_line = src_lines[i + 1] if i + 1 < len(src_lines) else ''
        if in_uniform_block:
            if in_uniform_block_contents:
                if line.startswith('}'):
                    in_uniform_block = in_uniform_block_contents = False
                    block_name = line.lstrip('}').rstrip(';').strip()
                    if uniform_block_is_struct:
                        uniform_structs[current_uniform_struct_name] = current_uniform_struct_members
                        named_interface_blocks.add(block_name)
                        line = '};'
                    else:
                        uniform_blocks[block_name] = current_uniform_names
                        line = '// ' + line
                    current_uniform_names = []
                else:
                    if uniform_block_is_struct:
                        current_uniform_names.append(add_uniform_name(line.split()[-1], current_uniform_struct_members))
                    else:
                        line = line.strip()
                        current_uniform_names.append(add_uniform_name(line.split()[-1]))
                        line = 'uniform ' + line
            elif line.startswith('{'):  # }}
                if not uniform_block_is_struct:
                    line = '// ' + line
                in_uniform_block_contents = True
                current_uniform_names = []
        else:
            if line.startswith('#version '):
                line = f'#version {GLSL_VERSION}'
                if not is_fragment_shader:
                    line += '\n#extension GL_ARB_explicit_attrib_location : require'
            elif line.startswith('#extension ') or line in ('layout(row_major) buffer;', 'layout(push_constant)'):
                line = '// ' + line
            elif line.startswith('layout(binding ='):
                line = '// ' + line
            elif line.startswith('layout(location =') and (is_fragment_shader or next_line.startswith('out ')):  # ))
                register_pipeline_boundary_io(line, next_line)
                line = '// ' + line
            elif line.startswith('flat layout(location ='):
                register_pipeline_boundary_io(line[len('flat ') :], next_line)
                line = 'flat'
            elif line:  # ))))
                words = line.split()
                if 'uniform' in words and line.startswith('layout('):  # )
                    in_uniform_block = True
                    in_uniform_block_contents = False
                    block_name = words[-1]
                    slang_block_name = block_name[len('block_') :].rpartition('_')[0] if block_name.startswith('block_') else ''
                    uniform_block_is_struct = line.startswith('layout(std140') and slang_block_name not in GLSL_LOOSE_UNIFORM_BLOCKS  # )
                    if uniform_block_is_struct:
                        current_uniform_struct_name = slang_block_name
                        assert block_name.startswith('block_')
                        current_uniform_struct_members = {}
                        uniform_struct_names[current_uniform_struct_name] = block_name
                    else:
                        line = '// ' + line
                elif words[0] == 'uniform' and len(words) > 2 and words[1].removeprefix('u').removeprefix('i').startswith('sampler'):
                    add_uniform_name(words[2])
                elif not is_fragment_shader and words[0] == 'in':
                    name = words[-1].rstrip(';')
                    input_locations[name.rpartition('_')[0]] = int(lines[-1].split()[-1].rstrip(')'))
        lines.append(line)
    if fragment_inputs:
        raise ValueError(
            f'Could not match vertex outputs to fragment inputs for shader: {shader_name}. Leftover fragment inputs: {", ".join(fragment_inputs.values())}'
        )
    ans = '\n'.join(lines)
    for block_name, names in uniform_blocks.items():
        for u in names:
            u = u.partition('[')[0]  # ]
            replacements[f'{block_name}.{u}'] = u

    for x in named_interface_blocks:
        replacements[f'{x}.'] = ''

    def sub(m: re.Match[str]) -> str:
        return replacements[m.group(1)]

    ans = re.sub(r'\b(' + '|'.join(re.escape(word) for word in replacements) + r')\b', sub, ans)
    # Slang emits `{ }` style struct initializers which aren't valid in GLSL 140;
    # convert them to GLSL constructor call syntax.
    ans = re.sub(
        r'\b([A-Za-z_]\w*)\s+(\w+)\s*=\s*\{([^}]*)\}',
        lambda m: f'{m.group(1)} {m.group(2)} = {m.group(1)}({m.group(3)})',
        ans,
    )
    m = GLSLMetadata()
    m.loose_uniforms = uniform_names
    m.uniform_structs = uniform_structs
    m.input_locations = input_locations
    m.uniform_struct_names = uniform_struct_names
    if is_fragment_shader:
        m.fragment_inputs = pipeline_io_vars
    return ans, m


def shader_name_from_path(path: str) -> str:
    parts = os.path.basename(path).split('.')
    if parts[1] in ('vert', 'frag', 'glsl'):
        return parts[0]
    return '.'.join(parts[:2])


def fixup_opengl_files(paths: Iterable[str]) -> None:
    "Convert the GLSL output of slangc to something that will work with OpenGL 3.1"
    metadata_map: dict[str, GLSLMetadata] = {}
    dest_dir = ''
    for path in sorted(paths):
        dest_dir = os.path.dirname(path)
        with open(path, 'r') as f:
            glsl_code = f.read()
        shader_name = shader_name_from_path(path)
        try:
            fixed, metadata = fixup_opengl_code(glsl_code, shader_name, metadata_map.get(shader_name))
        except Exception:
            os.unlink(path)
            raise
        write_if_changed(path, fixed)
        if shader_name in metadata_map:
            metadata_map[shader_name].merge(metadata)
        else:
            metadata_map[shader_name] = metadata
    for name, gm in metadata_map.items():
        with open(os.path.join(dest_dir, f'{name}.glsl.json'), 'w') as f:
            f.write(json.dumps(gm.asdict()))


def write_if_changed(dest: str, text: str) -> None:
    with suppress(FileNotFoundError), open(dest) as f:
        existing = f.read()
        if existing == text:
            return
    with open(dest, 'w') as f:
        f.write(text)


def glsl_metadata_for_shader(path: str) -> dict[str, Any]:
    with open(path) as f:
        d = json.load(f)
    m = GLSLMetadata.fromdict(d)
    return {
        'loose_uniforms': m.loose_uniforms,
        'uniform_structs': m.uniform_structs,
        'input_locations': m.input_locations,
        'uniform_struct_names': m.uniform_struct_names,
    }


def write_glsl_metadata(dest_dir: str, dest: str = 'glsl-uniforms.json') -> None:
    metadata_map = {}
    for x in glob.glob(os.path.join(dest_dir, '*.glsl.json')):
        shader_name = shader_name_from_path(x)
        if '.' in shader_name:
            continue
        metadata_map[shader_name] = glsl_metadata_for_shader(x)
    write_if_changed(os.path.join(dest_dir, dest), json.dumps(metadata_map, indent=2, sort_keys=True))


@lru_cache(maxsize=1)
def load_glsl_metadata() -> dict[str, dict[str, Any]]:
    with open(os.path.join(shaders_dir, 'glsl-uniforms.json')) as f:
        return dict(json.load(f))


# }}}


ParallelRun = Callable[[Iterable[tuple[bool, str, list[str]]]], None]


def create_specialisations(sources: dict[str, SlangFile], build_dir: str) -> Iterator[Command]:
    for _, base_build, _, _, sfile in iter_entry_point_shaders(sources, build_dir, build_dir):
        if sfile.entry_points:
            for sp in sfile.specializations:
                if not sp.variables:
                    continue
                dest = f'{base_build}{sp.filename_insert}.slang'
                payload = existing = ''
                if sp.variables:
                    lines = []
                    for key, val in sp.variables.items():
                        declaration = sfile.specializable_variables[key].rpartition('=')[0]
                        if not declaration:
                            declaration = sfile.specializable_variables[key].rstrip(';')
                        declaration = declaration.replace('extern ', 'export ', 1)
                        lines.append(f'{declaration} = {val};')
                    payload = '\n'.join(lines)
                with suppress(FileNotFoundError), open(dest) as f:
                    existing = f.read()
                if needs_build := payload != existing:
                    if payload:
                        with open(dest, 'w') as fw:
                            fw.write(payload)
                    else:
                        os.remove(dest)
                yield Command(needs_build, f'Compiling specialisation |{os.path.basename(dest)}| ...', list(slangc()) + [dest, '-o', dest + '-module'])


def compile_builtin_shaders(build_dir: str, dest_dir: str, parallel_run: ParallelRun) -> None:
    ensure_cache_dir(build_dir)
    ensure_cache_dir(dest_dir)
    src_dir = os.path.abspath('kitty/shaders')
    source_tree = get_ordered_sources_in_tree(src_dir)
    serialize_source_metadata(source_tree, dest_dir)

    # Compile IR layer by layer so each module's dependencies finish before it starts
    for layer in topological_layers(source_tree):
        layer_sources = {k: source_tree[k] for k in layer}
        parallel_run(commands_to_compile_dir_to_ir(layer_sources, src_dir, build_dir))
    # Create the specializations
    parallel_run(create_specialisations(source_tree, build_dir))
    # Now Vulkan shaders
    built_spirv_files: list[str] = []
    spirv_commands = commands_to_compile_to_spirv(source_tree, build_dir, dest_dir, built_spirv_files)
    # Now glsl files
    built_glsl_files: list[str] = []
    glsl_commands = commands_to_compile_to_glsl(source_tree, build_dir, dest_dir, built_glsl_files)
    # Now run all commands
    parallel_run(chain(spirv_commands, glsl_commands))
    fixup_opengl_files(built_glsl_files)
    if shutil.which('glslangValidator'):
        from kitty.shaders.validate_shaders import validation_command_for_file

        parallel_run((True, f'Validating |{os.path.basename(x)}| ...', validation_command_for_file(x)) for x in built_glsl_files)
    write_glsl_metadata(dest_dir)


def main() -> None:
    if not shutil.which(slangc()[0]):
        raise SystemExit(f'The shader slang compiler ({slangc()[0]}) not in PATH: {os.environ.get("PATH")}')
    setup = runpy.run_path('setup.py')
    verbose = sys.argv[-3] == 'verbose'
    Command = setup['Command']
    parallel_run = setup['parallel_run']
    emphasis = setup['emphasis']

    def prun(cmds: Iterable[tuple[bool, str, list[str]]]) -> None:
        cmds = tuple(cmds)
        needed = []
        for needs_build, desc, cmd in cmds:
            if needs_build:
                desc = re.sub(r'\|(.+?)\|', lambda m: emphasis(m.group(1)), desc)
                needed.append(Command(desc, cmd, lambda: True))
        parallel_run(needed, verbose)

    compile_builtin_shaders(sys.argv[-2], sys.argv[-1], prun)


class SlangFailed(Exception):
    def __init__(self, fname: str, cp: subprocess.CompletedProcess):
        args = cp.args
        stderr = cp.stderr
        if isinstance(args, str):
            cmd = args
        else:
            cmd = shlex.join(args)
        super().__init__(f'Failed to compile {fname} with command line:\n{cmd}\nand stderr:\n{stderr.decode()}')


def key(*items: str | bytes) -> bytes:
    h = hashlib.md5(usedforsecurity=False)
    for data in items:
        if isinstance(data, str):
            data = data.encode()
        h.update(data)
    return h.hexdigest().encode()


def _expand_custom_path(name: str) -> str:
    opts: Options | None = None
    with suppress(RuntimeError):
        opts = get_options()
    return expandvars(os.path.expanduser(name), opts.env if opts else {})


def _custom_file_candidates(name: str, ext: str, search_dirs: Iterable[str]) -> Iterator[str]:
    # Exact name first, then with the extension added, so that names that
    # already have the extension or are absolute paths work as expected
    name = _expand_custom_path(name)
    names = (name,) if name.endswith(ext) else (name, name + ext)
    if os.path.isabs(name):
        yield from names
        return
    seen: set[str] = set()
    for d in search_dirs:
        if d:
            d = os.path.normpath(os.path.abspath(d))
            if d not in seen:
                seen.add(d)
                for n in names:
                    yield os.path.join(d, n)


def _read_first(candidates: Iterable[str], tried: list[str]) -> tuple[str, bytes]:
    for candidate in candidates:
        tried.append(candidate)
        try:
            with open(candidate, 'rb') as f:
                return os.path.abspath(candidate), f.read()
        except (FileNotFoundError, IsADirectoryError, NotADirectoryError):
            pass
    return '', b''


class CustomFileNotFound(FileNotFoundError):
    def __init__(self, name: str, tried: Sequence[str]):
        self.tried = tuple(tried)
        super().__init__(f'Could not find {name!r} amongst the builtins or at any of: {", ".join(self.tried)}')


def _builtin_src(reader: Callable[[str], bytes], name: str, tried: list[str]) -> bytes:
    try:
        return reader(name)
    except FileNotFoundError:
        raise CustomFileNotFound(name, tried) from None


@lru_cache(maxsize=64)
def custom_shader(name: str = '', pipeline_dir: str = '') -> tuple[str, str, bytes, bytes]:
    if not name:
        src = get_custom_shader_src('types')
        return name, '', src, key(src)

    tried: list[str] = []
    found_path, src = _read_first(_custom_file_candidates(name, '.slang', (pipeline_dir, os.path.join(config_dir, 'shaders'))), tried)
    if found_path:
        return found_path, os.path.dirname(found_path), src, key(src)
    src = _builtin_src(get_custom_shader_src, name.removesuffix('.slang'), tried)
    return name, '', src, key(src)


@lru_cache(maxsize=64)
def pipeline_definition(name: str) -> tuple[tuple[str, ...], str]:
    if name.endswith('.slang'):
        raise FileNotFoundError(f'{name} is a shader not a pipeline')
    tried: list[str] = []
    found_path, src = _read_first(
        (c for c in _custom_file_candidates(name, '.pipeline', (os.path.join(config_dir, 'shaders'),)) if c.endswith('.pipeline')), tried
    )
    if found_path:
        return tuple(src.decode().splitlines()), os.path.dirname(found_path)
    src = _builtin_src(get_custom_pipeline_src, name.removesuffix('.pipeline'), tried)
    return tuple(src.decode().splitlines()), ''


class NamedTexture(StrEnum):
    a = auto()
    b = auto()
    persist = auto()
    default = auto()


class Slot(StrEnum):
    end = auto()


def is_valid_named_texture(x: str) -> TypeGuard[NamedTexture]:
    return x in NamedTexture._value2member_map_


def is_valid_slot(x: str) -> TypeGuard[Slot]:
    return x in Slot._value2member_map_


VALID_VAR_TYPES: frozenset[str] = frozenset({'uint', 'int', 'float', 'double', 'bool'})
SHADER_ANIMATION_EVENTS: frozenset[str] = frozenset(
    {
        'pointer-left-button-press',
        'os-window-focus-in',
        'os-window-focus-out',
        'window-focus-in',
        'window-focus-out',
        'tab-change',
        'bell-in-window',
        'user-activity',
        'user-idle',
        'cursor-trail-move',
        'cursor-trail-stop',
    }
)


def is_valid_animation_event(name: str) -> bool:
    if name.startswith(USER_ANIMATION_EVENT_PREFIX):
        return is_valid_user_animation_event_name(name[len(USER_ANIMATION_EVENT_PREFIX) :])
    return name in SHADER_ANIMATION_EVENTS


def parse_animation_events(raw: str) -> tuple[str, ...]:
    events = raw.split('|')
    for e in events:
        if not is_valid_animation_event(e):
            if e.startswith(USER_ANIMATION_EVENT_PREFIX):
                raise ValueError(
                    f'{e!r} is not a valid user event name, the part after {USER_ANIMATION_EVENT_PREFIX} must be at most'
                    f' {MAX_SHADER_ANIM_USER_EVENT_NAME_LEN} letters, digits, underscores, hyphens or periods'
                )
            raise ValueError(
                f'{e!r} is not a valid animation event name; valid names: {", ".join(sorted(SHADER_ANIMATION_EVENTS))}'
                f' or {USER_ANIMATION_EVENT_PREFIX}<name> for events sent by the shader_event action'
            )
    return tuple(events)


def parse_css_animation_curve(spec: str) -> EasingFunction:
    _NAMED: dict[str, tuple[str, str]] = {
        'ease-in-out': ('cubic-bezier', '0.42, 0, 0.58, 1'),
        'linear': ('cubic-bezier', '0, 0, 1, 1'),
        'ease': ('cubic-bezier', '0.25, 0.1, 0.25, 1'),
        'ease-out': ('cubic-bezier', '0, 0, 0.58, 1'),
        'ease-in': ('cubic-bezier', '0.42, 0, 1, 1'),
        'step-start': ('steps', '1, start'),
        'step-end': ('steps', '1, end'),
    }

    def make(func_name: str, params: str) -> EasingFunction:
        if func_name == 'cubic-bezier':
            return EasingFunction.cubic_bezier(params)
        if func_name == 'linear':
            return EasingFunction.linear(params)
        if func_name == 'steps':
            return EasingFunction.steps(params)
        raise ValueError(f'{func_name!r} is not a valid easing function type')

    spec = spec.strip()
    if spec in _NAMED:
        return make(*_NAMED[spec])
    m = re.match(r'^([-a-zA-Z]+)\(([^)]+)\)$', spec)
    if m:
        return make(m.group(1), m.group(2))
    raise ValueError(f'{spec!r} is not a recognized CSS animation curve')


@run_once
def identifiers_pat() -> re.Pattern[str]:
    return re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')


def parse_var_directive(parts: list[str]) -> tuple[str, str, str]:
    if len(parts) < 4:
        raise ValueError('var directive requires: var <type> <name> [=] <value>')
    var_type = parts[1]
    q = var_type[:-1] if var_type and var_type[-1] in '234' else var_type
    if q not in VALID_VAR_TYPES:
        raise ValueError(f'var type {var_type!r} must be one of: {", ".join(sorted(VALID_VAR_TYPES))}')
    var_name = parts[2]
    if not identifiers_pat().match(var_name):
        raise ValueError(f'var name {var_name!r} is not a valid identifier')
    if parts[3] == '=':
        if len(parts) < 5:
            raise ValueError('var directive missing value after =')
        value = ' '.join(parts[4:])
    else:
        value = ' '.join(parts[3:])
    return var_type, var_name, value.rstrip(';')


def apply_pipeline_specializations(src: bytes, merged_vars: dict[str, tuple[str, str]]) -> bytes:
    if not merged_vars:
        return src
    text = src.decode()
    # Replace: static const <any_type> <name> = <default>; → static const <type> <name> = <value>;
    replacements = sorted(
        (v.type_start, v.end, f'{merged_vars[v.name][0]} {v.name} = {merged_vars[v.name][1]}')
        for v in parse_slang_declarations(text).variables
        if v.name in merged_vars and {'static', 'const'} <= v.modifiers and 'extern' not in v.modifiers
    )
    for start, end, replacement in reversed(replacements):
        text = text[:start] + replacement + text[end:]
    return text.encode()


class Group(TypedDict):
    pipeline_dir: str  # directory used to resolve shader names for this group
    viewport_pos: tuple[float, float]
    viewport_size: tuple[float, float]
    output_texture: NamedTexture
    shaders: tuple[str, ...]
    vars: dict[str, tuple[str, str]]
    animation_start: tuple[str, ...]  # empty = no animation
    animation_toggle: tuple[str, ...]  # events that start the animation if stopped and stop it if running
    animation_curve: EasingFunction  # parsed easing curve
    animation_step: int  # nanoseconds between animation samples
    animation_end_events: tuple[str, ...]  # events that stop the animation
    animation_end_duration: int  # nanoseconds; 0 = no time limit, negative = use cursor_stop_blinking_after
    animation_duration: int  # nanoseconds for animation_progress to reach one; negative = same as animation_end_duration
    animation_reverse: int  # nanoseconds to play the animation in reverse when stopped; 0 = no, negative = same as animation_duration
    animation_loops: int  # times to play the animation forwards and in reverse, only used with animation_reverse
    attached: bool  # if True, this group is always active when the previous group is active


class Pipeline(TypedDict):
    slot: Slot
    textures: tuple[NamedTexture, ...]
    groups: tuple[Group, ...]
    vars: dict[str, tuple[str, str]]
    pipeline_dir: str


@run_once
def trailing_comment_pat() -> re.Pattern[str]:
    return re.compile(r'\s#.*')


def parse_pipeline_definition(lines: Iterable[str], pipeline_name: str, pipeline_dir: str = '') -> Pipeline:
    slot = Slot.end
    textures: tuple[NamedTexture, ...] = ()
    groups: list[Group] = []
    current_group: Group | None = None
    pipeline_vars: dict[str, tuple[str, str]] = {}
    has_animation_stop = False

    def unit_float(x: str) -> float:
        return max(0, min(float(x), 1))

    def commit_group() -> None:
        nonlocal current_group
        if current_group is not None:
            if current_group['animation_toggle'] and not current_group['animation_start'] and not has_animation_stop:
                # A group turned on and off by toggling should stay on until toggled off
                current_group['animation_end_duration'] = 0
            if current_group['animation_loops'] > 1 and not current_group['animation_reverse']:
                raise ValueError('animation_loops can only be used together with animation_reverse')
            groups.append(current_group)
            current_group = None

    def init_group(*shaders: str) -> Group:
        return {
            'pipeline_dir': pipeline_dir,
            'viewport_pos': (0, 0),
            'viewport_size': (1, 1),
            'output_texture': NamedTexture.default,
            'shaders': shaders,
            'vars': {},
            'animation_start': (),
            'animation_toggle': (),
            'animation_curve': EasingFunction(),
            'animation_step': ANIMATION_SAMPLE_WAIT,
            'animation_end_events': (),
            'animation_end_duration': -1,
            'animation_duration': -1,
            'animation_reverse': 0,
            'animation_loops': 1,
            'attached': False,
        }

    for line in lines:
        # A # at the start of the line or preceded by whitespace starts a comment
        line = trailing_comment_pat().sub('', line).strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        if current_group is None:
            match parts[0]:
                case 'slot':
                    if not is_valid_slot(parts[1]):
                        raise ValueError(f'slot {parts[1]} is not valid')
                    slot = parts[1]
                case 'textures':
                    textures = tuple(map(NamedTexture, parts[1:]))
                case 'startgroup':
                    commit_group()
                    current_group = init_group()
                    has_animation_stop = False
                case 'var':
                    var_type, var_name, value = parse_var_directive(parts)
                    pipeline_vars[var_name] = (var_type, value)
                case _:
                    raise ValueError(f'Unknown key {parts[0]}')
        else:
            match parts[0]:
                case 'viewport_pos':
                    current_group['viewport_pos'] = unit_float(parts[1]), unit_float(parts[1 if len(parts) < 3 else 2])
                case 'viewport_size':
                    current_group['viewport_size'] = unit_float(parts[1]), unit_float(parts[1 if len(parts) < 3 else 2])
                case 'output_texture':
                    if not is_valid_named_texture(parts[1]):
                        raise ValueError(f'output_texture {parts[1]} does not appear in textures')
                    current_group['output_texture'] = parts[1]
                case 'shaders':
                    current_group['shaders'] += tuple(parts[1:])
                case 'var':
                    var_type, var_name, value = parse_var_directive(parts)
                    current_group['vars'][var_name] = (var_type, value)
                case 'animation_start':
                    val = ''.join(parts[1:]) if len(parts) > 1 else 'none'
                    current_group['animation_start'] = () if val == 'none' else parse_animation_events(val)
                case 'animation_toggle':
                    val = ''.join(parts[1:]) if len(parts) > 1 else 'none'
                    current_group['animation_toggle'] = () if val == 'none' else parse_animation_events(val)
                case 'animation_curve':
                    if len(parts) < 2:
                        raise ValueError('animation_curve requires a CSS curve name')
                    current_group['animation_curve'] = parse_css_animation_curve(' '.join(parts[1:]))
                case 'animation_step':
                    if len(parts) < 2:
                        raise ValueError('animation_step requires a millisecond value')
                    step_ms = int(parts[1])
                    if step_ms < 0:
                        raise ValueError(f'animation_step must be non-negative, not: {step_ms}')
                    current_group['animation_step'] = step_ms * 1_000_000
                case 'animation_stop':
                    has_animation_stop = True
                    val = ''.join(parts[1:]) if len(parts) > 1 else 'never'
                    if val == 'never':
                        current_group['animation_end_events'] = ()
                        current_group['animation_end_duration'] = 0
                    else:
                        end_events: list[str] = []
                        end_duration: int = 0
                        for token in val.split('|'):
                            try:
                                end_duration = int(token) * 1_000_000
                            except ValueError:
                                end_events.extend(parse_animation_events(token))
                        current_group['animation_end_events'] = tuple(end_events)
                        current_group['animation_end_duration'] = end_duration
                case 'animation_duration':
                    if len(parts) < 2:
                        raise ValueError('animation_duration requires a millisecond value')
                    duration_ms = int(parts[1])
                    if duration_ms < 0:
                        raise ValueError(f'animation_duration must be non-negative, not: {duration_ms}')
                    current_group['animation_duration'] = duration_ms * 1_000_000
                case 'animation_reverse':
                    val = parts[1] if len(parts) > 1 else 'yes'
                    match val:
                        case 'yes':
                            current_group['animation_reverse'] = -1
                        case 'no':
                            current_group['animation_reverse'] = 0
                        case _:
                            try:
                                reverse_ms = int(val)
                            except ValueError:
                                reverse_ms = -1
                            if reverse_ms < 0:
                                raise ValueError(f'animation_reverse must be yes, no or a non-negative number of milliseconds, not: {val}')
                            current_group['animation_reverse'] = reverse_ms * 1_000_000
                case 'animation_loops':
                    if len(parts) < 2:
                        raise ValueError('animation_loops requires a number')
                    loops = int(parts[1])
                    if not 1 <= loops < 2**31:
                        raise ValueError(f'animation_loops must be a positive number, not: {loops}')
                    current_group['animation_loops'] = loops
                case 'attach':
                    current_group['attached'] = True
                case 'endgroup':
                    commit_group()
                case _:
                    raise ValueError(f'Unknown key {parts[0]}')
    if current_group is not None:
        raise ValueError('Unclosed group present')
    groups = groups or [init_group(pipeline_name)]
    if len(groups) > MAX_CUSTOM_SHADER_GROUPS:
        raise ValueError(f'Pipeline {pipeline_name!r} has {len(groups)} groups but the maximum is {MAX_CUSTOM_SHADER_GROUPS}')
    if groups[0]['attached']:
        raise ValueError('The first group in a pipeline cannot use attach (no previous group to attach to)')
    if groups[-1]['output_texture'] is not NamedTexture.default:
        raise ValueError('The final group cannot output to a named texture')
    if groups[-1]['viewport_pos'] != (0, 0) or groups[-1]['viewport_size'] != (1, 1):
        raise ValueError('The final group must not specify a viewport')
    check_user_animation_events(groups, f'Pipeline {pipeline_name!r}')

    return {'slot': slot, 'textures': textures, 'groups': tuple(groups), 'vars': pipeline_vars, 'pipeline_dir': pipeline_dir}


@lru_cache(maxsize=32)
def parse_pipeline(name: str) -> Pipeline:
    lines, pipeline_dir = pipeline_definition(name)
    return parse_pipeline_definition(lines, name, pipeline_dir)


def user_animation_events(groups: Iterable[Group]) -> tuple[str, ...]:
    "The names, without the user: prefix, of all user events used by groups, in order of first use"
    ans: dict[str, None] = {}
    for g in groups:
        for e in chain(g['animation_start'], g['animation_toggle'], g['animation_end_events']):
            if e.startswith(USER_ANIMATION_EVENT_PREFIX):
                ans[e[len(USER_ANIMATION_EVENT_PREFIX) :]] = None
    return tuple(ans)


def check_user_animation_events(groups: Iterable[Group], what: str) -> None:
    if (n := len(user_animation_events(groups))) > MAX_SHADER_ANIM_USER_EVENTS:
        raise ValueError(f'{what} uses {n} user events but the maximum is {MAX_SHADER_ANIM_USER_EVENTS}')


def merge_pipelines(pipelines: list[Pipeline]) -> Pipeline:
    if len(pipelines) == 1:
        return pipelines[0]
    slot = pipelines[0]['slot']
    for p in pipelines[1:]:
        if p['slot'] != slot:
            raise ValueError(f'Cannot chain pipelines with different slots: {slot!r} vs {p["slot"]!r}')
    seen_textures: set[NamedTexture] = set()
    merged_textures: list[NamedTexture] = []
    for p in pipelines:
        for t in p['textures']:
            if t not in seen_textures:
                seen_textures.add(t)
                merged_textures.append(t)
    all_groups: list[Group] = []
    for p in pipelines:
        all_groups.extend(p['groups'])
    if len(all_groups) > MAX_CUSTOM_SHADER_GROUPS:
        raise ValueError(f'Chained pipelines have {len(all_groups)} groups combined but the maximum is {MAX_CUSTOM_SHADER_GROUPS}')
    if all_groups[-1]['output_texture'] is not NamedTexture.default:
        raise ValueError('The final group of the last pipeline cannot output to a named texture')
    if all_groups[-1]['viewport_pos'] != (0, 0) or all_groups[-1]['viewport_size'] != (1, 1):
        raise ValueError('The final group of the last pipeline must not specify a viewport')
    check_user_animation_events(all_groups, 'Chained pipelines')
    merged_vars: dict[str, tuple[str, str]] = {}
    for p in pipelines:
        merged_vars.update(p['vars'])
    return {
        'slot': slot,
        'textures': tuple(merged_textures),
        'groups': tuple(all_groups),
        'vars': merged_vars,
        'pipeline_dir': pipelines[0]['pipeline_dir'],
    }


def group_has_own_animation(group: Group) -> bool:
    "Whether the group is turned on and off by events of its own"
    return bool(group['animation_start'] or group['animation_toggle'])


def group_moves_content(group: Group) -> bool:
    """Whether whatever the shaders in a group do to the content is visible on
    the whole screen for as long as the group is active, which is either always
    or until an event turns the group off, as opposed to a transient effect that
    lasts for a fixed duration"""
    return (
        not group['attached']
        and group['output_texture'] is NamedTexture.default
        and group['viewport_pos'] == (0, 0)
        and group['viewport_size'] == (1, 1)
        and (not group_has_own_animation(group) or group['animation_end_duration'] == 0)
    )


def pointer_map_shaders(pipeline: Pipeline, defines_pointer_map: Callable[[int, int], bool]) -> tuple[tuple[int, int], ...]:
    """The (group, shader) indices of the shaders whose pointer_map() decides
    where pointer events land, in the order they must be applied. Only groups
    that draw to the whole screen and are active either always or until an
    event turns them off move content for any length of time, so only they
    count. The last shader to run decides what is
    visible at a given position, so it is applied first. defines_pointer_map()
    is called with the (group, shader) indices of the shaders that count."""
    ans: list[tuple[int, int]] = []
    for g_idx, group in enumerate(pipeline['groups']):
        if group_moves_content(group):
            ans.extend((g_idx, s_idx) for s_idx in range(len(group['shaders'])) if defines_pointer_map(g_idx, s_idx))
    return tuple(reversed(ans))


def defines_pointer_map(query: SlangShaderQuery) -> bool:
    if (func := query.function('pointer_map')) is None or not func.has_body:
        return False
    if 'public' not in func.modifiers:
        raise ValueError(f'The pointer_map() function in the shader {query.name} must be declared public')
    if not func.returns('float2', 'vector<float,2>'):
        raise ValueError(f'The pointer_map() function in the shader {query.name} must return float2 not {func.return_type}')
    return True


class PipelineIR(NamedTuple):
    import_dirs: tuple[str, ...]
    module_path: str
    pointer_map_shaders: tuple[tuple[int, int], ...]


def build_custom_shader_pipeline_ir(pipeline: Pipeline, cache_dir: str, invocation_tracker: set[tuple[str, ...]]) -> PipelineIR:
    slot = pipeline['slot']
    slot_module_name = f'{slot.replace("-", "_")}'
    cache_dir = os.path.join(cache_dir, 'c')
    ensure_cache_dir(cache_dir)
    slot_dir = os.path.join(cache_dir, slot)
    libdir = os.path.join(cache_dir, 'lib')
    import_dirs = [slot_dir, libdir]
    bc = list(slangc()) + ['-warnings-as-errors', 'all', '-lang', 'slang', '-I', libdir]
    _, _, ct_shader, ct_key = custom_shader()
    os.makedirs(libdir, exist_ok=True)
    os.makedirs(slot_dir, exist_ok=True)
    cache_ok = False
    mtime = 0
    types_rebuilt = False

    def entry_point(g_idx: int, s_idx: int, name: str = 'fragment_main') -> str:
        return f'{name}_{g_idx}_{s_idx}'

    j = partial(os.path.join, libdir)
    with suppress(FileNotFoundError), open(j('ct.key'), 'rb') as f:
        cache_ok = f.read() == ct_key
        mtime = max(mtime, os.fstat(f.fileno()).st_mtime_ns)
    if not cache_ok:
        cmd = bc + ['-module-name', 'kitty_custom_shader_types', '-o', j('kitty-custom-shader-types.slang-module'), '--', '-']
        invocation_tracker.add(tuple(cmd))
        cp = subprocess.run(cmd, input=ct_shader, capture_output=True)
        if cp.returncode != 0:
            raise SlangFailed('custom-types.slang', cp)
        ct_key_path = j('ct.key')
        with open(ct_key_path, 'wb') as f:
            f.write(ct_key)
        mtime = max(mtime, os.stat(ct_key_path).st_mtime_ns)
        types_rebuilt = True

    slot_key_parts: list[str | bytes] = [json.dumps(pipeline, sort_keys=True), get_custom_shader_src('pipeline'), str(POINTER_MAP_SIZE)]

    for group in pipeline['groups']:
        for name in group['shaders']:
            _path, import_dir, _src, content_key = custom_shader(name, group['pipeline_dir'])
            if import_dir and import_dir not in import_dirs:
                import_dirs.append(import_dir)
            slot_key_parts.append(content_key)
    slot_key = key(*slot_key_parts)
    slot_key_file = os.path.join(slot_dir, 'inputs.key')
    # What was learned about the shaders when building, needed to use the module
    slot_info_file = os.path.join(slot_dir, 'info.json')
    ans = os.path.join(slot_dir, f'{slot}.slang-module')
    if not types_rebuilt:
        with suppress(FileNotFoundError), open(slot_key_file, 'rb') as f:
            if f.read() == slot_key:
                with suppress(OSError, ValueError, KeyError, TypeError), open(slot_info_file) as f:
                    info = json.load(f)
                    pm = tuple((int(g), int(s)) for g, s in info['pointer_map_shaders'])
                    return PipelineIR(tuple(import_dirs), ans, pm)

    j = partial(os.path.join, slot_dir)
    imports = []
    queries: dict[tuple[int, int], SlangShaderQuery] = {}
    for g_idx, group in enumerate(pipeline['groups']):
        merged_vars = pipeline['vars'].copy()
        merged_vars.update(group['vars'])
        for s_idx, name in enumerate(group['shaders']):
            _path, import_dir, src, _content_key = custom_shader(name, group['pipeline_dir'])
            if import_dir and import_dir not in import_dirs:
                import_dirs.append(import_dir)
            src = apply_pipeline_specializations(src, merged_vars)
            queries[(g_idx, s_idx)] = SlangShaderQuery(src, name, (import_dir,) if import_dir else (), invocation_tracker)
            modname = f'm_{g_idx}_{s_idx}'
            imports.append(modname)
            module_file = j(f'{modname}.slang-module')
            inc = ['-I', import_dir] if import_dir else []
            defines = [f'-D{func}={entry_point(g_idx, s_idx, func)}' for func in ('fragment_main', 'pointer_map')]
            cmd = bc + inc + defines + ['-module-name', modname, '-o', module_file, '--', '-']
            invocation_tracker.add(tuple(cmd))
            cp = subprocess.run(cmd, input=src, capture_output=True)
            if cp.returncode != 0:
                raise SlangFailed(name, cp)
            mtime = max(mtime, os.stat(module_file).st_mtime_ns)
    # Generate group-branched PIPELINE code.
    # sRGB conversion is emitted in every group's branch, gated on the convert_to_srgb
    # parameter. The C caller sets it to true only for the last active group so that
    # inactive animated groups do not cause an extra blit draw call.
    pipeline_parts: list[str] = []
    for g_idx, group in enumerate(pipeline['groups']):
        calls = '\n'.join(f'        color = {entry_point(g_idx, i)}(color, t, csd);' for i in range(len(group['shaders'])))
        calls += '\n        if (convert_to_srgb) color = float4(linear2srgb(color.rgb), color.a);'
        prefix = '} else ' if g_idx else ''
        pipeline_parts.append(f'    {prefix}if (group == {g_idx}) {{\n{calls}')
    pipeline_parts.append('    }')
    pipeline_code = '\n'.join(pipeline_parts)

    mod_src = get_custom_shader_src('pipeline').decode()
    mod_src = mod_src.replace('// IMPORTS', '\n'.join(f'import {imp};' for imp in imports), 1)
    mod_src = mod_src.replace('// PIPELINE', pipeline_code, 1)
    pm = pointer_map_shaders(pipeline, lambda g, s: defines_pointer_map(queries[(g, s)]))

    def pointer_map_call(g: int, s: int) -> str:
        call = f'pos = {entry_point(g, s, "pointer_map")}(pos, csd);'
        if group_has_own_animation(pipeline['groups'][g]):
            # Applies only while the group is active
            call = f'if ((active_groups & {1 << g}u) != 0u) {call}'
        return call

    pointer_map_code = '\n    '.join(pointer_map_call(g, s) for g, s in pm)
    mod_src = mod_src.replace('// POINTER_MAP', pointer_map_code, 1)
    # subprocess.run(['bat', '-P', '-l', 'cpp'], input=mod_src.encode())

    with tempfile.TemporaryDirectory() as tdir:
        for x in import_dirs:
            inc.extend(('-I', x))
        cmd = bc + inc + [f'-DPOINTER_MAP_SIZE={POINTER_MAP_SIZE}', '-module-name', slot_module_name, '-o', ans, '--', '-']
        invocation_tracker.add(tuple(cmd))
        cp = subprocess.run(cmd, cwd=tdir, capture_output=True, input=mod_src.encode())
        if cp.returncode != 0:
            raise SlangFailed(f'{slot}.slang', cp)

    with open(slot_info_file, 'w') as f:
        json.dump({'pointer_map_shaders': pm}, f)
    with open(slot_key_file, 'wb') as f:
        f.write(slot_key)
    return PipelineIR(tuple(import_dirs), ans, pm)


def module_wrapper_for_slot(slot: str) -> bytes:
    return """
#language slang 2026
import MODULE;

struct VertexOutput {
    float2 texcoord : TEXCOORD;
    float4 position : SV_Position;
};

[shader("vertex")]
VertexOutput vmain_wrap(uint vertex_id : SV_VertexID) {
    float4 c = pipeline_vertex_main(vertex_id);
    return {float2(c[0], c[1]), float4(c[2], c[3], 0, 1)};
}

[shader("fragment")]
float4 fmain_wrap(
    float2 texcoord : TEXCOORD,
    uniform int group,
    uniform float4 viewport,
    uniform float animation_progress,
    uniform bool convert_to_srgb,
    uniform uint active_groups
) : SV_Target {
    return pipeline_fragment_main(texcoord, group, viewport, animation_progress, convert_to_srgb, active_groups);
}
        """.replace('MODULE', slot.replace('-', '_')).encode()


def build_custom_shader_pipeline_glsl(
    pipeline: Pipeline, cache_dir: str = '', invocation_tracker: set[tuple[str, ...]] | None = None
) -> tuple[str, str, dict[str, Any]]:
    import kitty.constants as kc

    cache_dir = os.path.join(cache_dir or kc.cache_dir(), 'shaders')
    os.makedirs(cache_dir, exist_ok=True)
    if invocation_tracker is None:
        invocation_tracker = set()

    with lock_with_file(
        os.path.join(cache_dir, 'lock'),
    ):
        pipeline_ir = build_custom_shader_pipeline_ir(pipeline, cache_dir, invocation_tracker)
        import_dirs, slang_module_path = pipeline_ir.import_dirs, pipeline_ir.module_path
        glsl_dir = os.path.join(os.path.dirname(os.path.dirname(slang_module_path)), 'glsl')
        os.makedirs(glsl_dir, exist_ok=True)
        module_mtime = safe_mtime(slang_module_path)
        slot = pipeline['slot']
        vertex = os.path.join(glsl_dir, f'{slot}.vert.glsl')
        fragment = os.path.join(glsl_dir, f'{slot}.frag.glsl')
        metadata = os.path.join(glsl_dir, f'{slot}.glsl.json')
        if module_mtime > safe_mtime(metadata):
            inc = []
            for x in import_dirs:
                inc.extend(('-I', x))
            cmd = (
                list(slangc())
                + inc
                + [
                    '-warnings-as-errors',
                    'all',
                    '-line-directive-mode',
                    'none',
                    '-lang',
                    'slang',
                    '-target',
                    'glsl',
                    '-profile',
                    f'glsl_{glsl_version}',
                ]
            )
            vcmd = cmd + ['-stage', 'vertex', '-entry', 'vmain_wrap', '-o', vertex, '--', '-']
            fcmd = cmd + ['-stage', 'fragment', '-entry', 'fmain_wrap', '-o', fragment, '--', '-']
            src = module_wrapper_for_slot(slot)
            invocation_tracker.add(tuple(vcmd))
            invocation_tracker.add(tuple(fcmd))
            v = subprocess.Popen(vcmd, stderr=subprocess.PIPE, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL)
            f = subprocess.Popen(fcmd, stderr=subprocess.PIPE, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL)
            assert v.stdin is not None and f.stdin is not None
            assert v.stderr is not None and f.stderr is not None
            v.stdin.write(src), v.stdin.close()
            f.stdin.write(src), f.stdin.close()
            try:
                if (rc := v.wait()) != 0:
                    raise SlangFailed(f'{slot}.vert.glsl', subprocess.CompletedProcess(vcmd, rc, stderr=v.stderr.read()))
                if (rc := f.wait()) != 0:
                    raise SlangFailed(f'{slot}.frag.glsl', subprocess.CompletedProcess(fcmd, rc, stderr=f.stderr.read()))
            finally:
                v.stderr.close()
                f.stderr.close()
            fixup_opengl_files((fragment, vertex))
        with open(vertex) as vf, open(fragment) as ff:
            m = glsl_metadata_for_shader(metadata)
            m['pipeline'] = pipeline
            m['has_pointer_map'] = bool(pipeline_ir.pointer_map_shaders)
            m['pointer_map_groups'] = sorted({g for g, _ in pipeline_ir.pointer_map_shaders})
            return vf.read(), ff.read(), m


def clear_caches() -> None:
    custom_shader.cache_clear()
    pipeline_definition.cache_clear()
    parse_pipeline.cache_clear()
    load_shader_programs.force_recompile_of_custom_shaders = True


def test_slang_build() -> None:

    if shutil.which(slangc()[0]) is None:
        raise AssertionError(f'The shader slang compiler ({slangc()[0]}) not in PATH: {os.environ.get("PATH")}')
    q = os.path.join(shaders_dir, 'graphics.spv')
    if not os.path.isfile(q):
        raise AssertionError(f'The compiled graphics shader {q} does not exist')
    if not get_shader_src('graphics'):
        raise AssertionError('Could not load graphics.slang shader source')
    src = b"""
#language slang 2026
[shader("vertex")]
float4 main(uint vertex_id : SV_VertexID) : SV_Position { return float4(vertex_id, 1, 0, 1); }
"""
    cp = subprocess.run(list(slangc()) + '-lang slang -entry main -stage vertex -target glsl -o /dev/stdout -- -'.split(), input=src, capture_output=True)
    if cp.returncode != 0:
        raise AssertionError(f'Test compile of shader to GLSL failed with returncode: {cp.returncode} and stderr: {cp.stderr.decode()}')


if __name__ == '__main__':
    main()
