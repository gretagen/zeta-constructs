local gen = {}
gen.name = "boot"

function gen.plan(cfg, sync)
  local path = "/boot/limine.conf"
  local content = sync.read_file(path)
  if not content then return {} end

  local changes = {}
  local new = content
  local globals_dirty = false

  -- timeout
  if cfg.boot.timeout then
    local t = tostring(cfg.boot.timeout)
    local updated, n = new:gsub("timeout:%s*%d+", "timeout: " .. t, 1)
    if n > 0 then
      new = updated
    elseif not new:match("timeout:") then
      new = "timeout: " .. t .. "\n" .. new
      globals_dirty = true
    end
    if new ~= content then globals_dirty = true end
  end

  -- wallpaper (only if key already present or explicitly set)
  -- NOTE: [^\n]* not .* — Lua's dot matches newlines, so .* here would
  -- swallow the rest of the file (entries and cmdline included).
  if cfg.boot.wallpaper and cfg.boot.wallpaper ~= "" then
    if new:match("wallpaper:") then
      new = new:gsub("wallpaper:[^\n]*", "wallpaper: " .. cfg.boot.wallpaper, 1)
      if not new:match("wallpaper_style:") then
        new = new:gsub("(wallpaper:[^\n]*)", "%1\nwallpaper_style: stretched", 1)
      else
        new = new:gsub("wallpaper_style:[^\n]*", "wallpaper_style: stretched", 1)
      end
    end
  end

  -- serial
  if cfg.boot.serial then
    if new:match("serial:") then
      new = new:gsub("serial:%s*%w+", "serial: yes", 1)
    end
  end

  if new ~= content then
    globals_dirty = true
  end

  -- Build desired shared cmdline extras (root identity + kernel_cmdline)
  -- Applied via chronos rewrite-limine after patching one existing cmdline.
  local cmdline_parts = {}
  if cfg.root_partuuid and cfg.root_partuuid ~= "PLACEHOLDER" then
    table.insert(cmdline_parts, "root=PARTUUID=" .. cfg.root_partuuid)
  else
    local current_cmdline_str = content:match("cmdline:%s*(%S[^\n]*)")
    if current_cmdline_str then
      local existing_root = current_cmdline_str:match("(root=%S+)")
      if existing_root then
        table.insert(cmdline_parts, existing_root)
      end
    end
  end

  -- Preserve rootflags from current default entry
  local current_cmdline_str = content:match("cmdline:%s*(%S[^\n]*)")
  local rootflags = current_cmdline_str and current_cmdline_str:match("(rootflags=%S+)")
  if rootflags then
    table.insert(cmdline_parts, rootflags)
  else
    table.insert(cmdline_parts, "rootflags=subvol=@")
  end
  table.insert(cmdline_parts, "rw")

  if cfg.kernel_cmdline and cfg.kernel_cmdline ~= "" then
    table.insert(cmdline_parts, cfg.kernel_cmdline)
  end

  -- Preserve init= from the current entry: it declares which init system
  -- boots (written by iniswap). Without this the rebuild silently drops it
  -- and the machine falls back to the default init on next boot. Skip if
  -- kernel_cmdline already carries one, to avoid duplicating the parameter.
  local has_init = table.concat(cmdline_parts, " "):find("init=") ~= nil
  if not has_init and current_cmdline_str then
    -- anchored: match "init=" at start or after whitespace so a trailing
    -- ".init=1" style param is not mistaken for the init declaration
    local init_param = current_cmdline_str:match("^init=%S+")
      or current_cmdline_str:match("%s(init=%S+)")
    if init_param then
      table.insert(cmdline_parts, init_param)
    end
  end

  local desired_cmdline = table.concat(cmdline_parts, " ")
  local need_cmdline = false
  if current_cmdline_str and current_cmdline_str ~= desired_cmdline then
    need_cmdline = true
    -- Patch only the first (default /Haliade SYS) cmdline so chronos can
    -- harvest extras; full multi-entry rewrite happens via chronos.
    new = new:gsub("cmdline:%s*[^\n]*", "cmdline: " .. desired_cmdline, 1)
  end

  if globals_dirty or need_cmdline or new ~= content or sync.repower then
    table.insert(changes, sync.change("~", "boot", "/boot/limine.conf",
      "update bootloader globals/cmdline", function()
        sync.write_file(path, new)
        -- Regenerate generation entries from snapshots
        sync.shell("chronos rewrite-limine")
      end))
  end

  return changes
end

return gen
