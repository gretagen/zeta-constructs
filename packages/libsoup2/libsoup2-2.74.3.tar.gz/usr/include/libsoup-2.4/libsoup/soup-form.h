/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/* 
 * Copyright 2008 Red Hat, Inc.
 */

#ifndef  __SOUP_FORM_H__
#define  __SOUP_FORM_H__ 1

#include <libsoup/soup-types.h>
#include <libsoup/soup-multipart.h>

G_BEGIN_DECLS

#define SOUP_FORM_MIME_TYPE_URLENCODED "application/x-www-form-urlencoded"
#define SOUP_FORM_MIME_TYPE_MULTIPART  "multipart/form-data"

SOUP_AVAILABLE_IN_2_4
GHashTable  *soup_form_decode           (const char   *encoded_form);
SOUP_AVAILABLE_IN_2_26
GHashTable  *soup_form_decode_multipart (SoupMessage  *msg,
					 const char   *file_control_name,
					 char        **filename,
					 char        **content_type,
					 SoupBuffer  **file);

SOUP_AVAILABLE_IN_2_4
char        *soup_form_encode           (const char   *first_field,
					 ...) G_GNUC_NULL_TERMINATED;
SOUP_AVAILABLE_IN_2_4
char        *soup_form_encode_hash      (GHashTable   *form_data_set);
SOUP_AVAILABLE_IN_2_4
char        *soup_form_encode_datalist  (GData       **form_data_set);
SOUP_AVAILABLE_IN_2_4
char        *soup_form_encode_valist    (const char   *first_field,
					 va_list       args);

#ifndef SOUP_DISABLE_DEPRECATED
/* Compatibility with libsoup 2.3.0 */
#define soup_form_decode_urlencoded      soup_form_decode
#define soup_form_encode_urlencoded      soup_form_encode_hash
#define soup_form_encode_urlencoded_list soup_form_encode_datalist
#endif

SOUP_AVAILABLE_IN_2_4
SoupMessage *soup_form_request_new                (const char     *method,
						   const char     *uri,
						   const char     *first_field,
						   ...) G_GNUC_NULL_TERMINATED;
SOUP_AVAILABLE_IN_2_4
SoupMessage *soup_form_request_new_from_hash      (const char     *method,
						   const char     *uri,
						   GHashTable     *form_data_set);
SOUP_AVAILABLE_IN_2_4
SoupMessage *soup_form_request_new_from_datalist  (const char     *method,
						   const char     *uri,
						   GData         **form_data_set);
SOUP_AVAILABLE_IN_2_26
SoupMessage *soup_form_request_new_from_multipart (const char     *uri,
						   SoupMultipart  *multipart);

G_END_DECLS

#endif /* __SOUP_FORM_H__ */
