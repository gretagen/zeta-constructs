
#ifndef WSDISCOVERYCLIENT_EXPORT_H
#define WSDISCOVERYCLIENT_EXPORT_H

#ifdef WSDISCOVERYCLIENT_STATIC_DEFINE
#  define WSDISCOVERYCLIENT_EXPORT
#  define WSDISCOVERYCLIENT_NO_EXPORT
#else
#  ifndef WSDISCOVERYCLIENT_EXPORT
#    ifdef KDSoapWSDiscoveryClient_EXPORTS
        /* We are building this library */
#      define WSDISCOVERYCLIENT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define WSDISCOVERYCLIENT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef WSDISCOVERYCLIENT_NO_EXPORT
#    define WSDISCOVERYCLIENT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef WSDISCOVERYCLIENT_DEPRECATED
#  define WSDISCOVERYCLIENT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef WSDISCOVERYCLIENT_DEPRECATED_EXPORT
#  define WSDISCOVERYCLIENT_DEPRECATED_EXPORT WSDISCOVERYCLIENT_EXPORT WSDISCOVERYCLIENT_DEPRECATED
#endif

#ifndef WSDISCOVERYCLIENT_DEPRECATED_NO_EXPORT
#  define WSDISCOVERYCLIENT_DEPRECATED_NO_EXPORT WSDISCOVERYCLIENT_NO_EXPORT WSDISCOVERYCLIENT_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef WSDISCOVERYCLIENT_NO_DEPRECATED
#    define WSDISCOVERYCLIENT_NO_DEPRECATED
#  endif
#endif

#endif /* WSDISCOVERYCLIENT_EXPORT_H */
