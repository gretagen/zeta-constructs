;; config.scm.in -- Making information accessible in -*- scheme -*- code.

(define-module (shepherd config)
  #:export (Version
            Prefix-dir
            %localstatedir
            %runstatedir
            %sysconfdir
            %localedir
            %pkglibdir
            bug-address
            package-name
            package-url))

(define Version "1.0.9")
(define Prefix-dir "/usr")
(define %localstatedir "/var")
(define %runstatedir "/var/run")
(define %sysconfdir "/etc")
(define %localedir "/usr/share/locale")
(define %pkglibdir "/usr/lib/shepherd")

(define bug-address "https://codeberg.org/shepherd/shepherd/issues")
(define package-name "GNU Shepherd")
(define package-url "https://shepherding.services")
