;; system.scm -- Low-level operating system interface.
;; Copyright (C) 2013-2014, 2016, 2018, 2020, 2022-2025 Ludovic Courtès <ludo@gnu.org>
;; Copyright (C) 2018 Carlo Zancanaro <carlo@zancanaro.id.au>
;; Copyright (C) 2020 Jan (janneke) Nieuwenhuizen <janneke@gnu.org>
;; Copyright (C) 2024 Jakob Kirsch <jakob.kirsch@web.de>
;;
;; This file is part of the GNU Shepherd.
;;
;; The GNU Shepherd is free software; you can redistribute it and/or modify it
;; under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3 of the License, or (at
;; your option) any later version.
;;
;; The GNU Shepherd is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with the GNU Shepherd.  If not, see <https://www.gnu.org/licenses/>.

(define-module (shepherd system)
  #:autoload   (shepherd support) (catch-system-error)
  #:use-module (system foreign)
  #:use-module (ice-9 binary-ports)
  #:use-module (ice-9 match)
  #:autoload   (ice-9 textual-ports) (get-string-all)
  #:use-module (rnrs bytevectors)
  #:use-module (srfi srfi-71)
  #:use-module (srfi srfi-26)
  #:export (disable-reboot-on-ctrl-alt-del
            reboot
            reboot-kexec
            kexec-supported?
            kexec-loaded?
            halt
            power-off
            max-file-descriptors
            prctl
            PR_SET_CHILD_SUBREAPER
            getpgid
            ipv6-only
            mark-as-close-on-exec
            SFD_CLOEXEC
            SFD_NONBLOCK
            signalfd
            consume-signalfd-siginfo
            block-signals
            unblock-signals
            set-blocked-signals
            with-blocked-signals
            wait-for-file-deletion
            %gzip-program
            %zstd-program
            without-automatic-finalization))

;; The <sys/reboot.h> constants.
(define RB_AUTOBOOT 19088743)
(define RB_HALT_SYSTEM 3454992675)
(define RB_POWER_OFF 1126301404)
(define RB_DISABLE_CAD 0)          ; integer | #f
(define RB_KEXEC 1163412803)                      ; integer | #f

(define (syscall->procedure return-type name argument-types)
  "Return a procedure that wraps the C function NAME using the dynamic FFI,
and that returns two values: NAME's return value, and errno.

If an error occurs while creating the binding, defer the error report until
the returned procedure is called."
  (catch #t
    (lambda ()
      (pointer->procedure return-type (dynamic-func name (dynamic-link))
                          argument-types
                          #:return-errno? #t))
    (lambda args
      (lambda _
        (throw 'system-error name  "~A" (list (strerror ENOSYS))
               (list ENOSYS))))))

(define %libc-reboot
  ;; libc's 'reboot' function as declared in <sys/reboot.h>.
  (let ((proc (syscall->procedure int "reboot" (list unsigned-int))))
    (define (howto->symbol howto)
      (cond ((eqv? howto RB_AUTOBOOT) 'RB_AUTOBOOT)
            ((eqv? howto RB_HALT_SYSTEM) 'RB_HALT_SYSTEM)
            ((eqv? howto RB_POWER_OFF) 'RB_POWER_OFF)
            (else howto)))

    (lambda (howto)
      (let ((ret err (proc howto)))
        (unless (zero? ret)
          (throw 'system-error "reboot" "~A: ~S"
                 (list (strerror err) (howto->symbol howto))
                 (list err)))))))

(define (disable-reboot-on-ctrl-alt-del)
  "Disable hard reboot upon ctrl-alt-del.  Instead, the kernel Linux will send
SIGINT to PID 1, which is responsible for cleaning things up gracefully.  See
ctrlaltdel(8) and see kernel/reboot.c in Linux."
  (when RB_DISABLE_CAD
    (%libc-reboot RB_DISABLE_CAD)))

(define (reboot)
  "Perform a hard reset of the system now.  Return #f on failure."
  (%libc-reboot RB_AUTOBOOT))

(define (reboot-kexec)
  "Execute kernel loaded with 'kexec -l' now.  Kexec is a feature of the
Linux kernel that allows you to instantly reboot into a new kernel while skipping
the BIOS phase.  Return #f on failure or throw an exception on non-Linux systems."
  (if RB_KEXEC
      (%libc-reboot RB_KEXEC)
      (throw 'system-error 'kexec  "~A" (list (strerror ENOSYS))
             (list ENOSYS))))

(define (kexec-supported?)
  "Return true if the system supports rebooting via kexec (this is normally
the case on Linux)."
  (->bool RB_KEXEC))

(define (kexec-loaded?)
  "Return true if a kexec image has been previously loaded (with the
@command{kexec -l} command or similar)."
  (catch 'system-error
    (lambda ()
      (string=? (string-trim-right
                 (call-with-input-file "/sys/kernel/kexec_loaded"
                   get-string-all))
                "1"))
    (const #f)))

(define (halt)
  "Halt the system.  Return #f on failure."
  (%libc-reboot RB_HALT_SYSTEM))

(define (power-off)
  "Stop system and switch power off if possible.  Return #f on failure."
  (%libc-reboot RB_POWER_OFF))


(define _SC_OPEN_MAX 4)

(define sysconf
  (let ((proc (syscall->procedure long "sysconf" (list int))))
    (lambda (name)
      "Return the system configuration for NAME."
      (let ((result err (proc name)))
        (if (= -1 result)
            (throw 'system-error "sysconf" "~A: ~S"
                   (list (strerror err) name)
                   (list err))
            result)))))

(define PR_SET_CHILD_SUBREAPER 36)

(define prctl
  (let ((proc (syscall->procedure long "prctl" (list int int))))
    (lambda (process operation)
      "Perform an operation on the given process"
      (let ((result err (proc process operation)))
        (if (= -1 result)
            (throw 'system-error "prctl" "~A"
                   (list (strerror err))
                   (list err))
            result)))))

(define (max-file-descriptors)
  "Return the maximum number of open file descriptors allowed."
  (sysconf _SC_OPEN_MAX))

(define getpgid
  ;; Guile 3.0.2 lacks 'getpgid'.
  (let ((proc (syscall->procedure int "getpgid" (list int))))
    (lambda (pid)
      "Return the process group ID for process PID."
      (let ((result err (proc pid)))
        (if (= -1 result)
            (throw 'system-error "getpgid" "~A"
                   (list (strerror err))
                   (list err))
            result)))))

(define (ipv6-only port)
  "Make PORT, a file port backed by a socket, IPv6-only (using the IPV6_V6ONLY
socket option) and return PORT.

This is useful when willing to make a listening socket that operates on IPv6
only (by default, Linux binds AF_INET6 addresses on IPv4 as well)."
  (setsockopt port IPPROTO_IPV6 IPV6_V6ONLY 1)
  port)

(define-syntax define-as-needed             ;copied from (guix build syscalls)
  (syntax-rules ()
    "Define VARIABLE.  If VARIABLE already exists in (guile) then re-export it,
  otherwise export the newly-defined VARIABLE."
    ((_ (proc args ...) body ...)
     (define-as-needed proc (lambda* (args ...) body ...)))
    ((_ variable value)
     (if (module-defined? the-scm-module 'variable)
         (module-re-export! (current-module) '(variable))
         (begin
           (module-define! (current-module) 'variable value)
           (module-export! (current-module) '(variable)))))))

(define (allocate-sigset)
  (bytevector->pointer (make-bytevector 128)))

(define sigemptyset
  (syscall->procedure int "sigemptyset" '(*)))

(define sigaddset
  (syscall->procedure int "sigaddset" `(* ,int)))

(define sigismember
  (let ((proc (syscall->procedure int "sigismember" `(* ,int))))
    (lambda (set signal)
      (not (zero? (proc set signal))))))

(define (sigset signals)
  "Return a pointer to a fresh 'sigset_t' for SIGNALS."
  (let ((set (allocate-sigset)))
    (sigemptyset set)
    (for-each (cut sigaddset set <>) signals)
    set))

(define sigset->list
  (let ((all-signals
         (filter integer?
                 (module-map (lambda (symbol variable)
                               (let ((str (symbol->string symbol)))
                                 (and (string-prefix? "SIG" str)
                                      (not (string-prefix? "SIG_" str))
                                      (variable-ref variable))))
                             (resolve-interface '(guile))))))
    (lambda (set)
      "Return the list of integers (signal numbers) corresponding to SET, a
sigset pointer."
      (filter (cut sigismember set <>) all-signals))))

(define (mark-as-close-on-exec/portable)
  "Mark all the open file descriptors except standard input, standard output,
and standard error (that is, 3 and above) as close-on-exec---slow but portable
version."
  (define max-fd
    (max-file-descriptors))

  (let loop ((fd 3))
    (when (< fd max-fd)
      (catch-system-error
       (let ((flags (fcntl fd F_GETFD)))
         (when (zero? (logand flags FD_CLOEXEC))
           (fcntl fd F_SETFD (logior FD_CLOEXEC flags)))))
      (loop (+ fd 1)))))

(define CLOSE_RANGE_CLOEXEC 4)

(define max-unsigned-int
  ;; Maximum value for C 'unsigned int'.
  (- (expt 2 (* 8 (sizeof unsigned-int)))
     1))

(define close-range
  (let ((proc (syscall->procedure int "close_range"
                                  (list unsigned-int unsigned-int
                                        unsigned-int))))
    (lambda* (#:optional
              (first 0)
              (last max-unsigned-int)
              (flags CLOSE_RANGE_CLOEXEC))
      "Close or mark as close-on-exec (depending on @var{flags}) all open
file descriptors from @var{first} to @var{last}."
      (proc first last flags))))

(define mark-as-close-on-exec
  (if (= 0 CLOSE_RANGE_CLOEXEC)                   ;to be on the safe side
      mark-as-close-on-exec/portable
      (lambda ()
        "Mark all the open file descriptors except standard input, standard
output, and standard error (that is, 3 and above) as close-on-exec."
        (catch 'system-error
          (lambda ()
            (close-range 3))
          (lambda args
            (if (= ENOSYS (system-error-errno args))
                (mark-as-close-on-exec/portable)
                (apply throw args)))))))

(define %sizeof-struct-signalfd-siginfo
  ;; Size of 'struct signalfd_siginfo' or zero if it doesn't exist, as is the
  ;; case on GNU/Hurd.
  128)

;; The following constants are set to zero on non-Linux systems.
(define SFD_CLOEXEC 524288)
(define SFD_NONBLOCK 2048)

(define signalfd
  (let ((proc (syscall->procedure int "signalfd" `(,int * ,int))))
    (lambda* (fd signals #:optional (flags SFD_CLOEXEC))
      "Return an open input port over a signal file descriptor for SIGNALS, a
list of signal constants; if FD is -1, a new file descriptor is allocated,
otherwise FD is returned and its associated state is updated.  FLAGS must be a
bitmask of SFD_CLOEXEC or SFD_NONBLOCK."
      (fdopen (proc fd (sigset signals) flags) "r0"))))

(define (consume-signalfd-siginfo port)
  "Read a 'signalfd_siginfo' structure from PORT and discard it.  Return the
number of the signal received."
  (let ((bv (get-bytevector-n port %sizeof-struct-signalfd-siginfo)))
    ;; The first 'uint32_t' field of 'struct signalfd_siginfo' is the signal
    ;; number.
    (bytevector-u32-native-ref bv 0)))

(define SIG_BLOCK 0)
(define SIG_UNBLOCK 1)
(define SIG_SETMASK 2)

(define sigprocmask
  (let ((proc (syscall->procedure int "pthread_sigmask" `(,int * *))))
    (lambda (how signals)
      "Add SIGNALS, a list of SIG* values, to the set of blocked signals if
HOW is SIG_BLOCK, or unblock them if HOW is SIG_UNBLOCK.  Return the previous
set of blocked signals as a list of SIG* values."
      (define old
        (allocate-sigset))

      (let ((result err (proc how (sigset signals) old)))
        (if (= -1 result)
            (throw 'system-error "sigprocmask" "~A"
                   (list (strerror err)) (list err))
            (sigset->list old))))))

(define (block-signals signals)
  "Block SIGNALS, a list of SIG* values, in the current thread."
  (sigprocmask SIG_BLOCK signals))

(define (unblock-signals signals)
  "Unblock SIGNALS, a list of SIG* values, in the current thread."
  (sigprocmask SIG_UNBLOCK signals))

(define (set-blocked-signals signals)
  "Block exactly the signals listed in SIGNALS, a list of SIG* values, in the
current thread."
  (sigprocmask SIG_SETMASK signals))

(define (call-with-blocked-signals signals thunk)
  (let ((previous-set #f))
    (dynamic-wind
      (lambda ()
        (set! previous-set (block-signals signals)))
      thunk
      (lambda ()
        (set-blocked-signals previous-set)))))

(define-syntax-rule (with-blocked-signals signals exp ...)
  "Evaluate EXP... in a context where SIGNALS are blocked."
  (call-with-blocked-signals signals (lambda () exp ...)))


;;;
;;; File monitoring.
;;;

(define IN_NONBLOCK 2048)
(define IN_CLOEXEC 524288)

(define IN_DELETE_SELF 1024)
(define IN_ATTRIB 4)

(define inotify-init
  (let ((proc (syscall->procedure int "inotify_init1" (list int))))
    (lambda* (#:optional (flags (logior IN_NONBLOCK IN_CLOEXEC)))
      "Return an input port for an inotify instance with the given
@var{flags}, a bitwise or of @code{IN_} constants."
      (fdopen (proc flags) "r0"))))

(define inotify-add-watch
  (let ((proc (syscall->procedure int "inotify_add_watch"
                                  (list int '* uint32))))
    (lambda (port file mask)
      "Add to @var{port}, a port as returned by @code{inotify-init}, the
given @var{file} to watch.  The set of events to monitor is specified by
@var{mask}, a bitwise or of @code{IN_} constants.  Return a @dfn{watch
descriptor} for @var{file}, a non-negative integer."
      (proc (fileno port)
            (string->pointer file)
            mask))))

(define %inotify-event-struct
  (list int                                       ;wd
        uint32                                    ;mask
        uint32                                    ;cookie
        uint32))                                  ;len

(define (read-inotify-event port)
  "Read an @code{inotify_event} struct from @var{port}.  Return true or the
end-of-file object."
  (let ((bv (get-bytevector-n port (sizeof %inotify-event-struct))))
    (if (eof-object? bv)
        bv
        (match (parse-c-struct (bytevector->pointer bv) %inotify-event-struct)
          ((wd mask cookie name-length)
           (when (> name-length 0)
             (get-bytevector-n port name-length))
           #t)))))

(define wait-for-file-deletion
  (cond ((string-contains %host-type "linux")
         (lambda (file)
           "Wait for the deletion of @var{file} and return.  This implementation uses
inotify."
           ;; Since IN_DELETE_SELF events won't fire as long as there exists
           ;; an open file descriptor on FILE (which is the case for
           ;; shepherd's listening socket), watch IN_ATTRIB as well and check
           ;; whether FILE still exists when it fires.
           (let* ((port (inotify-init))
                  (watch (catch 'system-error
                           (lambda ()
                             (inotify-add-watch port file
                                                (logior IN_ATTRIB
                                                        IN_DELETE_SELF)))
                           (lambda args
                             (if (= ENOENT (system-error-errno args))
                                 #f
                                 (apply throw args))))))
             (when watch
               (let loop ()
                 (read-inotify-event port)
                 (when (file-exists? file)
                   (loop))))
             (close-port port)
             #t)))
        ;; TODO: Implement with 'dir_notice_changes' on GNU/Hurd.
        (else
         (lambda (file)
           "Wait for the deletion of @var{file} and return."
           (let loop ()                 ;naive implementation, without inotify
             (if (file-exists? file)
                 (begin
                   (sleep 60)
                   (loop))
                 #t))))))


;;;
;;; External programs.
;;;

(define %gzip-program "/usr/bin/gzip")
(define %zstd-program "/usr/bin/zstd")


;;;
;;; Guile shenanigans.
;;;

(define %set-automatic-finalization-enabled?!
  ;; When using a statically-linked Guile, for instance in the initrd, we
  ;; cannot resolve this symbol, but most of the time we don't need it
  ;; anyway.  Thus, delay it.
  (let ((proc (delay
                (pointer->procedure int
                                    (dynamic-func
                                     "scm_set_automatic_finalization_enabled"
                                     (dynamic-link))
                                    (list int)))))
    (lambda (enabled?)
      "Switch on or off automatic finalization in a separate thread.
Turning finalization off shuts down the finalization thread as a side effect."
      (->bool ((force proc) (if enabled? 1 0))))))

(define-syntax-rule (without-automatic-finalization exp ...)
  "Turn off automatic finalization within the dynamic extent of EXP."
  (let ((enabled? #t))
    (dynamic-wind
      (lambda ()
        (set! enabled? (%set-automatic-finalization-enabled?! #f)))
      (lambda ()
        exp ...)
      (lambda ()
        (%set-automatic-finalization-enabled?! enabled?)))))
