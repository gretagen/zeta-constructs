#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::NewStuffCore" for configuration ""
set_property(TARGET KF6::NewStuffCore APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6::NewStuffCore PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "KF6::Archive;KF6::I18n;KF6::ConfigCore;KF6::Package;Qt6::Xml;KF6::Syndication"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKF6NewStuffCore.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKF6NewStuffCore.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::NewStuffCore )
list(APPEND _cmake_import_check_files_for_KF6::NewStuffCore "${_IMPORT_PREFIX}/lib64/libKF6NewStuffCore.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
