---
layout: user-guide
permalink: /user-guide/language-version
---

# Language Version

Like many programming languages, Slang experiences a tension between the desire for rapid innovation/evolution and stability. One of the benefits that users of Slang have so far enjoyed has been the rapid pace of innovation in the language and its standard library. However, as developers start to have larger bodies of Slang code, they may become concerned that changes to the language could break existing code. There is no magical way to keep innovating while also keeping the language static.

Slang supports using the `#language` preprocessor directive, as well as the `-std` compiler option (`CompilerOptionName::LanguageVersion`) to specify the language version that a translation unit is written against.
The translation unit will then be parsed and checked by the compiler using the rules from the specified language version.
If a translation unit has multiple primary source files, a `#language` directive in any of them selects the version for the complete module, and all such directives must agree.

Users are advised to provide a `#language` directive as the first non-whitespace line in their source file, such as:

```
#language slang 2026
```

The following language versions are recognized by the compiler:

Language version | Aliases         | Development status  | Remarks
---------------- | --------------- | ------------------- | --------------------------------------------
2018             | default, legacy | Stable              | Current default, breaking changes avoided
2025             | 202a            | Stable              | Breaking changes avoided
2026             | 202b, latest    | Stable              | Breaking changes avoided
202c             | next            | In development      | Development version, expect breaking changes

If no `#language` line exists and no version is specified via compiler options, the default setting is `legacy`.

## The Legacy Slang Language

When the language version is set to `legacy`, the compiler behavior will be consistent with the Slang language as in 2018-2023. Specifically:

- All declarations have `public` visibility.
- A `module` declaration is not required at the start of each module.

## Slang 2025

Slang language version 2025 brings these changes on top of the legacy language:

- All declarations have `internal` visibility.
- A `module` declaration is required at the start of each module.
- Modifier `volatile` has been deprecated in Slang. See GitHub issue
  [#10614](https://github.com/shader-slang/slang/issues/10614) for details. The modifier is still accepted
  in GLSL source code for compatibility reasons.
- Compile-time for (`$for`) has been deprecated. Use `[ForceUnroll] for` instead. See GitHub issue
  [#13065](https://github.com/shader-slang/slang/issues/13065) for details.

## Slang 2026

Slang language version 2026 brings these changes on top of Slang 2025:

- Comma expression is removed when it is used inside a parenthesis. The expression `(a, b)` no longer evaluates to have `b`'s type as in C/C++. Instead, `(a,b)` means `makeTuple(a,b)` and returns a tuple consisting of `a` and `b`. See [SP#027](https://github.com/shader-slang/spec/blob/main/proposals/027-tuple-syntax.md) for details.
- Users must explicitly opt in to enable dynamic dispatch with the `dyn` keyword. More rigorous validations are enabled to make sure dynamic dispatch is not triggered accidentally. See [SP#024](https://github.com/shader-slang/spec/blob/main/proposals/024-any-dyn-types.md) for details.
- Modifier `volatile` has been removed from Slang. See GitHub issue
  [#10614](https://github.com/shader-slang/slang/issues/10614) for details. The modifier is still accepted
  in GLSL source code for compatibility reasons.
- Interface-typed variables can no longer be default-initialized. See GitHub issue
  [#9191](https://github.com/shader-slang/slang/issues/9191) for details.
- Constructing a 4-dimensional vector from `(vector<T,2>, T)` and `(T, vector<T,2>)` has been removed. In previous language
  versions, these initializers implicitly converted the scalar `T` argument into a `vector<T,2>`, producing unexpected results.
  See GitHub issue [#12093](https://github.com/shader-slang/slang/issues/12093) for details.
- Casting a literal `0` to a user-defined struct type (e.g., `(MyStruct)0`) triggers a warning about future
  compatibility (see _Slang 202c_).
- A `struct` can no longer inherit from another `struct`. Use composition (struct as a member) instead. See
  GitHub issue [#7420](https://github.com/shader-slang/slang/issues/7420) for details.

## Slang 202c (in development)

Slang language version 202c brings these changes on top of Slang 2026:

- The generic-parameter-count overload tie-breaker has been removed.
  Older compilers treated required generic-parameter count as an ordinary ranking rule and
  preferred the candidate with fewer required parameters at that fixed point in overload
  resolution.
  When the current compiler operates in a pre-202c language mode, ordinary rules such as scope and
  `OverloadRank` run first.
  Only when every ordinary rule leaves the candidates tied does it use generic-parameter count as a
  compatibility fallback and emit a deprecation warning if that fallback selects a unique
  candidate.
  This reordering can silently select a different candidate than an older compiler when an ordinary
  rule now resolves the call before the compatibility fallback is reached.
  The warning is diagnostic `40021`; suppress it with `-warnings-disable 40021` or promote it to an
  error with `-warnings-as-errors 40021`.
  Such a call is ambiguous in Slang 202c unless another ranking rule distinguishes the candidates.
  A non-generic overload is more specific than an otherwise-equivalent specialization of a
  generic, including when all of the generic parameters have defaults; that ordinary rule applies
  in every language version.
- Casting a literal `0` to a user-defined struct type (e.g., `(MyStruct)0`) has lost its special meaning, and
  it is now a regular conversion. To maintain the previous semantics, a constructor call with no arguments can
  be used instead (e.g., `MyStruct()`). See GitHub issue
  [#12045](https://github.com/shader-slang/slang/issues/12045) for details.
- Compile-time for (`$for`) has been removed from the language. Use `[ForceUnroll] for` instead. See GitHub issue
  [#13065](https://github.com/shader-slang/slang/issues/13065) for details.
- A non-void function must `return` a value or `throw` on every path that reaches the end of its body. Failure
  to do so is diagnosed as an error in Slang 202c. Earlier versions report a warning, and an error only for
  targets that require a return value (SPIR-V, GLSL and WGSL). To migrate, add an explicit `return` at the end
  of the function where required. See GitHub issue
  [#12264](https://github.com/shader-slang/slang/issues/12264) for details.
