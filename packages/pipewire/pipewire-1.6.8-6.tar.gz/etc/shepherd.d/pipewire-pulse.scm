;; pipewire-pulse — standalone daemon after pipewire.
(haliade-service!
 'pipewire-pulse
 (service
  '(pipewire-pulse)
  #:requirement '(pipewire)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "exec setpriv --reuid=$(id -u pipewire) --regid=$(id -g pipewire) --init-groups env PIPEWIRE_RUNTIME_DIR=/run/pipewire XDG_STATE_HOME=/var/lib dbus-run-session /usr/bin/pipewire-pulse"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
