;; pipewire-pulse — standalone daemon after pipewire.
(haliade-service!
 'pipewire-pulse
 (service
  '(pipewire-pulse)
  #:requirement '(pipewire)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "umask 000; install -m 755 -g pipewire -o pipewire -d /run/pipewire /run/pipewire/pulse 2>/dev/null || true; exec setpriv --reuid=$(id -u pipewire) --regid=$(id -g pipewire) --init-groups env PIPEWIRE_RUNTIME_DIR=/run/pipewire PULSE_RUNTIME_PATH=/run/pipewire/pulse XDG_STATE_HOME=/var/lib /usr/bin/pipewire-pulse"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
