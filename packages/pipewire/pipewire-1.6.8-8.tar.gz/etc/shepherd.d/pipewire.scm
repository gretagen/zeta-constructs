;; PipeWire — private session bus + pipewire user (Void's model); the
;; bounded bus wait is the fails-open stand-in for dinit's depends-on
;; dbus readiness (same pattern as iwd.scm).
(haliade-service!
 'pipewire
 (service
  '(pipewire)
  #:requirement '(boot dbus)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "umask 000; install -m 755 -g pipewire -o pipewire -d /run/pipewire 2>/dev/null || true; n=0; until [ -S /run/dbus/system_bus_socket ]; do n=$((n+1)); [ $n -ge 5 ] && break; sleep 1; done; exec setpriv --reuid=$(id -u pipewire) --regid=$(id -g pipewire) --init-groups env PIPEWIRE_RUNTIME_DIR=/run/pipewire XDG_STATE_HOME=/var/lib /usr/bin/pipewire"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
