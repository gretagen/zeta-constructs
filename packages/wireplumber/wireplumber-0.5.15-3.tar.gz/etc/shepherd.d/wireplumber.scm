;; WirePlumber — session manager over pipewire's native socket (no bus).
(haliade-service!
 'wireplumber
 (service
  '(wireplumber)
  #:requirement '(pipewire)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "exec setpriv --reuid=$(id -u pipewire) --regid=$(id -g pipewire) --init-groups env PIPEWIRE_RUNTIME_DIR=/run/pipewire /usr/bin/wireplumber"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
