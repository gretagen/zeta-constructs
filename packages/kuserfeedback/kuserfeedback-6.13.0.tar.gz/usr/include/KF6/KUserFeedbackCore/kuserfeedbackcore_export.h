
#ifndef KUSERFEEDBACKCORE_EXPORT_H
#define KUSERFEEDBACKCORE_EXPORT_H

#ifdef KUSERFEEDBACKCORE_STATIC_DEFINE
#  define KUSERFEEDBACKCORE_EXPORT
#  define KUSERFEEDBACKCORE_NO_EXPORT
#else
#  ifndef KUSERFEEDBACKCORE_EXPORT
#    ifdef KF6UserFeedbackCore_EXPORTS
        /* We are building this library */
#      define KUSERFEEDBACKCORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KUSERFEEDBACKCORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KUSERFEEDBACKCORE_NO_EXPORT
#    define KUSERFEEDBACKCORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KUSERFEEDBACKCORE_DEPRECATED
#  define KUSERFEEDBACKCORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KUSERFEEDBACKCORE_DEPRECATED_EXPORT
#  define KUSERFEEDBACKCORE_DEPRECATED_EXPORT KUSERFEEDBACKCORE_EXPORT KUSERFEEDBACKCORE_DEPRECATED
#endif

#ifndef KUSERFEEDBACKCORE_DEPRECATED_NO_EXPORT
#  define KUSERFEEDBACKCORE_DEPRECATED_NO_EXPORT KUSERFEEDBACKCORE_NO_EXPORT KUSERFEEDBACKCORE_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KUSERFEEDBACKCORE_NO_DEPRECATED
#    define KUSERFEEDBACKCORE_NO_DEPRECATED
#  endif
#endif

#endif /* KUSERFEEDBACKCORE_EXPORT_H */
