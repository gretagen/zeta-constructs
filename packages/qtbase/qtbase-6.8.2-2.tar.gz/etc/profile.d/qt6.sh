#!/bin/sh
# Qt6 plugin path configuration
export QT_PLUGIN_PATH=/usr/lib/qt6/plugins
export QT_QPA_PLATFORM_PLUGIN_PATH=/usr/lib/qt6/plugins/platforms
