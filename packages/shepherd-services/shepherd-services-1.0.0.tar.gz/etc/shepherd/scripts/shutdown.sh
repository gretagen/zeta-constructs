#!/bin/sh
# dinit shutdown hook — final system teardown (Haliade OS)
# Ported from runit-services/stage3.sh. dinit itself has already stopped
# every supervised daemon in reverse dependency order (and it performs the
# final halt/reboot/poweroff), so this hook only covers the bits OpenRC's
# shutdown runlevel did that are not daemon supervision:
#   - /etc/local.d/*.stop      (local stop)
#   - unmount network shares   (netmount stop)
#   - persist the RNG seed     (seedrng stop)
#   - save clock to RTC        (hwclock stop)
#   - drop swap                (swap stop)
#   - sync
# Invoked via the "shutdown-hooks" service's stop-command, so it runs once
# dinit rolls the service graph down during dinit-halt/reboot/poweroff.
exec 2>&1
export PATH=/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin

echo "dinit shutdown hook — finalizing system"

# local stop (default runlevel .stop scripts)
if [ -d /etc/local.d ]; then
    for file in /etc/local.d/*.stop; do
        [ -x "$file" ] && "$file"
    done
fi

# netmount stop: unmount network filesystems
awk '$3 ~ /^(nfs|nfs4|smbfs|cifs|fuse.sshfs)$/ {print $2}' /proc/mounts 2>/dev/null | \
while read -r mp; do
    umount "$mp" 2>/dev/null || true
done

# seedrng stop: persist the RNG seed
if command -v seedrng >/dev/null 2>&1; then
    seedrng 2>/dev/null || true
fi

# hwclock stop: save system clock to hardware clock
if [ -x /sbin/hwclock ] && [ -e /etc/conf.d/hwclock ]; then
    . /etc/conf.d/hwclock
    case "${clock:-UTC}" in
    UTC)   hwclock --systohc --utc 2>/dev/null || true ;;
    local) hwclock --systohc --localtime 2>/dev/null || true ;;
    esac
fi

# deactivate swap
swapoff -a 2>/dev/null || true

sync
exit 0