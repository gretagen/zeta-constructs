#!/bin/sh
# dinit sysinit/rcboot — early boot (Haliade OS)
# Ported from runit-services/stage1.sh: mirrors OpenRC sysinit + boot
# runlevels (mounts, device nodes, udev, fonts/keymaps, modules, sysctl,
# network prep, fsck, swap, localmount, bootmisc, local.d, clear screen).
#
# Run by the dinit "sysinit" scripted service.
exec 2>&1
export PATH=/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin

# ---------------------------------------------------------------------------
# sysinit runlevel
# ---------------------------------------------------------------------------

# Mount virtual filesystems (skip if already mounted by initramfs)
mountpoint -q /proc    || mount -t proc proc /proc
mountpoint -q /sys     || mount -t sysfs sysfs /sys
mountpoint -q /dev     || mount -t devtmpfs devtmpfs /dev
mkdir -p /dev/pts
# devpts (mirrors OpenRC mount-devpts): check the kernel provides devpts,
# REMOUNT even if one already exists (an initramfs/udev mount may lack
# gid/mode/ptmxmode and break PTY allocation — OpenRC unmounts first for
# exactly this reason), keep /dev/ptmx populated, and surface failures
# instead of swallowing them (a silent failure looks like sshd's
# "PTY allocation request failed" or Xorg's "not enough ptys" later).
if grep -Eq "[[:space:]]+devpts$" /proc/filesystems 2>/dev/null; then
    if mountpoint -q /dev/pts; then
        umount /dev/pts 2>/dev/null || true
    fi
    mount -t devpts -o noexec,nosuid,gid=5,mode=0620,ptmxmode=0666 devpts /dev/pts || \
        echo "devpts: mount on /dev/pts failed (PTY allocation will not work)" >&2
else
    echo "devpts: not available in kernel (/proc/filesystems), skipping" >&2
fi
[ -c /dev/ptmx ] || mknod -m 666 /dev/ptmx c 5 2
mountpoint -q /run     || mount -t tmpfs tmpfs /run
mountpoint -q /tmp     || mount -t tmpfs tmpfs /tmp

# devfs: seed /dev with the minimum the kernel does not provide
[ -c /dev/console ] || mknod -m 600 /dev/console c 5 1
[ -c /dev/tty1 ]    || mknod -m 620 /dev/tty1 c 4 1
[ -c /dev/tty ]     || mknod -m 666 /dev/tty c 5 0
[ -c /dev/null ]    || mknod -m 666 /dev/null c 1 3
[ -c /dev/kmsg ]    || mknod -m 660 /dev/kmsg c 1 11
[ -e /dev/fd ]      || ln -snf /proc/self/fd /dev/fd
[ -e /dev/stdin ]   || ln -snf /proc/self/fd/0 /dev/stdin
[ -e /dev/stdout ]  || ln -snf /proc/self/fd/1 /dev/stdout
[ -e /dev/stderr ]  || ln -snf /proc/self/fd/2 /dev/stderr
[ -e /proc/kcore ]  && ln -snf /proc/kcore /dev/core

# Extra kernel-provided filesystems (same set as OpenRC devfs/sysfs services)
mkdir -p /dev/shm /dev/pts /dev/mqueue /sys/kernel/security /sys/kernel/debug \
         /sys/kernel/tracing /sys/kernel/config /sys/fs/fuse/connections \
         /sys/fs/pstore /sys/fs/bpf /sys/fs/cgroup /proc/sys/fs/binfmt_misc

mountpoint -q /dev/mqueue || mount -t mqueue mqueue /dev/mqueue 2>/dev/null
mountpoint -q /dev/shm    || mount -t tmpfs -o nodev,nosuid,mode=1777 \
                                shm /dev/shm 2>/dev/null

grep -qs securityfs /proc/filesystems && \
    mountpoint -q /sys/kernel/security || \
    mount -t securityfs securityfs /sys/kernel/security 2>/dev/null
grep -qs debugfs /proc/filesystems && \
    mountpoint -q /sys/kernel/debug || \
    mount -t debugfs debugfs /sys/kernel/debug 2>/dev/null
grep -qs tracefs /proc/filesystems && \
    mountpoint -q /sys/kernel/tracing || \
    mount -t tracefs tracefs /sys/kernel/tracing 2>/dev/null
grep -qs configfs /proc/filesystems && \
    mountpoint -q /sys/kernel/config || \
    mount -t configfs configfs /sys/kernel/config 2>/dev/null
grep -qs fusectl /proc/filesystems && \
    mountpoint -q /sys/fs/fuse/connections || \
    mount -t fusectl fusectl /sys/fs/fuse/connections 2>/dev/null
grep -qs '^pstore ' /proc/filesystems && \
    mountpoint -q /sys/fs/pstore || \
    mount -t pstore pstore -o kmsg_bytes=0 /sys/fs/pstore 2>/dev/null
grep -qs ' bpf$' /proc/filesystems && \
    mountpoint -q /sys/fs/bpf || \
    mount -t bpf bpf -o mode=0700 /sys/fs/bpf 2>/dev/null

# cgroups (sysinit). OpenRC default rc_cgroup_mode=unified -> mount cgroup2.
if [ -d /sys/fs/cgroup ] && ! mountpoint -q /sys/fs/cgroup; then
    if grep -qw cgroup2 /proc/filesystems; then
        mount -t cgroup2 cgroup2 -o nodev,noexec,nosuid,nsdelegate \
            /sys/fs/cgroup 2>/dev/null
    elif grep -qw cgroup /proc/filesystems; then
        mount -t cgroup cgroup -o nodev,noexec,nosuid \
            /sys/fs/cgroup 2>/dev/null
    fi
fi

# dmesg (sysinit): set console log level for a cleaner boot
[ -f /etc/conf.d/dmesg ] && . /etc/conf.d/dmesg
if [ -n "${dmesg_level}" ]; then
    dmesg -n"$dmesg_level"
fi

# udevd + udev-trigger (sysinit): coldplug events, settle, LVM activation
if [ -x /sbin/udevd ]; then
    /sbin/udevd --daemon 2>/dev/null || /sbin/udevd -d 2>/dev/null || true
    /bin/udevadm trigger --action=add    --type=subsystems 2>/dev/null || true
    /bin/udevadm trigger --action=add    --type=devices 2>/dev/null || true
    /bin/udevadm trigger --action=change --type=devices 2>/dev/null || true
    /bin/udevadm settle --timeout=5 2>/dev/null || true
    if [ -x /sbin/vgchange ]; then
        /sbin/vgchange -a y >/dev/null 2>&1 || true
    fi
fi

# ---------------------------------------------------------------------------
# boot runlevel
# ---------------------------------------------------------------------------

# etc-overlay: make /etc writable on the live/RO root via tmpfs overlay
if ! mountpoint -q /etc && ! touch /etc/.writable-test 2>/dev/null; then
    mkdir -p /run/etc-bak
    cp -a /etc/. /run/etc-bak/
    mount -t tmpfs tmpfs /etc -o mode=0755 2>/dev/null || true
    cp -a /run/etc-bak/. /etc/
    rm -rf /run/etc-bak
else
    rm -f /etc/.writable-test
fi

# mtab (boot): /etc/mtab -> /proc/self/mounts
ln -snf /proc/self/mounts /etc/mtab

# hostname (boot)
hostname="$(cat /etc/hostname 2>/dev/null || echo haliade)"
hostname "$hostname" 2>/dev/null || true

# hwclock (boot)
if [ -x /sbin/hwclock ]; then
    [ -f /etc/conf.d/hwclock ] && . /etc/conf.d/hwclock
    case "${clock:-UTC}" in
    UTC)   hwclock --hctosys --utc 2>/dev/null || true ;;
    local) hwclock --hctosys --localtime 2>/dev/null || true ;;
    esac
fi

# termencoding (boot): set consoles to UTF-8 (or ASCII, per unicode conf)
ttyn="$(echo ${rc_tty_number:-${RC_TTY_NUMBER:-12}})"
ttydev=/dev/tty; [ -d /dev/vc ] && ttydev=/dev/vc/
case "${unicode:-yes}" in
NO|no|No|FALSE|false) tencterm="(B" ;;
*) tencterm="%G" ;;
esac
printf_esc=%s
n=1
while [ "$n" -le "$ttyn" ]; do
    printf "\\033$printf_esc" "$tencterm" > "$ttydev$n" 2>/dev/null
    : $(( n += 1 ))
done

# keymaps (boot): keyboard mode + keymap
[ -f /etc/conf.d/keymaps ] && . /etc/conf.d/keymaps
keymap="${keymap:-us}"
case "${unicode:-yes}" in
NO|no|No|FALSE|false) kmode=-a ;;
*) kmode=-u ;;
esac
if [ -n "$keymap" ] && command -v loadkeys >/dev/null 2>&1; then
    n=1
    while [ "$n" -le "$ttyn" ]; do
        kbd_mode "$kmode" -C "$ttydev$n" 2>/dev/null || true
        : $(( n += 1 ))
    done
    # OpenRC adds "windowkeys" only when the conf flag is a yes-answer
    wkeys=""
    case "${windowkeys:-NO}" in
    YES|yes|Yes) wkeys="windowkeys" ;;
    esac
    # shellcheck disable=SC2086
    loadkeys -q $wkeys "$keymap" ${extended_keymaps:-} 2>/dev/null || true
fi

# consolefont (boot): mirror OpenRC consolefont start() — same conf vars
# (lower+uppercase), the same -u/-m param handling, and failures are
# surfaced. OpenRC prints [ ERROR ] at boot here; a silent `2>/dev/null ||
# break` would swallow the real reason, so keep setfont's stderr visible.
[ -f /etc/conf.d/consolefont ] && . /etc/conf.d/consolefont
consolefont="${consolefont:-${CONSOLEFONT}}"
unicodemap="${unicodemap:-${UNICODEMAP}}"
consoletranslation="${consoletranslation:-${CONSOLETRANSLATION}}"
param=""
[ -n "${unicodemap}" ] && param="-u ${unicodemap}"
[ -n "${consoletranslation}" ] && param="${param} -m ${consoletranslation}"
if [ -n "${consolefont}" ] && command -v setfont >/dev/null 2>&1; then
    n=1
    while [ "$n" -le "$ttyn" ]; do
        # shellcheck disable=SC2086
        setfont "${consolefont}" $param -C "$ttydev$n" >/dev/null || {
            echo "stage1: consolefont: setfont ${consolefont} failed on ${ttydev}${n} (reason above)" >&2
            break
        }
        : $(( n += 1 ))
    done
fi

# modules (boot): /etc/conf.d/modules (optional plain list) +
#                 modules-load.d drop-ins
if [ -f /etc/conf.d/modules ]; then
    . /etc/conf.d/modules
    # shellcheck disable=SC2154
    for mod in ${modules:-}; do
        modprobe --first-time --use-blacklist "$mod" 2>/dev/null || \
            modprobe --use-blacklist "$mod" 2>/dev/null || true
    done
fi
for f in /etc/modules-load.d/*.conf /run/modules-load.d/*.conf \
         /usr/lib/modules-load.d/*.conf; do
    [ -r "$f" ] || continue
    while read -r m _; do
        case "$m" in ""|\#*) continue ;; esac
        modprobe --first-time "$m" 2>/dev/null || true
    done < "$f"
done

# binfmt (boot): register handlers via the OpenRC helper
if [ -x /usr/libexec/rc/sh/binfmt.sh ]; then
    /usr/libexec/rc/sh/binfmt.sh 2>/dev/null || true
fi

# sysctl (boot): apply /etc/sysctl.conf + /etc/sysctl.d + kernel defaults
# (busybox-safe equivalent of sysctl --system)
for f in /etc/sysctl.conf /etc/sysctl.d/*.conf \
         /run/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf; do
    [ -r "$f" ] || continue
    while read -r line; do
        case "$line" in ""|\#*) continue ;; esac
        sysctl -w "$line" >/dev/null 2>&1 || true
    done < "$f"
done

# staticroute (boot): /etc/route.conf takes precedence,
#                     else staticiproute from /etc/conf.d/staticroute
route_action=add
(
set -f
if [ -s /etc/route.conf ]; then
    while read -r args; do
        [ -z "$args" ] && continue
        case "$args" in
        \#*) ;;
        +*) [ "$route_action" = add ] && eval "${args#+}" ;;
        -*) [ "$route_action" = del ] && eval "${args#-}" ;;
        *)  ip route add $args 2>/dev/null || true ;;
        esac
    done < /etc/route.conf
else
    [ -f /etc/conf.d/staticroute ] && . /etc/conf.d/staticroute
    if [ -n "${staticiproute}" ]; then
        IFSTMP=$IFS
        IFS=';'; set -- ${staticiproute}; IFS=$IFSTMP
        for args in "$@"; do
            [ -z "$args" ] && continue
            ip route add $args 2>/dev/null || true
        done
    fi
fi
)

# loopback (boot)
if command -v ip >/dev/null 2>&1; then
    ip addr add 127.0.0.1/8 dev lo brd + 2>/dev/null || true
    ip link set lo up 2>/dev/null || true
else
    ifconfig lo 127.0.0.1 netmask 255.0.0.0 2>/dev/null || true
    ifconfig lo up 2>/dev/null || true
fi

# network (boot): only acts if /etc/conf.d/network or /etc/ifconfig.* /
#                 /etc/ip.* configure interfaces (default: nothing to do,
#                 connmand/iwd handle connectivity).
[ -f /etc/conf.d/network ] && . /etc/conf.d/network
netifs=""
for f in /etc/ifconfig.* /etc/ip.*; do
    [ -f "$f" ] && netifs="$netifs ${f##*.}"
done
# shellcheck disable=SC2154
for int in ${interfaces:-} $netifs; do
    [ -n "$int" ] || continue
    intvar=$(echo "$int" | tr -c 'a-zA-Z0-9' '_')
    eval "addrs=\${ip_${intvar}:-}"
    if [ -n "$addrs" ]; then
        (
        set -f
        IFSTMP=$IFS
        IFS=';'; set -- $addrs; IFS=$IFSTMP
        for a in "$@"; do
            [ -n "$a" ] && ip addr add $a dev "$int" 2>/dev/null || true
        done
        )
        ip link set "$int" up 2>/dev/null || true
    fi
done
# default routes from conf.d/network
if [ -n "${defaultiproute}" ]; then
    ip route add default ${defaultiproute} 2>/dev/null || true
elif [ -n "${defaultroute}" ]; then
    ip route add default ${defaultroute} 2>/dev/null || true
fi

# fsck (boot): check local filesystems; -R skips the root fs (live overlay)
# (mirrors OpenRC: fsck -A -p -C0 -T with skip types)
if [ -x /sbin/fsck ] && [ ! -e /fastboot ] && [ ! -e /forcefsck ]; then
    fsck -A -p -C0 -T -t nonfs,nfs4,noopts=_netdev -R 2>/dev/null || true
fi

# root (boot): ensure / is read/write
mountpoint -q / && mount -o remount,rw / 2>/dev/null || true

# swap (boot)
swapon -a 2>/dev/null || true

# localmount (boot): mount remaining fstab entries, skip already mounted
# shellcheck disable=SC2034
while read -r dev mp fstype opts dump pass; do
    case "$dev" in ""|\#*) continue ;; esac
    mountpoint -q "$mp" 2>/dev/null && continue
    mount -t "$fstype" -o "$opts" "$dev" "$mp" 2>/dev/null || true
done < /etc/fstab

# netmount (default, one-shot): mount network shares from fstab
# (busybox-safe: mount fstab entries marked _netdev, skip mounted/noauto)
# shellcheck disable=SC2034
while read -r dev mp fstype opts dump pass; do
    case "$dev" in ""|\#*) continue ;; esac
    case ",$opts," in
    *,_netdev,*) ;;
    *) continue ;;
    esac
    case ",$opts," in *,noauto,*) continue ;; esac
    mountpoint -q "$mp" 2>/dev/null && continue
    mount -t "$fstype" -o "$opts" "$dev" "$mp" 2>/dev/null || true
done < /etc/fstab

# seedrng (boot)
if command -v seedrng >/dev/null 2>&1; then
    seedrng 2>/dev/null || true
fi

# bootmisc (boot): runtime dirs, utmp/wtmp, wipe /tmp, X11 socket dirs
mkdir -p /var/log /var/lock /var/run 2>/dev/null
[ -L /var/run ] || ln -snf /run /var/run 2>/dev/null || true
touch /var/run/utmp /var/log/wtmp 2>/dev/null || true
mkdir -p /run/dbus /run/systemd /run/udev /run/wpa_supplicant /run/connman
rm -rf /tmp/.ICE-unix /tmp/.X11-unix
mkdir -p /tmp/.ICE-unix /tmp/.X11-unix
chmod 1777 /tmp/.ICE-unix /tmp/.X11-unix
find /tmp -mindepth 1 -maxdepth 1 \
    ! -name '.ICE-unix' ! -name '.X11-unix' ! -name lost+found \
    -exec rm -rf -- {} + 2>/dev/null || true

# local (default, one-shot): run /etc/local.d/*.start scripts
if [ -d /etc/local.d ]; then
    for file in /etc/local.d/*.start; do
        [ -x "$file" ] && "$file"
    done
fi

# clear: boot output is done — wipe the VTs. agetty clears its own tty before
# prompting (it must, or a supervisor restart stacks a second prompt instead of
# replacing the first), so this really covers the VTs with no getty and leaves
# stage2 starting from a clean screen.
n=1
while [ "$n" -le "$ttyn" ]; do
    printf '\033[2J\033[H' > "$ttydev$n" 2>/dev/null || true
    : $(( n += 1 ))
done

exit 0