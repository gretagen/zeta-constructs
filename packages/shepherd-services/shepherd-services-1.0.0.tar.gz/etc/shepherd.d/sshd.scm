;; sshd — OpenSSH server, foreground with stderr logging (-D -e), same argv
;; as the runit/dinit services; the -t precheck and /run/sshd mirror dinit's
;; sh -c wrapper. No bus dependency, like dinit (depends-on sysinit only).
(haliade-service!
 'sshd
 (service
  '(sshd)
  #:requirement '(boot)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "/usr/sbin/sshd -t 2>/dev/null; [ -d /run/sshd ] || mkdir -p /run/sshd 2>/dev/null; exec /usr/sbin/sshd -D -e"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
