;; dbus — D-Bus system message bus.
;; Mirrors the dinit service: chown /run/dbus to messagebus, then run in the
;; foreground (--nofork makes dbus-daemon bind the system bus socket itself).
(haliade-service!
 'dbus
 (service
  '(dbus)
  #:requirement '(boot)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "chown messagebus:messagebus /run/dbus 2>/dev/null || true; exec /usr/bin/dbus-daemon --system --nofork --nopidfile"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
