;; iwd — iNet Wireless Daemon.
;; Mirrors the runit/dinit services: unblock rfkill, prepare /var/lib/iwd,
;; bind-mount it over /usr/var/lib/iwd, export STATE_DIRECTORY, then run
;; iwd. The bounded bus wait is the fails-open stand-in for dinit's
;; depends-on dbus readiness.
(haliade-service!
 'iwd
 (service
  '(iwd)
  #:requirement '(boot dbus)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "/sbin/rfkill unblock all 2>/dev/null || true; [ -d /var/lib/iwd ] || mkdir -p /var/lib/iwd 2>/dev/null; chmod 700 /var/lib/iwd 2>/dev/null; [ -d /usr/var/lib/iwd ] || mkdir -p /usr/var/lib/iwd 2>/dev/null; mountpoint -q /usr/var/lib/iwd 2>/dev/null || mount --bind /var/lib/iwd /usr/var/lib/iwd 2>/dev/null; n=0; until [ -S /run/dbus/system_bus_socket ]; do n=$((n+1)); [ $n -ge 5 ] && break; sleep 1; done; exec env STATE_DIRECTORY=/var/lib/iwd /usr/libexec/iwd"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
