;; elogind — user seat manager (foreground, as in OpenRC/runit/dinit).
;; /run/systemd is already created by sysinit.sh; the bounded bus wait is
;; the fails-open stand-in for dinit's pipefd readiness on dbus.
(haliade-service!
 'elogind
 (service
  '(elogind)
  #:requirement '(boot dbus)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "mkdir -p /run/systemd; rm -f /run/elogind.pid; n=0; until [ -S /run/dbus/system_bus_socket ]; do n=$((n+1)); [ $n -ge 5 ] && break; sleep 1; done; exec /usr/libexec/elogind"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
