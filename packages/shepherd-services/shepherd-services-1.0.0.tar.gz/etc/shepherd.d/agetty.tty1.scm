;; agetty.tty1 — login prompt. No --noclear (agetty must clear before
;; prompting; with the flag a supervisor restart stacks a second prompt).
;; The bounded bus wait replaces dinit's soft waits-for: the prompt comes up
;; once the boot daemons are up, or after 30 seconds either way (fails-open,
;; like the runit sv status loop).
(haliade-service!
 'agetty.tty1
 (service
  '(agetty.tty1)
  #:requirement '(boot)
  #:start (make-forkexec-constructor
           '("/bin/sh" "-c"
             "n=0; until [ -S /run/dbus/system_bus_socket ]; do n=$((n+1)); [ $n -ge 30 ] && break; sleep 1; done; exec /sbin/agetty tty1 38400 linux"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
