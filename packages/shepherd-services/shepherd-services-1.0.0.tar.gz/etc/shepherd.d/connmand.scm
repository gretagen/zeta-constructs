;; connmand — Connection Manager (ethernet-first, as in OpenRC/dinit).
;; No bus-wait wrapper: connmand tolerates a late bus and retries on its own;
;; the #:requirement only orders it after dbus, like dinit's depends-on.
(haliade-service!
 'connmand
 (service
  '(connmand)
  #:requirement '(boot dbus)
  #:start (make-forkexec-constructor '("/usr/sbin/connmand" "-n"))
  #:stop (make-kill-destructor)
  #:respawn? #t))
