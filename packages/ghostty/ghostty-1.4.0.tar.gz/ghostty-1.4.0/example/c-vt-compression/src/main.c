#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <ghostty/vt.h>

//! [compression-idle-step]
// Perform one step after the application's idle timer fires. Returning true
// asks the application to schedule another step while the terminal is idle.
static bool compression_idle_step(GhosttyTerminal terminal) {
  GhosttyTerminalCompressionResult compression_result;
  GhosttyResult result = ghostty_terminal_compress(
      terminal,
      GHOSTTY_TERMINAL_COMPRESSION_MODE_INCREMENTAL,
      &compression_result);
  assert(result == GHOSTTY_SUCCESS);

  switch (compression_result) {
    case GHOSTTY_TERMINAL_COMPRESSION_RESULT_PENDING:
      return true;
    case GHOSTTY_TERMINAL_COMPRESSION_RESULT_COMPLETE:
    case GHOSTTY_TERMINAL_COMPRESSION_RESULT_UNSUPPORTED:
      return false;
    default:
      assert(false);
      return false;
  }
}
//! [compression-idle-step]

//! [memory-usage]
// Return the bytes of memory a terminal currently holds. A server hosting
// many terminals can compare this figure across terminals to decide which
// one to compress or shut down first.
static uint64_t terminal_resident_bytes(GhosttyTerminal terminal) {
  // GHOSTTY_INIT_SIZED sets the size field, which the call requires.
  GhosttyTerminalMemoryUsage usage =
      GHOSTTY_INIT_SIZED(GhosttyTerminalMemoryUsage);
  GhosttyResult result = ghostty_terminal_get(
      terminal,
      GHOSTTY_TERMINAL_DATA_MEMORY_USAGE,
      &usage);
  assert(result == GHOSTTY_SUCCESS);

  // Count both screens and any images. The alternate screen reports zero
  // until a program such as a full-screen editor first switches to it.
  return usage.primary_resident_bytes + usage.primary_image_bytes +
         usage.alternate_resident_bytes + usage.alternate_image_bytes;
}
//! [memory-usage]

int main(void) {
  GhosttyTerminal terminal;
  GhosttyResult result = ghostty_terminal_new(NULL, &terminal, 80, 24);
  assert(result == GHOSTTY_SUCCESS);

  size_t max_scrollback_bytes = 10 * 1024 * 1024;
  result = ghostty_terminal_set(
      terminal,
      GHOSTTY_TERMINAL_OPT_SCROLLBACK_MAX_BYTES,
      &max_scrollback_bytes);
  assert(result == GHOSTTY_SUCCESS);

  //! [compression-activity]
  uint64_t compression_activity;
  result = ghostty_terminal_compression_activity(
      terminal,
      &compression_activity);
  assert(result == GHOSTTY_SUCCESS);

  // Terminal mutations may change the token. When it changes, restart the
  // application's idle timer rather than compressing on the output path.
  const char *line = "repeated and compressible terminal history\r\n";
  for (size_t i = 0; i < 4000; i++) {
    ghostty_terminal_vt_write(
        terminal,
        (const uint8_t *)line,
        strlen(line));
  }

  uint64_t new_activity;
  result = ghostty_terminal_compression_activity(terminal, &new_activity);
  assert(result == GHOSTTY_SUCCESS);
  if (new_activity != compression_activity) {
    compression_activity = new_activity;
    // Restart the application's compression idle timer here.
  }
  //! [compression-activity]

  uint64_t before = terminal_resident_bytes(terminal);

  // Simulate the idle timer and its short pending-work continuations.
  while (compression_idle_step(terminal)) {}

  uint64_t after = terminal_resident_bytes(terminal);
  printf("resident memory: %llu bytes before compression, %llu after\n",
         (unsigned long long)before,
         (unsigned long long)after);

  ghostty_terminal_free(terminal);
  return 0;
}
