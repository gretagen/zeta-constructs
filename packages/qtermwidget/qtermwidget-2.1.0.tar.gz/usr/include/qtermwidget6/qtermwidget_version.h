/*  Copyright (C) 2020 Axel Kittenberger (axel.kittenberger@univie.ac.at)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public License
    along with this library; see the file COPYING.LIB.  If not, write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301, USA.
*/


#ifndef _Q_TERM_WIDGET_VERSION
#define _Q_TERM_WIDGET_VERSION

#include <QtGlobal>
#define QTERMWIDGET_VERSION_MAJOR 2
#define QTERMWIDGET_VERSION_MINOR 1
#define QTERMWIDGET_VERSION_PATCH 0
#define QTERMWIDGET_VERSION QT_VERSION_CHECK(\
	QTERMWIDGET_VERSION_MAJOR,\
	QTERMWIDGET_VERSION_MINOR,\
	QTERMWIDGET_VERSION_PATCH)

#endif

