local gen = {}
gen.name = "nixpkgs"

-- Declare system-level nixpkgs packages from definition.lua:
--
--   ["nixpkgs"] = {
--     "nixpkgs#fastfetch",
--   },
--
-- Backed by `nix profile add/remove` — the same commands the nixos subspace
-- uses in subspaces_packages, but pinned to the SYSTEM profile
-- (/nix/var/nix/profiles/default) so root's sync makes the tools visible to
-- every user: a bare `nix profile add` would write root's private per-user
-- profile, which no other user's PATH contains. /etc/profile.d/nix-haliade.sh
-- (shipped by the nix package) puts the system profile bin on all login
-- shells. This is the
-- generator shipped by the nix-declarative-helper construct; it only runs when
-- "nixpkgs" is registered in sync.lua's generator_names (see
-- `nix-declarative-helper --help`).
--
-- Additions diff against `nix profile list`, matched by element name: nix
-- names an element after the last component of the installable, so
-- nixpkgs#fastfetch becomes "fastfetch" in the listing. Both the full ref and
-- the element name are consulted so a profile entry added by hand with the
-- same ref is not re-added.
--
-- Removals only ever touch refs THIS generator previously declared, recorded
-- in /var/db/declared-nixpkgs at apply time (mirroring packages-isolated) — a
-- package someone installed themselves with `nix profile add` is never yanked
-- from their declaration, and the record is only written when the command
-- actually ran, so a declined prompt or failed install is retried next sync.

local DECLARED = "/var/db/declared-nixpkgs"

-- The shared system profile. Bare `nix profile` commands would operate on
-- root's private per-user profile instead, which no other user's PATH
-- contains — /etc/profile.d/nix-haliade.sh (nix package) exposes THIS one.
local SYSTEM_PROFILE = "/nix/var/nix/profiles/default"

-- Refs are interpolated into shell commands, so accept only word-ish
-- characters plus the punctuation flake references legitimately use
-- (nixpkgs#fastfetch, github:owner/repo#pkg, path:/srv/flake#pkg).
-- No spaces, quotes, $, backticks, ;|&<> — safe to embed unquoted.
local function valid_ref(r)
  return type(r) == "string"
    and r:match("^[%w%./%:%@%+%#_%-]+$") ~= nil
    and r:match("^[^#]+#[^#]+$") ~= nil
end

-- The profile element name for a ref (text after the last '#').
local function ref_name(r)
  return r:match("[^#]+$")
end

local function read_declared(sync)
  local set = {}
  local content = sync.read_file(DECLARED) or ""
  for line in (content .. "\n"):gmatch("([^\n]+)") do
    local ref = line:match("^%s*(.-)%s*$")
    if ref and ref ~= "" then set[ref] = true end
  end
  return set
end

-- Record a ref as ours / drop it again. Runs at apply time only.
local function declare(sync, ref)
  sync.shell("mkdir -p /var/db")
  return sync.shell("grep -qxF '" .. ref .. "' " .. DECLARED
    .. " 2>/dev/null || echo '" .. ref .. "' >> " .. DECLARED)
end

local function undeclare(sync, ref)
  return sync.shell("grep -vxF '" .. ref .. "' " .. DECLARED .. " > " .. DECLARED
    .. ".tmp 2>/dev/null; mv -f " .. DECLARED .. ".tmp " .. DECLARED)
end

function gen.plan(cfg, sync)
  local changes = {}
  local desired_list = cfg["nixpkgs"] or {}

  if #desired_list == 0 and next(read_declared(sync)) == nil then
    return {}
  end

  -- nix is optional (see `nix-declarative-helper --verifynix`): plan nothing
  -- and say why rather than failing the whole sync.
  if sync.shell_output("command -v nix") == "" then
    if #desired_list > 0 then
      io.stderr:write("[warn] nixpkgs: nix is not installed install it via zeta -Provide nix) ")
    end
    return {}
  end

  -- Validate and de-duplicate the desired refs, keeping declaration order.
  local desired, desired_set, seen = {}, {}, {}
  for _, ref in ipairs(desired_list) do
    if not valid_ref(ref) then
      io.stderr:write("[warn] nixpkgs: skipping invalid reference '"
        .. tostring(ref) .. "' (expected e.g. \"nixpkgs#fastfetch\")\n")
    elseif not seen[ref] then
      seen[ref] = true
      desired[#desired + 1] = ref
      desired_set[ref] = true
    end
  end

  if #desired == 0 and next(read_declared(sync)) == nil then
    return {}
  end

  -- Installed element names + full refs from `nix profile list`. Tolerates
  -- both the Name: block format (nix 2.19+) and older one-line listings.
  local installed = {}
  local listing = sync.shell_output("nix profile list --profile " .. SYSTEM_PROFILE)
  for line in (listing .. "\n"):gmatch("([^\n]+)") do
    local nm = line:match("^Name:%s*(%S+)")
    if nm then installed[nm] = true end
    local tok = line:match("^(%S+#%S+)%s")
    if tok then
      installed[tok] = true
      installed[ref_name(tok)] = true
    end
  end

  -- Install what is declared but not present.
  for _, ref in ipairs(desired) do
    local name = ref_name(ref)
    if not installed[ref] and not installed[name] then
      table.insert(changes, sync.change("+", "nixpkgs", ref, nil,
        function(_, s)
          local ok = s.shell("nix profile add --profile " .. SYSTEM_PROFILE .. " " .. ref)
          if not ok then
            io.stderr:write("[warn] '" .. ref .. "' nix profile add failed "
              .. "(flake unavailable, network error, or already present)\n")
            return false
          end
          return declare(s, ref)
        end))
    end
  end

  -- Remove what we previously declared and is no longer desired (never touch
  -- entries this generator does not own).
  local undeclared = {}
  for ref in pairs(read_declared(sync)) do
    if not desired_set[ref] then undeclared[#undeclared + 1] = ref end
  end
  table.sort(undeclared)

  for _, ref in ipairs(undeclared) do
    local name = ref_name(ref)
    table.insert(changes, sync.change("-", "nixpkgs", ref, nil,
        function(_, s)
        if installed[ref] or installed[name] then
          local ok = s.shell("nix profile remove --profile " .. SYSTEM_PROFILE .. " " .. name)
          if not ok then
            io.stderr:write("[warn] '" .. ref .. "' — nix profile remove failed\n")
            return false
          end
        end
        return undeclare(s, ref)
      end))
  end

  return changes
end

return gen
