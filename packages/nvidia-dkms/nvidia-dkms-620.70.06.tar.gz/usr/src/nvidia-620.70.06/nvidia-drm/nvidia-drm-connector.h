/*
 * Copyright (c) 2016-2026, NVIDIA CORPORATION. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef __NVIDIA_DRM_CONNECTOR_H__
#define __NVIDIA_DRM_CONNECTOR_H__

#include "nvidia-drm-conftest.h"

#if defined(NV_DRM_AVAILABLE)

#if defined(NV_DRM_DRMP_H_PRESENT)
#include <drm/drmP.h>
#endif

#include <drm/drm_connector.h>

#include "nvtypes.h"
#include "nvkms-api-types.h"

enum nv_drm_allm_mode {
    NV_DRM_ALLM_MODE_DISABLED        = 0,
    NV_DRM_ALLM_MODE_ENABLED_DYNAMIC = 1,
    NV_DRM_ALLM_MODE_ENABLED_FORCED  = 2,
};

struct nv_drm_connector {
    NvU32 physicalIndex;

    NvBool internal;
    NvKmsConnectorType type;

    char dpAddress[NVKMS_DP_ADDRESS_STRING_LENGTH];

    struct nv_drm_encoder *nv_detected_encoder;
    struct edid *edid;

    enum NvKmsContentProtection cp;
    bool cp_event_pending;

    atomic_t connection_status_dirty;

    /**
     * @modeset_permission_filep:
     *
     * The filep using this connector with DRM_IOCTL_NVIDIA_GRANT_PERMISSIONS.
     */
    struct drm_file *modeset_permission_filep;

    /**
     * @modeset_permission_crtc:
     *
     * The crtc using this connector with DRM_IOCTL_NVIDIA_GRANT_PERMISSIONS.
     */
    struct nv_drm_crtc *modeset_permission_crtc;

    NvBool allmCapable;

    struct drm_connector base;
};

static inline struct nv_drm_connector *to_nv_connector(
    struct drm_connector *connector)
{
    if (connector == NULL) {
        return NULL;
    }
    return container_of(connector, struct nv_drm_connector, base);
}

struct nv_drm_connector_state {
       struct drm_connector_state base;
       enum nv_drm_dithering_mode dithering_mode;
       enum nv_drm_connector_color_format color_format;
       enum nv_drm_connector_output_bpc output_bpc;
       struct drm_property_blob *hdcp_topology_blob;
       struct drm_property_blob *hdmi_vsif_metadata;
       enum nv_drm_allm_mode allmMode;
};

static inline struct nv_drm_connector_state *to_nv_drm_connector_state(
                     struct drm_connector_state *state)
{
    return container_of(state, struct nv_drm_connector_state, base);
}

static inline const struct nv_drm_connector_state *to_nv_drm_connector_state_const(
                           const struct drm_connector_state *state)
{
    return container_of(state, const struct nv_drm_connector_state, base);
}

static inline void nv_drm_connector_mark_connection_status_dirty(
    struct nv_drm_connector *nv_connector)
{
    atomic_cmpxchg(&nv_connector->connection_status_dirty, false, true);
}

static inline bool nv_drm_connector_check_connection_status_dirty_and_clear(
    struct nv_drm_connector *nv_connector)
{
    return atomic_cmpxchg(
            &nv_connector->connection_status_dirty,
            true,
            false) == true;
}

struct drm_connector*
nv_drm_get_connector(struct drm_device *dev,
                     NvU32 physicalIndex, NvKmsConnectorType type,
                     NvBool internal,
                     char dpAddress[NVKMS_DP_ADDRESS_STRING_LENGTH]);

bool nv_drm_connector_revoke_permissions(struct drm_device *dev,
                                         struct nv_drm_connector *nv_connector);
void nv_drm_connector_update_content_protection(struct nv_drm_connector *nv_connector);
int nv_drm_connector_update_topology_property(struct nv_drm_connector *nv_connector,
                                              const void *topology);


#endif /* NV_DRM_AVAILABLE */

#endif /* __NVIDIA_DRM_CONNECTOR_H__ */
