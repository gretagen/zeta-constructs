/*******************************************************************************
    Copyright (c) 2015-2026 NVIDIA Corporation

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to
    deal in the Software without restriction, including without limitation the
    rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
    sell copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

        The above copyright notice and this permission notice shall be
        included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.

*******************************************************************************/

#ifndef __UVM_DEVMEM_H__
#define __UVM_DEVMEM_H__

#include "uvm_forward_decl.h"
#include "uvm_linux.h"
#include "uvm_types.h"
#include "uvm_va_space.h"

static inline void uvm_devmem_device_p2p_init(uvm_parent_gpu_t *gpu) {}
static inline NV_STATUS uvm_devmem_init(uvm_parent_gpu_t *gpu) { return NV_OK; }
static inline void uvm_devmem_deinit(uvm_parent_gpu_t *parent_gpu) {}
static inline NV_STATUS uvm_devmem_global_init(void) { return NV_OK; }
static inline void uvm_devmem_global_deinit(void) {}
static inline void uvm_devmem_device_p2p_deinit(uvm_parent_gpu_t *gpu) {}
static inline void uvm_devmem_exit(void) {}
static inline void uvm_devmem_pci_p2pdma_cache_exit(void) { }
static inline NV_STATUS uvm_devmem_get_page_ref_if_device_coherent(struct page *page)
{
    return NV_OK;
}
static inline void uvm_devmem_put_page_ref_if_device_coherent(struct page *page) {}
static inline bool uvm_devmem_cdmm_present(uvm_parent_gpu_t *parent_gpu)
{
    return false;
}

bool uvm_devmem_check_orphan_pages(uvm_pmm_gpu_t *pmm);

// This represents a physical RM allocation used for device peer-to-peer access.
// This is distinct from the va_range type because the physical allocations can be
// shared by multiple va_ranges.
typedef struct
{
    // The physical GPU memory backing device P2P ranges can be referenced by
    // two entities - kernel device drivers and the va_range(s) that UVM uses
    // to create CPU mappings. The physical memory can not be freed until after
    // both entities have finished accessing it. This refcount tracks total
    // kernel users of the memory.
    nv_kref_t refcount;

    // The number of va ranges referencing this physical range.
    nv_kref_t va_range_count;

    uvm_gpu_t *gpu;
    NvHandle rm_memory_handle;
    NvU64 *pfns;
    NvU64 pfn_count;
    NvLength page_size;
    uvm_deferred_free_object_t deferred_free;
    struct list_head *deferred_free_list;
    wait_queue_head_t waitq;
} uvm_device_p2p_mem_t;

// Assigned to page->zone_device_data for DEVICE_COHERENT pages where these
// could be used to track a device p2p allocation made with cudaMalloc() or
// system allocated memory in a va_block.
typedef struct {
    uvm_gpu_chunk_t *gpu_chunk;
    uvm_device_p2p_mem_t *p2p_mem;
} uvm_coherent_devmem_page_t;

NV_STATUS uvm_devmem_global_init(void);
void uvm_devmem_global_deinit(void);

#if (defined(CONFIG_PCI_P2PDMA) || UVM_CDMM_PAGES_SUPPORTED()) && defined(NV_STRUCT_PAGE_HAS_ZONE_DEVICE_DATA)
extern struct kmem_cache *g_uvm_coherent_devmem_page_cache;

// page->zone_device_data does not exist in kernels versions older than v5.3
// which don't support CONFIG_PCI_P2PDMA. Therefore we need these accessor
// functions to ensure compilation succeeeds on older kernels.
static void page_set_zone_device_p2p_data(struct page *page, uvm_device_p2p_mem_t *p2p_mem)
{
#if UVM_CDMM_PAGES_SUPPORTED()
    if (is_device_coherent_page(page)) {
        uvm_coherent_devmem_page_t *coherent_devmem_page;

        if (!page->zone_device_data) {
            coherent_devmem_page = kmem_cache_zalloc(g_uvm_coherent_devmem_page_cache, NV_UVM_GFP_FLAGS);
            page->zone_device_data = coherent_devmem_page;
            WARN_ON(!coherent_devmem_page);
        }

        coherent_devmem_page->p2p_mem = p2p_mem;
    }
    else {
        page->zone_device_data = p2p_mem;
    }
#else
    page->zone_device_data = p2p_mem;
#endif
}

static uvm_device_p2p_mem_t *page_get_zone_device_p2p_data(struct page *page)
{
    if (!page->zone_device_data)
        return NULL;
#if UVM_CDMM_PAGES_SUPPORTED()
    else if (is_device_coherent_page(page))
        return ((uvm_coherent_devmem_page_t *) page->zone_device_data)->p2p_mem;
#endif
    else
        return page->zone_device_data;
}

static void page_set_zone_device_chunk_data(struct page *page, uvm_gpu_chunk_t *gpu_chunk)
{
#if UVM_CDMM_PAGES_SUPPORTED()
    if (is_device_coherent_page(page)) {
        uvm_coherent_devmem_page_t *coherent_devmem_page;

        if (!page->zone_device_data) {
            coherent_devmem_page = kmem_cache_zalloc(g_uvm_coherent_devmem_page_cache, NV_UVM_GFP_FLAGS);
            page->zone_device_data = coherent_devmem_page;
            WARN_ON(!coherent_devmem_page);
        }

        coherent_devmem_page->gpu_chunk = gpu_chunk;
    }
    else {
        page->zone_device_data = gpu_chunk;
    }
#else
    page->zone_device_data = gpu_chunk;
#endif
}

static uvm_gpu_chunk_t *page_get_zone_device_chunk_data(struct page *page)
{
    if (!page->zone_device_data)
        return NULL;
#if UVM_CDMM_PAGES_SUPPORTED()
    else if (is_device_coherent_page(page))
        return ((uvm_coherent_devmem_page_t *) page->zone_device_data)->gpu_chunk;
#endif
    else
        return page->zone_device_data;
}
#else
static void page_set_zone_device_p2p_data(struct page *page, uvm_device_p2p_mem_t *zone_device_data)
{
    UVM_ASSERT(0);
}

static uvm_device_p2p_mem_t *page_get_zone_device_p2p_data(struct page *page)
{
    UVM_ASSERT(0);
    return NULL;
}
#endif
#endif
