#!/bin/sh
# dinit shutdown hook — user-space teardown (Haliade OS)
# Runs once dinit has stopped every supervised daemon (the "before:"
# orderings in the shutdown-hooks service). Upstream dinit's
# do_system_shutdown already covers kill(-1), swapoff, unmount_disks
# and sync, and the kernel's reboot() repeats them — so only the bits
# neither performs live here:
#   - /etc/local.d/*.stop   (each isolated: timeout, never fatal)
#   - persist the RNG seed   (seedrng stop)
#   - save clock to RTC      (hwclock stop)
# Invoked via the "shutdown-hooks" service's stop-command, so it runs
# once dinit rolls the service graph down during dinit-halt/reboot/poweroff.
exec 2>&1
export PATH=/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin

echo "dinit shutdown hook — finalizing system"

# local stop (default runlevel .stop scripts). A hanging or crashing
# hook costs 10 seconds and a log line — never the shutdown itself.
if [ -d /etc/local.d ]; then
    for file in /etc/local.d/*.stop; do
        [ -x "$file" ] || continue
        echo "local.d stop: $file"
        timeout 10 "$file" || echo "local.d stop failed (ignored): $file" >&2
    done
fi

# seedrng stop: persist the RNG seed
if command -v seedrng >/dev/null 2>&1; then
    seedrng 2>/dev/null || true
fi

# hwclock stop: save system clock to hardware clock
if [ -x /sbin/hwclock ] && [ -e /etc/conf.d/hwclock ]; then
    . /etc/conf.d/hwclock
    case "${clock:-UTC}" in
    UTC)   hwclock --systohc --utc 2>/dev/null || true ;;
    local) hwclock --systohc --localtime 2>/dev/null || true ;;
    esac
fi

exit 0
