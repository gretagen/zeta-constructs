#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PW::LibColorCorrect" for configuration "Release"
set_property(TARGET PW::LibColorCorrect APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(PW::LibColorCorrect PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "KF6::I18n;Qt6::DBus;Qt6::Qml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libcolorcorrect.so.6.3.6"
  IMPORTED_SONAME_RELEASE "libcolorcorrect.so.6"
  )

list(APPEND _cmake_import_check_targets PW::LibColorCorrect )
list(APPEND _cmake_import_check_files_for_PW::LibColorCorrect "${_IMPORT_PREFIX}/lib64/libcolorcorrect.so.6.3.6" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
