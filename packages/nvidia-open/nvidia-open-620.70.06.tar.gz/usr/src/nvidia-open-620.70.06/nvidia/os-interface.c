/*
 * SPDX-FileCopyrightText: Copyright (c) 1999-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: MIT
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#define  __NO_VERSION__

#include "conftest.h"
#include "os-interface.h"
#include "nv-linux.h"
#include "nv-pci.h"
#include <linux/iommu.h>
#include "nv-caps-imex.h"

#include "nv-platform.h"

#include "nv-time.h"

#include <linux/mmzone.h>
#include <linux/numa.h>
#include <linux/cpuset.h>
#include <linux/sys_soc.h>

#include <linux/shmem_fs.h>
#include <linux/pid.h>
#include <linux/pid_namespace.h>
#if defined(CONFIG_LOCKDEP)
#include <linux/lockdep.h>
#endif // CONFIG_LOCKDEP
#if defined(NV_MISC_CGROUP_PRESENT)
#include <linux/cgroup.h>
#endif // NV_MISC_CGROUP_PRESENT
#if defined(NV_DMEM_CGROUP_PRESENT)
#include <linux/cgroup_dmem.h>
#endif // NV_DMEM_CGROUP_PRESENT

#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <linux/pci_regs.h>

#if defined(NVCPU_AARCH64)
#include <linux/arm-smccc.h>

#if defined(NV_CRYPTO_PRESENT) && \
    (defined(CONFIG_CRYPTO_HASH) || defined(CONFIG_CRYPTO_HASH_MODULE))
#define NV_USE_KERNEL_CRYPTO_HASH 1
#endif // defined(NV_CRYPTO_PRESENT) && CONFIG_CRYPTO_HASH
#endif // NVCPU_AARCH64

#if defined(NV_USE_KERNEL_CRYPTO_HASH)
#include <crypto/hash.h>
#endif // NV_USE_KERNEL_CRYPTO_HASH

extern char *NVreg_TemporaryFilePath;

#define MAX_ERROR_STRING 528
static char nv_error_string[MAX_ERROR_STRING];
static NV_DEFINE_SPINLOCK(nv_error_string_lock);

extern nv_linux_state_t nv_ctl_device;

extern nv_kthread_q_t nv_kthread_q;

NvU64 os_page_size     = PAGE_SIZE;
NvU64 os_max_page_size = PAGE_SIZE << NV_MAX_PAGE_ORDER;
NvU64 os_page_mask     = NV_PAGE_MASK;
NvU8  os_page_shift    = PAGE_SHIFT;

NvBool os_cc_enabled = 0;
NvBool os_cc_sev_snp_enabled = 0;
NvBool os_cc_snp_vtom_enabled = 0;
NvBool os_cc_tdx_enabled = 0;
NvBool os_cc_sme_enabled = 0;
NvBool os_tdisp_enabled = 0;

NvBool NV_API_CALL os_is_tdisp_tdi_run_state(void *nv_state)
{
    nv_state_t *nv = nv_state;

    if (nv == NULL)
        return NV_FALSE;

    if (!os_tdisp_enabled)
        return NV_FALSE;

    return nv->tdisp_dma_mapping_ready;
}

/*
 * Map a contiguous physical device range with protected (encrypted) attributes.
 *
 * TDISP BAR0 contains protected regions and unprotected holes. A regular
 * whole-BAR ioremap path classifies the mixed range as unprotected, but RM
 * needs one protected BAR0 map after RUN state. The unprotected holes, such as
 * MSI-X and CXL MEMBAR, are VMM trap/emulated ranges, so a protected stage-1
 * mapping does not cause GPT faults. vmap_pfn() with explicit
 * pgprot_encrypted(pgprot_device(PAGE_KERNEL)) preserves the needed PTE
 * attributes for the protected BAR0 regions. pgprot_encrypted() may
 * reference cc_mkenc() on x86, and vmap_pfn() may be GPL-only, so keep
 * the implementation behind link-safe export checks.
 */
void* NV_API_CALL os_map_device_paddr_range_protected(NvU64 phys_addr, NvU64 size)
{
#if NV_CHECK_EXPORT_SYMBOL(vmap_pfn) && \
    defined(NV_PGPROT_ENCRYPTED_PRESENT) && \
    (defined(NVCPU_AARCH64) || NV_CHECK_EXPORT_SYMBOL(cc_mkenc))
    unsigned long *pfns;
    void *vaddr;
    pgprot_t prot;
    size_t i;
    size_t bytes = (size_t)size;
    size_t nr_pages = bytes / PAGE_SIZE;

    if (nr_pages == 0)
    {
        return NULL;
    }

    pfns = kvmalloc_array(nr_pages, sizeof(unsigned long), GFP_KERNEL);
    if (pfns == NULL)
    {
        return NULL;
    }

    for (i = 0; i < nr_pages; i++)
    {
        pfns[i] = (unsigned long)(((phys_addr_t)phys_addr >> PAGE_SHIFT) + i);
    }

    prot = pgprot_device(PAGE_KERNEL);
    prot = pgprot_encrypted(prot);

    vaddr = vmap_pfn(pfns, nr_pages, prot);
    kvfree(pfns);
    return vaddr;
#else
    (void)phys_addr;
    (void)size;
    return NULL;
#endif
}

#if defined(CONFIG_DMA_SHARED_BUFFER)
NvBool os_dma_buf_enabled = NV_TRUE;
#else
NvBool os_dma_buf_enabled = NV_FALSE;
#endif // CONFIG_DMA_SHARED_BUFFER

NvBool os_imex_channel_is_supported = NV_TRUE;

void NV_API_CALL os_disable_console_access(void)
{
    console_lock();
}

void NV_API_CALL os_enable_console_access(void)
{
    console_unlock();
}

typedef struct semaphore os_mutex_t;

//
// os_alloc_mutex - Allocate the RM mutex
//
//  ppMutex - filled in with pointer to opaque structure to mutex data type
//
NV_STATUS NV_API_CALL os_alloc_mutex
(
    void **ppMutex
)
{
    NV_STATUS rmStatus;
    os_mutex_t *os_mutex;

    rmStatus = os_alloc_mem(ppMutex, sizeof(os_mutex_t));
    if (rmStatus != NV_OK)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to allocate mutex!\n");
        return rmStatus;
    }
    os_mutex = (os_mutex_t *)*ppMutex;
    NV_INIT_MUTEX(os_mutex);

    return NV_OK;
}

//
// os_free_mutex - Free resources associated with mutex allocated
//                via os_alloc_mutex above.
//
//  pMutex - Pointer to opaque structure to mutex data type
//
void NV_API_CALL os_free_mutex
(
    void  *pMutex
)
{
    os_mutex_t *os_mutex = (os_mutex_t *)pMutex;

    if (os_mutex != NULL)
    {
        os_free_mem(pMutex);
    }
}

//
//  pMutex - Pointer to opaque structure to mutex data type
//

NV_STATUS NV_API_CALL os_acquire_mutex
(
    void  *pMutex
)
{
    os_mutex_t *os_mutex = (os_mutex_t *)pMutex;

    if (!NV_MAY_SLEEP())
    {
        return NV_ERR_INVALID_REQUEST;
    }
    down(os_mutex);

    return NV_OK;
}

NV_STATUS NV_API_CALL os_cond_acquire_mutex
(
    void * pMutex
)
{
    os_mutex_t *os_mutex = (os_mutex_t *)pMutex;
    if (!NV_MAY_SLEEP())
    {
        return NV_ERR_INVALID_REQUEST;
    }

    if (down_trylock(os_mutex))
    {
        return NV_ERR_TIMEOUT_RETRY;
    }

    return NV_OK;
}


void NV_API_CALL os_release_mutex
(
    void *pMutex
)
{
    os_mutex_t *os_mutex = (os_mutex_t *)pMutex;
    up(os_mutex);
}

typedef struct semaphore os_semaphore_t;


void* NV_API_CALL os_alloc_semaphore
(
    NvU32 initialValue
)
{
    NV_STATUS rmStatus;
    os_semaphore_t *os_sema;

    rmStatus = os_alloc_mem((void *)&os_sema, sizeof(os_semaphore_t));
    if (rmStatus != NV_OK)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to allocate semaphore!\n");
        return NULL;
    }

    sema_init(os_sema, initialValue);

    return (void *)os_sema;
}

void NV_API_CALL os_free_semaphore
(
    void *pSema
)
{
    os_semaphore_t *os_sema = (os_semaphore_t *)pSema;

    os_free_mem(os_sema);
}

NV_STATUS NV_API_CALL os_acquire_semaphore
(
    void *pSema
)
{
    os_semaphore_t *os_sema = (os_semaphore_t *)pSema;

    if (!NV_MAY_SLEEP())
    {
        return NV_ERR_INVALID_REQUEST;
    }
    down(os_sema);
    return NV_OK;
}

NV_STATUS NV_API_CALL os_cond_acquire_semaphore
(
    void * pSema
)
{
    os_semaphore_t *os_sema = (os_semaphore_t *)pSema;
    //
    // NOTE: down_trylock() is safe to call from IRQ, se we don't need an
    // NV_MAY_SLEEP() check here. We do check it in os_cond_acquire_mutex(),
    // even though it is also calling down_trylock(), since that keeps it
    // in line with the kernel's 'struct mutex' API.
    //
    if (down_trylock(os_sema))
    {
        return NV_ERR_TIMEOUT_RETRY;
    }

    return NV_OK;
}

NV_STATUS NV_API_CALL os_release_semaphore
(
    void *pSema
)
{
    os_semaphore_t *os_sema = (os_semaphore_t *)pSema;
    up(os_sema);
    return NV_OK;
}

typedef struct
{
    struct rw_semaphore sem;

#if defined(CONFIG_LOCKDEP)
    /**
     * A key of lock class. It would be registered to Lockdep validator so all
     * instances' usages and dependencies will contribute to constructing correct
     * locking rules and this lock will be tracked by the Lockdep validator.
     *
     */
    struct lock_class_key key;
#endif // CONFIG_LOCKDEP
} os_rwlock_t;

void* NV_API_CALL os_alloc_rwlock(void)
{
    os_rwlock_t *os_rwlock = NULL;

    NV_STATUS rmStatus = os_alloc_mem((void *)&os_rwlock, sizeof(os_rwlock_t));
    if (rmStatus != NV_OK)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to allocate a struct os_rwlock_t!\n");
        return NULL;
    }

    init_rwsem(&os_rwlock->sem);

#if defined(CONFIG_LOCKDEP)
#if NV_IS_EXPORT_SYMBOL_PRESENT_lockdep_register_key
    // Register the dynamically allocated key to Lockdep.
    lockdep_register_key(&os_rwlock->key);
    lockdep_set_class(&os_rwlock->sem, &os_rwlock->key);
#endif //NV_IS_EXPORT_SYMBOL_PRESENT_lockdep_register_key
#endif // CONFIG_LOCKDEP

    return os_rwlock;
}

void NV_API_CALL os_free_rwlock(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;

#if defined(CONFIG_LOCKDEP)
    // Unregister the dynamically allocated key.
    lockdep_unregister_key(&os_rwlock->key);
#endif // CONFIG_LOCKDEP

    os_free_mem(os_rwlock);
}

NV_STATUS NV_API_CALL os_acquire_rwlock_read(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;

    if (!NV_MAY_SLEEP())
    {
        return NV_ERR_INVALID_REQUEST;
    }
    down_read(&os_rwlock->sem);
    return NV_OK;
}

NV_STATUS NV_API_CALL os_acquire_rwlock_write(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;

    if (!NV_MAY_SLEEP())
    {
        return NV_ERR_INVALID_REQUEST;
    }
    down_write(&os_rwlock->sem);
    return NV_OK;
}

NV_STATUS NV_API_CALL os_cond_acquire_rwlock_read(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;

    if (!down_read_trylock(&os_rwlock->sem))
    {
        return NV_ERR_TIMEOUT_RETRY;
    }

    return NV_OK;
}

NV_STATUS NV_API_CALL os_cond_acquire_rwlock_write(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;

    if (!down_write_trylock(&os_rwlock->sem))
    {
        return NV_ERR_TIMEOUT_RETRY;
    }

    return NV_OK;
}

void NV_API_CALL os_release_rwlock_read(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;
    up_read(&os_rwlock->sem);
}

void NV_API_CALL os_release_rwlock_write(void *pRwLock)
{
    os_rwlock_t *os_rwlock = (os_rwlock_t *)pRwLock;
    up_write(&os_rwlock->sem);
}

NvBool NV_API_CALL os_semaphore_may_sleep(void)
{
    return NV_MAY_SLEEP();
}

NvBool NV_API_CALL os_is_isr(void)
{
    return (nv_in_hardirq());
}

// return TRUE if the caller is the super-user
NvBool NV_API_CALL os_is_administrator(void)
{
    return NV_IS_SUSER();
}

NvBool NV_API_CALL os_check_access(RsAccessRight accessRight)
{
    switch (accessRight)
    {
        case RS_ACCESS_PERFMON:
        {
#if defined(CAP_PERFMON)
            return capable(CAP_PERFMON);
#else
            return os_is_administrator();
#endif
        }
        case RS_ACCESS_NICE:
        {
            return capable(CAP_SYS_NICE);
        }
        default:
        {
            return NV_FALSE;
        }
    }
}

char* NV_API_CALL os_string_copy(
    char *dst,
    const char *src
)
{
    return strcpy(dst, src);
}

NvU32 NV_API_CALL os_string_length(
    const char* str
)
{
    return strlen(str);
}

NvU32 NV_API_CALL os_strtoul(const char *str, char **endp, NvU32 base)
{
    return (NvU32)simple_strtoul(str, endp, base);
}

NvS32 NV_API_CALL os_string_compare(const char *str1, const char *str2)
{
    return strcmp(str1, str2);
}

static void *os_mem_copy_custom(
    void       *dstPtr,
    const void *srcPtr,
    NvU32       length
)
{
    void *ret = dstPtr;
    NvU32 dwords, bytes = length;
    NvU8 *dst = dstPtr;
    const NvU8 *src = srcPtr;

    if ((length >= 128) &&
        (((NvUPtr)dst & 3) == 0) & (((NvUPtr)src & 3) == 0))
    {
        dwords = (length / sizeof(NvU32));
        bytes = (length % sizeof(NvU32));

        while (dwords != 0)
        {
            *(NvU32 *)dst = *(const NvU32 *)src;
            dst += sizeof(NvU32);
            src += sizeof(NvU32);
            dwords--;
        }
    }

    while (bytes != 0)
    {
        *dst = *src;
        dst++;
        src++;
        bytes--;
    }

    return ret;
}

void *NV_API_CALL os_mem_copy(
    void       *dst,
    const void *src,
    NvU32       length
)
{
#if defined(NVCPU_AARCH64)
    /*
     * TODO: Remove once memset/memcpy restructure is complete
     *
     * When performing memcpy for memory mapped as device, memcpy_[to/from]io
     * must be used. WAR to check the source and destination to determine the
     * correct memcpy_io to use.
     */
    if (is_vmalloc_addr(dst) && !is_vmalloc_addr(src))
    {
        memcpy_toio(dst, src, length);
        return dst;
    }
    else if (!is_vmalloc_addr(dst) && is_vmalloc_addr(src))
    {
        memcpy_fromio(dst, src, length);
        return dst;
    }
    else if (is_vmalloc_addr(dst) && is_vmalloc_addr(src))
    {
        return os_mem_copy_custom(dst, src, length);
    }
    else
#endif
    {
#if defined(CONFIG_CC_OPTIMIZE_FOR_SIZE)
        /*
         * When the kernel is configured with CC_OPTIMIZE_FOR_SIZE=y, Kbuild uses
         * -Os universally. With -Os, GCC will aggressively inline builtins, even
         * if -fno-builtin is specified, including memcpy with a tiny byte-copy
         * loop on x86 (rep movsb). This is horrible for performance - a strict
         * dword copy is much faster - so when we detect this case, just provide
         * our own implementation.
         */
        return os_mem_copy_custom(dst, src, length);
#else
        /*
         * Generally speaking, the kernel-provided memcpy will be the fastest,
         * (optimized much better for the target architecture than the above
         * loop), so we want to use that whenever we can get to it.
         */
        return memcpy(dst, src, length);
#endif
    }
}

NV_STATUS NV_API_CALL os_memcpy_from_user(
    void       *to,
    const void *from,
    NvU32       n
)
{
    return (copy_from_user(to, from, n) ? NV_ERR_INVALID_ADDRESS : NV_OK);
}

NV_STATUS NV_API_CALL os_memcpy_to_user(
    void       *to,
    const void *from,
    NvU32       n
)
{
    return (copy_to_user(to, from, n) ? NV_ERR_INVALID_ADDRESS : NV_OK);
}

void* NV_API_CALL os_mem_set(
    void  *dst,
    NvU8   c,
    NvU32  length
)
{
#if defined(NVCPU_AARCH64)
    /*
     * TODO: Remove once memset/memcpy restructure is complete
     *
     * WAR to check the destination to determine if the memory is of type Device
     * or Normal, and use the correct memset.
     */
    if (is_vmalloc_addr(dst))
    {
        memset_io(dst, (int)c, length);
        return dst;
    }
    else
#endif
       return memset(dst, (int)c, length);
}

NvS32 NV_API_CALL os_mem_cmp(
    const NvU8 *buf0,
    const NvU8* buf1,
    NvU32 length
)
{
    return memcmp(buf0, buf1, length);
}


/*
 * Operating System Memory Functions
 *
 * There are 2 interesting aspects of resource manager memory allocations
 * that need special consideration on Linux:
 *
 * 1. They are typically very large, (e.g. single allocations of 164KB)
 *
 * 2. The resource manager assumes that it can safely allocate memory in
 *    interrupt handlers.
 *
 * The first requires that we call vmalloc, the second kmalloc. We decide
 * which one to use at run time, based on the size of the request and the
 * context. Allocations larger than 128KB require vmalloc, in the context
 * of an ISR they fail.
 */

#if defined(NV_VGX_HYPER)
/*
 * Citrix Hypervisor-8.0 Dom0 sysmem ends up getting fragmented because
 * of which high-order kmalloc allocations fail. We try to avoid it by
 * requesting allocations not larger than 8K.
 *
 * KVM will be affected low memory pressure situation a lot,
 * particularly if hugetlbfs hugepages are being used. Hence, 8K applies
 * here too.
 */
#define KMALLOC_LIMIT 8192
#else
#define KMALLOC_LIMIT 131072
#endif

#define VMALLOC_ALLOCATION_SIZE_FLAG (1 << 0)

NV_STATUS NV_API_CALL os_alloc_mem(
    void **address,
    NvU64 size
)
{
    NvU64 original_size = size;
    unsigned long alloc_size;

    if (address == NULL)
        return NV_ERR_INVALID_ARGUMENT;

    *address = NULL;
    NV_MEM_TRACKING_PAD_SIZE(size);

    // check for integer overflow on size
    if (size < original_size)
        return NV_ERR_INVALID_ARGUMENT;

    //
    // NV_KMALLOC, nv_vmalloc take an input of 4 bytes in x86. To avoid
    // truncation and wrong allocation, below check is required.
    //
    alloc_size = size;

    if (alloc_size != size)
        return NV_ERR_INVALID_PARAMETER;

    if (!NV_MAY_SLEEP())
    {
        if (alloc_size <= KMALLOC_LIMIT)
            NV_KMALLOC_ATOMIC(*address, alloc_size);
    }
    else
    {
        if (alloc_size <= KMALLOC_LIMIT)
        {
            NV_KMALLOC_NO_OOM(*address, alloc_size);
        }
        if (*address == NULL)
        {
            *address = nv_vmalloc(alloc_size, GFP_KERNEL);
            alloc_size |= VMALLOC_ALLOCATION_SIZE_FLAG;
        }
    }

    NV_MEM_TRACKING_HIDE_SIZE(address, alloc_size);

    return ((*address != NULL) ? NV_OK : NV_ERR_NO_MEMORY);
}

void NV_API_CALL os_free_mem(void *address)
{
    NvU64 size;

    NV_MEM_TRACKING_RETRIEVE_SIZE(address, size);

    if (size & VMALLOC_ALLOCATION_SIZE_FLAG)
    {
        size &= ~VMALLOC_ALLOCATION_SIZE_FLAG;
        nv_vfree(address, size);
    }
    else
        NV_KFREE(address, size);
}


/*****************************************************************************
*
*   Name: osGetSystemTime
*
*****************************************************************************/

NV_STATUS NV_API_CALL os_get_system_time(
    NvU32 *seconds,
    NvU32 *useconds
)
{
    struct timespec64 tm;

    ktime_get_real_ts64(&tm);

    *seconds = tm.tv_sec;
    *useconds = tm.tv_nsec / NSEC_PER_USEC;

    return NV_OK;
}

//
// Get the High resolution tick count of the system uptime
//
NvU64 NV_API_CALL os_get_monotonic_time_ns_hr(void)
{
    return nv_ktime_get_raw_ns();
}

NvU64 NV_API_CALL os_get_monotonic_time_ns(void)
{
#if defined(NV_JIFFIES_TO_TIMESPEC_PRESENT)
    struct timespec ts;
    jiffies_to_timespec(jiffies, &ts);
    return (NvU64) timespec_to_ns(&ts);
#else
    struct timespec64 ts;
    jiffies_to_timespec64(jiffies, &ts);
    return (NvU64) timespec64_to_ns(&ts);
#endif
}

NvU64 NV_API_CALL os_get_monotonic_tick_resolution_ns(void)
{
    return (NvU64)jiffies_to_usecs(1) * NSEC_PER_USEC;
}

//---------------------------------------------------------------------------

//
//  Misc services.
//
//---------------------------------------------------------------------------

NV_STATUS NV_API_CALL os_delay_us(NvU32 MicroSeconds)
{
    return nv_delay_us(MicroSeconds);
}

NV_STATUS NV_API_CALL os_delay(NvU32 MilliSeconds)
{
    return nv_sleep_ms(MilliSeconds);
}

NvU64 NV_API_CALL os_get_cpu_frequency(void)
{
    NvU64 cpu_hz = 0;
#if defined(CONFIG_CPU_FREQ)
    cpu_hz = (cpufreq_get(0) * 1000);
#elif defined(NVCPU_X86_64)
    NvU64 tsc[2];

    tsc[0] = nv_rdtsc();
    mdelay(250);
    tsc[1] = nv_rdtsc();

    cpu_hz = ((tsc[1] - tsc[0]) * 4);
#endif
    return cpu_hz;
}

NvU32 NV_API_CALL os_get_current_process(void)
{
    return current->tgid;
}

void NV_API_CALL os_get_current_process_name(char *buf, NvU32 len)
{
    task_lock(current);
    if (strscpy(buf, current->comm, len) < 0) {
        // strscpy() returns -E2BIG on truncation, which is acceptable here.
    }

    task_unlock(current);
}

NV_STATUS NV_API_CALL os_iommu_sva_bind(void *arg, void **handle, NvU32 *pasid)
{
    nv_state_t *nv = arg;
#if defined(CONFIG_IOMMU_SVA) && \
    (defined(NV_IOASID_GET_PRESENT) || defined(NV_MM_PASID_DROP_PRESENT))
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    struct iommu_sva *sva_handle;

    if (pasid == NULL || handle == NULL)
        return NV_ERR_INVALID_ARGUMENT;

    *pasid = 0;
    *handle = NULL;

    if (nv->ats_support && current && current->mm)
    {
#if defined(NV_IOMMU_SVA_BIND_DEVICE_HAS_DRVDATA_ARG)
        sva_handle = iommu_sva_bind_device(nvl->dev, current->mm, NULL);
#else
        sva_handle = iommu_sva_bind_device(nvl->dev, current->mm);
#endif
        if (!IS_ERR(sva_handle))
        {
            *pasid = iommu_sva_get_pasid(sva_handle);
            *handle = sva_handle;
            NV_DEV_PRINTF(NV_DBG_INFO, nv, "PASID: %u\n", *pasid);

            return NV_OK;
        }
    }
#endif
    NV_DEV_PRINTF(NV_DBG_ERRORS, nv, "IOMMU SVA bind failed\n");

    return NV_ERR_INVALID_STATE;
}

void NV_API_CALL os_iommu_sva_unbind(void *handle)
{
#if defined(CONFIG_IOMMU_SVA) && \
    (defined(NV_IOASID_GET_PRESENT) || defined(NV_MM_PASID_DROP_PRESENT))
    iommu_sva_unbind_device(handle);
#endif
}

NV_STATUS NV_API_CALL os_get_current_thread(NvU64 *threadId)
{
    if (in_interrupt())
        *threadId = 0;
    else
        *threadId = (NvU64) current->pid;

    return NV_OK;
}

/*******************************************************************************/
/*                                                                             */
/* Debug and logging utilities follow                                          */
/*                                                                             */
/*******************************************************************************/

// The current debug display level (default to maximum debug level)
NvU32 cur_debuglevel = 0xffffffff;

/*
 * The binary core of RM (nv-kernel.o) calls both out_string, and nv_printf.
 */
inline void NV_API_CALL out_string(const char *str)
{
    printk("%s", str);
}

/*
 * nv_printf() prints to the kernel log for the driver.
 * Returns the number of characters written.
 */
int NV_API_CALL nv_printf(NvU32 debuglevel, const char *printf_format, ...)
{
    va_list arglist;
    int chars_written = 0;

    if (debuglevel >= ((cur_debuglevel >> 4) & 0x3))
    {
        size_t length;
        unsigned long flags;

        // When printk is called to extend the output of the previous line
        // (i.e. when the previous line did not end in \n), the printk call
        // must contain KERN_CONT.  Older kernels still print the line
        // correctly, but KERN_CONT was technically always required.

        // This means that every call to printk() needs to have a KERN_xxx
        // prefix.  The only way to get this is to rebuild the format string
        // into a new buffer, with a KERN_xxx prefix prepended.

        // Unfortunately, we can't guarantee that two calls to nv_printf()
        // won't be interrupted by a printk from another driver.  So to be
        // safe, we always append KERN_CONT.  It's still technically wrong,
        // but it works.

        // The long-term fix is to modify all NV_PRINTF-ish calls so that the
        // string always contains only one \n (at the end) and NV_PRINTF_EX
        // is deleted.  But that is unlikely to ever happen.

        length = strlen(printf_format);
        if (length < 1)
            return 0;

        NV_SPIN_LOCK_IRQSAVE(&nv_error_string_lock, flags);

        // KERN_CONT changed in the 3.6 kernel, so we can't assume its
        // composition or size.
        memcpy(nv_error_string, KERN_CONT, sizeof(KERN_CONT) - 1);
        memcpy(nv_error_string + sizeof(KERN_CONT) - 1, printf_format, length + 1);

        va_start(arglist, printf_format);
        chars_written = vprintk(nv_error_string, arglist);
        va_end(arglist);

        NV_SPIN_UNLOCK_IRQRESTORE(&nv_error_string_lock, flags);
    }

    return chars_written;
}

int NV_API_CALL nv_vprintf(NvU32 debuglevel, const char *printf_format, va_list arglist)
{
    int chars_written = 0;

    if (debuglevel >= ((cur_debuglevel >> 4) & 0x3))
    {
        size_t length;
        unsigned long flags;
        va_list arglistCopy;

        length = strlen(printf_format);
        if (length < 1)
            return 0;

        NV_SPIN_LOCK_IRQSAVE(&nv_error_string_lock, flags);

        memcpy(nv_error_string, KERN_CONT, sizeof(KERN_CONT) - 1);
        memcpy(nv_error_string + sizeof(KERN_CONT) - 1, printf_format, length + 1);

        va_copy(arglistCopy, arglist);
        chars_written = vprintk(nv_error_string, arglistCopy);
        va_end(arglistCopy);

        NV_SPIN_UNLOCK_IRQRESTORE(&nv_error_string_lock, flags);
    }

    return chars_written;
}

static int
_nv_log_level_to_linux_syslog_level(NV_LOG_LEVEL level)
{
    switch (level)
    {
        case NV_LOG_LEVEL_ALERT:   return LOGLEVEL_ALERT;
        case NV_LOG_LEVEL_CRIT:    return LOGLEVEL_CRIT;
        case NV_LOG_LEVEL_ERROR:   return LOGLEVEL_ERR;
        case NV_LOG_LEVEL_WARNING: return LOGLEVEL_WARNING;
        case NV_LOG_LEVEL_NOTICE:  return LOGLEVEL_NOTICE;
        case NV_LOG_LEVEL_INFO:    return LOGLEVEL_INFO;
        case NV_LOG_LEVEL_DEBUG:   return LOGLEVEL_DEBUG;
        default:                   return LOGLEVEL_INFO;
    }
}

int NV_API_CALL nv_dev_printf(struct nv_state_t *nv, NV_LOG_LEVEL level, const char *printf_format, ...)
{
    va_list arglist;
    int chars_written;

    va_start(arglist, printf_format);
    chars_written = nv_dev_vprintf(nv, level, printf_format, arglist);
    va_end(arglist);

    return chars_written;
}

int NV_API_CALL nv_dev_vprintf(struct nv_state_t *nv, NV_LOG_LEVEL level, const char *printf_format, va_list arglist)
{
    int chars_written = 0;
    nv_linux_state_t *nvl;
    struct device *dev;
    va_list arglistCopy;

    if (nv == NULL)
        return 0;

    nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    dev = (nvl != NULL) ? nvl->dev : NULL;
    if (dev == NULL)
        return 0;

    //
    // Prepend the visible "<driver> <dev_name>: " prefix in the format the
    // same way Linux's _dev_printk() does. dev_vprintk_emit() on its own
    // only attaches device info to the structured syslog metadata; it does
    // not inject a visible prefix into the message text. Without this
    // wrapping, portDbgDevicePrintf() callers would show up in dmesg
    // without the "<driver> <bus-id>:" prefix the API was intended to
    // provide (e.g. "nvidia 0000:c1:00.0: ...").
    //
    {
        struct va_format vaf;

        va_copy(arglistCopy, arglist);
        vaf.fmt = printf_format;
        vaf.va  = &arglistCopy;
        chars_written = dev_printk_emit(_nv_log_level_to_linux_syslog_level(level),
                                        dev, "%s %s: %pV",
                                        dev_driver_string(dev), dev_name(dev), &vaf);
        va_end(arglistCopy);
    }

    return chars_written;
}

NvS32 NV_API_CALL os_snprintf(char *buf, NvU32 size, const char *fmt, ...)
{
    va_list arglist;
    int chars_written;

    va_start(arglist, fmt);
    chars_written = vsnprintf(buf, size, fmt, arglist);
    va_end(arglist);

    return chars_written;
}

NvS32 NV_API_CALL os_vsnprintf(char *buf, NvU32 size, const char *fmt, va_list arglist)
{
    return vsnprintf(buf, size, fmt, arglist);
}

void NV_API_CALL os_log_error(const char *fmt, va_list ap)
{
    unsigned long flags;

    NV_SPIN_LOCK_IRQSAVE(&nv_error_string_lock, flags);

    vsnprintf(nv_error_string, MAX_ERROR_STRING, fmt, ap);
    nv_error_string[MAX_ERROR_STRING - 1] = 0;
    printk(KERN_ERR "%s", nv_error_string);

    NV_SPIN_UNLOCK_IRQRESTORE(&nv_error_string_lock, flags);
}

void NV_API_CALL os_io_write_byte(
    NvU32 address,
    NvU8 value
)
{
    outb(value, address);
}

void NV_API_CALL os_io_write_word(
    NvU32 address,
    NvU16 value
)
{
    outw(value, address);
}

void NV_API_CALL os_io_write_dword(
    NvU32 address,
    NvU32 value
)
{
    outl(value, address);
}

NvU8 NV_API_CALL os_io_read_byte(
    NvU32 address
)
{
    return inb(address);
}

NvU16 NV_API_CALL os_io_read_word(
    NvU32 address
)
{
    return inw(address);
}

NvU32 NV_API_CALL os_io_read_dword(
    NvU32 address
)
{
    return inl(address);
}


static NvBool NV_API_CALL xen_support_fully_virtualized_kernel(void)
{
#if defined(NV_XEN_SUPPORT_FULLY_VIRTUALIZED_KERNEL)
    return (os_is_vgx_hyper());
#endif
    return NV_FALSE;
}

void* NV_API_CALL os_map_kernel_space(
    NvU64 start,
    NvU64 size_bytes,
    NvU32 mode
)
{
    void *vaddr;

    if (!xen_support_fully_virtualized_kernel() && start == 0)
    {
        if (mode != NV_MEMORY_CACHED)
        {
            nv_printf(NV_DBG_ERRORS,
                "NVRM: os_map_kernel_space: won't map address 0x%0llx UC!\n", start);
            return NULL;
        }
        else
            return (void *)PAGE_OFFSET;
    }

    if (!NV_MAY_SLEEP())
    {
        nv_printf(NV_DBG_ERRORS,
            "NVRM: os_map_kernel_space: can't map 0x%0llx, invalid context!\n", start);
        os_dbg_breakpoint();
        return NULL;
    }

    switch (mode)
    {
        case NV_MEMORY_CACHED:
            vaddr = nv_ioremap_cache(start, size_bytes);
            break;
        case NV_MEMORY_WRITECOMBINED:
            vaddr = rm_disable_iomap_wc() ?
                    nv_ioremap_nocache(start, size_bytes) :
                    nv_ioremap_wc(start, size_bytes);
            break;
        case NV_MEMORY_UNCACHED:
            vaddr = nv_ioremap_nocache(start, size_bytes);
            break;
        default:
            nv_printf(NV_DBG_ERRORS,
                "NVRM: os_map_kernel_space: unsupported mode!\n");
            return NULL;
    }

    return vaddr;
}

void NV_API_CALL os_unmap_kernel_space(
    void *addr,
    NvU64 size_bytes
)
{
    if (addr == (void *)PAGE_OFFSET)
        return;

    nv_iounmap(addr, size_bytes);
}

#if NVCPU_IS_AARCH64

static inline void nv_flush_cache_cpu(void *info)
{
    if (!nvos_is_chipset_io_coherent())
    {
#if defined(NV_FLUSH_CACHE_ALL_PRESENT)
        flush_cache_all();
#else
        WARN_ONCE(0, "kernel does not provide flush_cache_all()\n");
#endif
    }
}

// flush the cache of all cpus
NV_STATUS NV_API_CALL os_flush_cpu_cache_all(void)
{
    on_each_cpu(nv_flush_cache_cpu, NULL, 1);
    return NV_OK;
}

NV_STATUS NV_API_CALL os_flush_user_cache(void)
{
    if (!NV_MAY_SLEEP())
    {
        return NV_ERR_NOT_SUPPORTED;
    }

    //
    // The Linux kernel does not export an interface for flushing a range,
    // although it is possible. For now, just flush the entire cache to be
    // safe.
    //
    on_each_cpu(nv_flush_cache_cpu, NULL, 1);
    return NV_OK;
}

#else // NVCPU_IS_AARCH64

NV_STATUS NV_API_CALL os_flush_cpu_cache_all(void)
{
    return NV_ERR_NOT_SUPPORTED;
}

NV_STATUS NV_API_CALL os_flush_user_cache(void)
{
    return NV_ERR_NOT_SUPPORTED;
}

#endif

void NV_API_CALL os_flush_cpu_write_combine_buffer(void)
{
#if defined(NVCPU_X86_64)
    asm volatile("sfence" ::: "memory");
#elif defined(NVCPU_AARCH64)
    asm volatile("dsb st" : : : "memory");
#else
    mb();
#endif
}

// override initial debug level from registry
void NV_API_CALL os_dbg_init(void)
{
    NvU32 new_debuglevel;
    nvidia_stack_t *sp = NULL;

    if (nv_kmem_cache_alloc_stack(&sp) != 0)
    {
        return;
    }

    if (NV_OK == rm_read_registry_dword(sp, NULL,
                                        "ResmanDebugLevel",
                                        &new_debuglevel))
    {
        if (new_debuglevel != (NvU32)~0)
            cur_debuglevel = new_debuglevel;
    }

    nv_kmem_cache_free_stack(sp);
}

void NV_API_CALL os_dbg_set_level(NvU32 new_debuglevel)
{
    nv_printf(NV_DBG_SETUP, "NVRM: Changing debuglevel from 0x%x to 0x%x\n",
        cur_debuglevel, new_debuglevel);
    cur_debuglevel = new_debuglevel;
}

NvU64 NV_API_CALL os_get_max_user_va(void)
{
    return TASK_SIZE;
}

NV_STATUS NV_API_CALL os_schedule(void)
{
    if (NV_MAY_SLEEP())
    {
        set_current_state(TASK_INTERRUPTIBLE);
        schedule_timeout(1);
        return NV_OK;
    }
    else
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: os_schedule: Attempted to yield"
                                 " the CPU while in atomic or interrupt"
                                 " context\n");
        return NV_ERR_ILLEGAL_ACTION;
    }
}

typedef struct {
    nv_kthread_q_item_t item;
    void *data;
} os_queue_data_t;

static void os_execute_work_item(void *_oqd)
{
    os_queue_data_t *oqd = _oqd;
    nvidia_stack_t *sp = NULL;
    void *data = oqd->data;

    NV_KFREE(oqd, sizeof(os_queue_data_t));

    if (nv_kmem_cache_alloc_stack(&sp) != 0)
    {
        return;
    }

    rm_execute_work_item(sp, data);

    nv_kmem_cache_free_stack(sp);
}

NV_STATUS NV_API_CALL os_queue_work_item(struct os_work_queue *queue, void *data)
{
    os_queue_data_t *oqd;
    nv_kthread_q_t *kthread;

    /* Use the global queue unless a valid queue was provided */
    kthread = queue ? &queue->nvk : &nv_kthread_q;

    /* Make sure the kthread is active */
    if (unlikely(!kthread->q_kthread)) {
        nv_printf(NV_DBG_ERRORS, "NVRM: queue is not enabled\n");
        return NV_ERR_NOT_READY;
    }

    /* Allocate atomically just in case we're called in atomic context. */
    NV_KMALLOC_ATOMIC(oqd, sizeof(os_queue_data_t));
    if (!oqd)
        return NV_ERR_NO_MEMORY;

    nv_kthread_q_item_init(&oqd->item, os_execute_work_item, oqd);
    oqd->data = data;

    nv_kthread_q_schedule_q_item(kthread, &oqd->item);

    return NV_OK;
}

NV_STATUS NV_API_CALL os_flush_work_queue(struct os_work_queue *queue, NvBool is_unload)
{
    nv_kthread_q_t *kthread;

    /* Use the global queue unless a valid queue was provided */
    kthread = queue ? &queue->nvk : &nv_kthread_q;

    if (NV_MAY_SLEEP())
    {
        kthread->is_unload_flush_ongoing = is_unload;

        if (kthread->q_kthread)
            nv_kthread_q_flush(kthread);

        kthread->is_unload_flush_ongoing = NV_FALSE;

        return NV_OK;
    }
    else
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: os_flush_work_queue: attempted to execute passive"
                  "work from an atomic or interrupt context.\n");
        return NV_ERR_ILLEGAL_ACTION;
    }
}

NvBool NV_API_CALL os_is_queue_flush_ongoing(struct os_work_queue *queue)
{
    nv_kthread_q_t *kthread = queue ? &queue->nvk : &nv_kthread_q;

    return kthread->is_unload_flush_ongoing;
}

extern NvU32 NVreg_EnableDbgBreakpoint;

void NV_API_CALL os_dbg_breakpoint(void)
{
    if (NVreg_EnableDbgBreakpoint == 0)
    {
        return;
    }

#if defined(CONFIG_X86_REMOTE_DEBUG) || defined(CONFIG_KGDB) || defined(CONFIG_XMON)
  #if defined(NVCPU_X86_64)
    __asm__ __volatile__ ("int $3");
  #elif defined(NVCPU_ARM)
    __asm__ __volatile__ (".word %c0" :: "i" (KGDB_COMPILED_BREAK));
  #elif defined(NVCPU_AARCH64)
    # warning "Need to implement os_dbg_breakpoint() for aarch64"
  #endif // NVCPU_*
#elif defined(CONFIG_KDB)
    KDB_ENTER();
#endif // CONFIG_X86_REMOTE_DEBUG || CONFIG_KGDB || CONFIG_XMON
}

NvU32 NV_API_CALL os_get_cpu_number(void)
{
    NvU32 cpu_id = get_cpu();
    put_cpu();
    return cpu_id;
}

NvU32 NV_API_CALL os_get_cpu_count(void)
{
    return num_possible_cpus();
}

NvBool NV_API_CALL os_is_efi_enabled(void)
{
    return efi_enabled(EFI_BOOT);
}

void NV_API_CALL os_dump_stack(void)
{
    dump_stack();
}

typedef struct os_spinlock_s
{
    nv_spinlock_t      lock;
    unsigned long      eflags;
#if defined(CONFIG_LOCKDEP)
    /**
     * A key of lock class. It would be registered to Lockdep validator so all
     * instances' usages and dependencies will contribute to constructing correct
     * locking rules and this lock will be tracked by the Lockdep validator.
     *
     */
    struct lock_class_key key;
#endif // CONFIG_LOCKDEP
} os_spinlock_t;

NV_STATUS NV_API_CALL os_alloc_spinlock(void **ppSpinlock)
{
    NV_STATUS rmStatus;
    os_spinlock_t *os_spinlock;

    rmStatus = os_alloc_mem(ppSpinlock, sizeof(os_spinlock_t));
    if (rmStatus != NV_OK)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to allocate spinlock!\n");
        return rmStatus;
    }

    os_spinlock = (os_spinlock_t *)*ppSpinlock;
    NV_SPIN_LOCK_INIT(&os_spinlock->lock);
#if defined(CONFIG_LOCKDEP)
#if NV_IS_EXPORT_SYMBOL_PRESENT_lockdep_register_key
    // Register the dynamically allocated key to Lockdep.
    lockdep_register_key(&os_spinlock->key);
    lockdep_set_class(&os_spinlock->lock, &os_spinlock->key);
#endif // NV_IS_EXPORT_SYMBOL_PRESENT_lockdep_register_key
#endif // CONFIG_LOCKDEP
    os_spinlock->eflags = 0;
    return NV_OK;
}

void NV_API_CALL os_free_spinlock(void *pSpinlock)
{

#if defined(CONFIG_LOCKDEP)
    os_spinlock_t *os_spinlock = (os_spinlock_t *)pSpinlock;
    // Unregister the dynamically allocated key.
    lockdep_unregister_key(&os_spinlock->key);
#endif // CONFIG_LOCKDEP
    os_free_mem(pSpinlock);
}

NvU64 NV_API_CALL os_acquire_spinlock(void *pSpinlock)
{
    os_spinlock_t *os_spinlock = (os_spinlock_t *)pSpinlock;
    unsigned long eflags;

    NV_SPIN_LOCK_IRQSAVE(&os_spinlock->lock, eflags);
    os_spinlock->eflags = eflags;

#if defined(NVCPU_X86_64)
    eflags &= X86_EFLAGS_IF;
#elif defined(NVCPU_AARCH64)
    eflags &= PSR_I_BIT;
#endif
    return eflags;
}

void NV_API_CALL os_release_spinlock(void *pSpinlock, NvU64 oldIrql)
{
    os_spinlock_t *os_spinlock = (os_spinlock_t *)pSpinlock;
    unsigned long eflags;

    eflags = os_spinlock->eflags;
    os_spinlock->eflags = 0;
    NV_SPIN_UNLOCK_IRQRESTORE(&os_spinlock->lock, eflags);
}

#define NV_KERNEL_RELEASE    ((LINUX_VERSION_CODE >> 16) & 0x0ff)
#define NV_KERNEL_VERSION    ((LINUX_VERSION_CODE >> 8)  & 0x0ff)
#define NV_KERNEL_SUBVERSION ((LINUX_VERSION_CODE)       & 0x0ff)

NV_STATUS NV_API_CALL os_get_version_info(os_version_info * pOsVersionInfo)
{
    NV_STATUS status      = NV_OK;

    pOsVersionInfo->os_major_version = NV_KERNEL_RELEASE;
    pOsVersionInfo->os_minor_version = NV_KERNEL_VERSION;
    pOsVersionInfo->os_build_number  = NV_KERNEL_SUBVERSION;

#if defined(UTS_RELEASE)
    pOsVersionInfo->os_build_version_str = UTS_RELEASE;
#endif

#if defined(UTS_VERSION)
    pOsVersionInfo->os_build_date_plus_str = UTS_VERSION;
#endif

    return status;
}

NV_STATUS NV_API_CALL os_get_is_openrm(NvBool *bIsOpenRm)
{
#if defined(NVCPU_X86_64) || defined(NVCPU_AARCH64)
    *bIsOpenRm = NV_TRUE;
    return NV_OK;
#else // defined(NVCPU_X86_64) || defined(NVCPU_AARCH64)
    return NV_ERR_NOT_SUPPORTED;
#endif // defined(NVCPU_X86_64) || defined(NVCPU_AARCH64)
}

NvBool NV_API_CALL os_is_bif_reset_supported(void *pOsGpuInfo)
{
    nv_state_t *nv = (nv_state_t *) pOsGpuInfo;
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);

    // BIF reset is not supported if init on probe is enabled
    return !(nvl->init_on_probe);
}

NvBool NV_API_CALL os_is_xen_dom0(void)
{
#if defined(NV_DOM0_KERNEL_PRESENT)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}

NvBool NV_API_CALL os_is_vgx_hyper(void)
{
#if defined(NV_VGX_HYPER)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}

NV_STATUS NV_API_CALL os_inject_vgx_msi(NvU16 guestID, NvU64 msiAddr, NvU32 msiData)
{
#if defined(NV_VGX_HYPER) && defined(NV_DOM0_KERNEL_PRESENT) && \
    defined(NV_XEN_IOEMU_INJECT_MSI)
    int rc = 0;
    rc = xen_ioemu_inject_msi(guestID, msiAddr, msiData);
    if (rc)
    {
        nv_printf(NV_DBG_ERRORS,
            "NVRM: %s: can't inject MSI to guest:%d, addr:0x%x, data:0x%x, err:%d\n",
            __FUNCTION__, guestID, msiAddr, msiData, rc);
        return NV_ERR_OPERATING_SYSTEM;
    }
    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif
}

NvBool NV_API_CALL os_is_grid_supported(void)
{
#if defined(NV_GRID_BUILD)
    return NV_TRUE;
#else
    return NV_FALSE;
#endif
}

NvU32 NV_API_CALL os_get_grid_csp_support(void)
{
#if defined(NV_GRID_BUILD_CSP)
    return NV_GRID_BUILD_CSP;
#else
    return 0;
#endif
}

void NV_API_CALL os_bug_check(NvU32 bugCode, const char *bugCodeStr)
{
    panic(bugCodeStr);
}

NV_STATUS NV_API_CALL os_get_euid(NvU32 *pSecToken)
{
    *pSecToken = NV_CURRENT_EUID();
    return NV_OK;
}

#if defined(NVCPU_X86_64) || defined(NVCPU_AARCH64)

static NvBool os_verify_checksum(const NvU8 *pMappedAddr, NvU32 length)
{
    NvU8 sum = 0;
    NvU32 iter = 0;

    for (iter = 0; iter < length; iter++)
        sum += pMappedAddr[iter];

    return sum == 0;
}

#define _VERIFY_SMBIOS3(_pMappedAddr)                        \
        _pMappedAddr &&                                      \
        (os_mem_cmp(_pMappedAddr, "_SM3_", 5) == 0  &&       \
        _pMappedAddr[6] < 32 &&                              \
        _pMappedAddr[6] > 0 &&                               \
        os_verify_checksum(_pMappedAddr, _pMappedAddr[6]))

#define OS_VERIFY_SMBIOS3(pMappedAddr) _VERIFY_SMBIOS3((pMappedAddr))

#define _VERIFY_SMBIOS(_pMappedAddr)                           \
        _pMappedAddr &&                                        \
        (os_mem_cmp(_pMappedAddr, "_SM_", 4) == 0  &&          \
        _pMappedAddr[5] < 32 &&                                \
        _pMappedAddr[5] > 0 &&                                 \
        os_verify_checksum(_pMappedAddr, _pMappedAddr[5]) &&   \
        os_mem_cmp((_pMappedAddr + 16), "_DMI_", 5) == 0  &&   \
        os_verify_checksum((_pMappedAddr + 16), 15))

#define OS_VERIFY_SMBIOS(pMappedAddr) _VERIFY_SMBIOS((pMappedAddr))

#define SMBIOS_LEGACY_BASE 0xF0000
#define SMBIOS_LEGACY_SIZE 0x10000

static NV_STATUS os_get_smbios_header_legacy(NvU64 *pSmbsAddr)
{
#if !defined(NVCPU_X86_64)
    return NV_ERR_NOT_SUPPORTED;
#else
    NV_STATUS status = NV_ERR_OPERATING_SYSTEM;
    NvU8 *pMappedAddr = NULL;
    NvU8 *pIterAddr = NULL;

    pMappedAddr = (NvU8*)os_map_kernel_space(SMBIOS_LEGACY_BASE,
                                             SMBIOS_LEGACY_SIZE,
                                             NV_MEMORY_CACHED);
    if (pMappedAddr == NULL)
    {
        return NV_ERR_INSUFFICIENT_RESOURCES;
    }

    pIterAddr = pMappedAddr;

    for (; pIterAddr < (pMappedAddr + SMBIOS_LEGACY_SIZE); pIterAddr += 16)
    {
        if (OS_VERIFY_SMBIOS3(pIterAddr))
        {
            *pSmbsAddr = SMBIOS_LEGACY_BASE + (pIterAddr - pMappedAddr);
            status = NV_OK;
            break;
        }

        if (OS_VERIFY_SMBIOS(pIterAddr))
        {
            *pSmbsAddr = SMBIOS_LEGACY_BASE + (pIterAddr - pMappedAddr);
            status = NV_OK;
            break;
        }
    }

    os_unmap_kernel_space(pMappedAddr, SMBIOS_LEGACY_SIZE);

    return status;
#endif
}

// This function is needed only if "efi" is enabled.
#if defined(CONFIG_EFI)
static NV_STATUS os_verify_smbios_header_uefi(NvU64 smbsAddr)
{
    NV_STATUS status = NV_ERR_OBJECT_NOT_FOUND;
    NvU64 start= 0, offset =0 , size = 32;
    NvU8 *pMappedAddr = NULL, *pBufAddr = NULL;

    start = smbsAddr;
    offset = (start & ~os_page_mask);
    start &= os_page_mask;
    size = ((size + offset + ~os_page_mask) & os_page_mask);

    pBufAddr = (NvU8*)os_map_kernel_space(start,
                                          size,
                                          NV_MEMORY_CACHED);
    if (pBufAddr == NULL)
    {
        return NV_ERR_INSUFFICIENT_RESOURCES;
    }

    pMappedAddr = pBufAddr + offset;

    if (OS_VERIFY_SMBIOS3(pMappedAddr))
    {
        status = NV_OK;
        goto done;
    }

    if (OS_VERIFY_SMBIOS(pMappedAddr))
    {
        status = NV_OK;
    }

done:
    os_unmap_kernel_space(pBufAddr, size);
    return status;
}
#endif

static NV_STATUS os_get_smbios_header_uefi(NvU64 *pSmbsAddr)
{
    NV_STATUS status = NV_ERR_OPERATING_SYSTEM;

#if defined(CONFIG_EFI)

// Make sure that efi.h has SMBIOS3_TABLE_GUID present.
#if defined(SMBIOS3_TABLE_GUID)
    if (efi.smbios3 != EFI_INVALID_TABLE_ADDR)
    {
        status = os_verify_smbios_header_uefi(efi.smbios3);
        if (status == NV_OK)
        {
            *pSmbsAddr = efi.smbios3;
            return NV_OK;
        }
    }
#endif

    if (efi.smbios != EFI_INVALID_TABLE_ADDR)
    {
        status = os_verify_smbios_header_uefi(efi.smbios);
        if (status == NV_OK)
        {
            *pSmbsAddr = efi.smbios;
            return NV_OK;
        }
    }
#endif

    return status;
}

#endif // defined(NVCPU_X86_64) || defined(NVCPU_AARCH64)

// The function locates the SMBIOS entry point.
NV_STATUS NV_API_CALL os_get_smbios_header(NvU64 *pSmbsAddr)
{

#if !defined(NVCPU_X86_64) && !defined(NVCPU_AARCH64)
    return NV_ERR_NOT_SUPPORTED;
#else
    NV_STATUS status = NV_OK;

    if (os_is_efi_enabled())
    {
        status = os_get_smbios_header_uefi(pSmbsAddr);
    }
    else
    {
        status = os_get_smbios_header_legacy(pSmbsAddr);
    }

    return status;
#endif
}

NV_STATUS NV_API_CALL os_get_acpi_rsdp_from_uefi
(
    NvU32  *pRsdpAddr
)
{
    NV_STATUS status = NV_ERR_NOT_SUPPORTED;

    if (pRsdpAddr == NULL)
    {
        return NV_ERR_INVALID_STATE;
    }

    *pRsdpAddr = 0;

#if defined(CONFIG_EFI)
    if (efi.acpi20 != EFI_INVALID_TABLE_ADDR)
    {
        *pRsdpAddr = efi.acpi20;
        status = NV_OK;
    }
    else if (efi.acpi != EFI_INVALID_TABLE_ADDR)
    {
        *pRsdpAddr = efi.acpi;
        status = NV_OK;
    }
    else
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: RSDP Not found!\n");
        status = NV_ERR_OPERATING_SYSTEM;
    }
#endif

    return status;
}

void NV_API_CALL os_add_record_for_crashLog(void *pbuffer, NvU32 size)
{
}

void NV_API_CALL os_delete_record_for_crashLog(void *pbuffer)
{
}

#if !defined(NV_VGPU_KVM_BUILD)
NV_STATUS NV_API_CALL os_call_vgpu_vfio(void *pvgpu_vfio_info, NvU32 cmd_type)
{
    return NV_ERR_NOT_SUPPORTED;
}
#endif

NV_STATUS NV_API_CALL os_alloc_pages_node
(
    NvS32  nid,
    NvU32  size,
    NvU32  flags,
    NvU64 *pAddress
)
{
    NV_STATUS status = NV_ERR_NOT_SUPPORTED;

#if defined(__GFP_THISNODE) && defined(GFP_HIGHUSER_MOVABLE) && \
    defined(__GFP_COMP) && defined(__GFP_NOWARN)
    gfp_t gfp_mask;
    struct page *alloc_addr;
    unsigned int order = get_order(size);

    /*
     * Explanation of flags used:
     *
     * 1. __GFP_THISNODE:           This will make sure the allocation happens
     *                              on the node specified by nid.
     *
     * 2. GFP_HIGHUSER_MOVABLE:     This makes allocations from ZONE_MOVABLE.
     *
     * 3. __GFP_COMP:               This will make allocations with compound
     *                              pages, which is needed in order to use
     *                              vm_insert_page API.
     *
     * 4. __GFP_NOWARN:             Used to avoid a WARN_ON in the slowpath if
     *                              the requested order is too large (just fail
     *                              instead).
     *
     * 5. __GFP_RETRY_MAYFAIL:      Used to avoid the Linux kernel OOM killer.
     *                              To help PMA on paths where UVM might be in
     *                              memory over subscription. This gives UVM a
     *                              chance to free memory before invoking any
     *                              action from the OOM killer.  Freeing
     *                              non-essential memory will also benefit the
     *                              system as a whole.
     *
     * 6. __GFP_ACCOUNT:            Used to track/account for allocations with cgroups.
     *                              The first attempt at adding this flag caused crashes
     *                              in some tests using CentOS and old kernels (4.18).
     *                              UVM has a similar guard against older versions, so we're
     *                              using one here to be at-or-later than the versions we
     *                              support for vidmem cgroup tracking (5.14+)
     *
     * 7. (Optional) __GFP_RECLAIM: Used to allow/forbid reclaim.
     *                              This is part of GFP_USER and consequently
     *                              GFP_HIGHUSER_MOVABLE.
     *
     * 8. (Optional) __GFP_NOMEMALLOC: Used to prevent access to "atomic" reserves.
     *                                 Kernels 6.4+ removed __GFP_ATOMIC and
     *                                 replaced the functionality with a negative
     *                                 check for DIRECT_RECLAIM. Having access to
     *                                 atomic reserves comes with constraints and
     *                                 it can grow the dynamic part of the reserves.
     *                                 Since kernel 6.6 the static reseves are only
     *                                 32 pages for ZONE_MOVABLE so it's ok to not
     *                                 have access to the reserves.
     *                              
     *
     *
     * Some of these flags are relatively more recent, with the last of them
     * (GFP_HIGHUSER_MOVABLE) having been added with this Linux kernel commit:
     *
     * 2007-07-17 769848c03895b63e5662eb7e4ec8c4866f7d0183
     *
     * Assume that this feature will only be used on kernels that support all
     * of the needed GFP flags.
     */

    gfp_mask = __GFP_THISNODE | GFP_HIGHUSER_MOVABLE | __GFP_COMP |
               __GFP_NOWARN | __GFP_RETRY_MAYFAIL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 14, 0)
    if (flags & NV_ALLOC_PAGES_NODE_DO_ACCOUNT)
    {
        gfp_mask |= __GFP_ACCOUNT;
    }
#endif

    if (flags & NV_ALLOC_PAGES_NODE_SKIP_RECLAIM)
    {
        gfp_mask &= ~(__GFP_RECLAIM);
        // Skipping direct reclaim on highorder allocations would grow
        // highatomic reserves, prevent this with __GFP_NOMEMALLOC.
        if (order > 0)
            gfp_mask |= __GFP_NOMEMALLOC;
    }

    alloc_addr = alloc_pages_node(nid, gfp_mask, order);
    if (alloc_addr == NULL)
    {
        nv_printf(NV_DBG_INFO,
            "NVRM: alloc_pages_node(node = %d, order = %u) failed\n",
            nid, order);
        status = NV_ERR_NO_MEMORY;
    }
    else if (page_to_nid(alloc_addr) != nid)
    {
        //
        // We can hit this case when a Linux kernel bug is not patched.
        // The needed patch is https://patchwork.kernel.org/patch/10427387/
        //
        nv_printf(NV_DBG_ERRORS,
            "NVRM: alloc_pages_node(node = %d, order = %u) wrong node ID.\n",
            nid, order);
        __free_pages(alloc_addr, order);
        status = NV_ERR_NO_MEMORY;
    }
    else
    {
        *pAddress = (NvU64)page_to_phys(alloc_addr);
        status = NV_OK;
    }
#endif // GFP flags

    return status;
}

NV_STATUS NV_API_CALL os_get_page
(
    NvU64 address
)
{
    get_page(NV_GET_PAGE_STRUCT(address));
    return NV_OK;
}

NV_STATUS NV_API_CALL os_put_page
(
    NvU64 address
)
{
    put_page(NV_GET_PAGE_STRUCT(address));
    return NV_OK;
}

NvU32 NV_API_CALL os_get_page_refcount
(
    NvU64 address
)
{
    return NV_PAGE_COUNT(NV_GET_PAGE_STRUCT(address));
}

NvU32 NV_API_CALL os_count_tail_pages
(
    NvU64 address
)
{
    NvU32 order = compound_order(compound_head(NV_GET_PAGE_STRUCT(address)));

    return 1 << order;
}

void NV_API_CALL os_free_pages_phys
(
    NvU64 address,
    NvU32 size
)
{
    __free_pages(NV_GET_PAGE_STRUCT(address), get_order(size));
}

NV_STATUS NV_API_CALL os_numa_memblock_size
(
    NvU64 *memblock_size
)
{
#if NV_IS_EXPORT_SYMBOL_PRESENT_memory_block_size_bytes
    *memblock_size = memory_block_size_bytes();
    return NV_OK;
#endif
    if (nv_ctl_device.numa_memblock_size == 0)
        return NV_ERR_INVALID_STATE;
    *memblock_size = nv_ctl_device.numa_memblock_size;
    return NV_OK;
}

/*
 * Allocates an anonymous file to be used only within the kernel.
 *
 * This file may bypass LSM checks such as SELinux, so it is important that this
 * file never be mapped, linked into the filesystem, or assigned a file
 * descriptor unless access control is checked by the caller.
 */
NV_STATUS NV_API_CALL os_allocate_temporary_file
(
    void **ppFile,
    NvU64 size
)
{
    struct file *file = ERR_PTR(-EOPNOTSUPP);
#if NV_FILESYSTEM_ACCESS_AVAILABLE
    const char *default_path = "/tmp";
    const int flags = O_TMPFILE | O_LARGEFILE | O_RDWR;
    const char *path = NVreg_TemporaryFilePath;

    if (!path)
    {
#if defined(mk_vma_flags)
#define NV_VMA_NORESERVE mk_vma_flags(VMA_NORESERVE_BIT)
#else
#define NV_VMA_NORESERVE VM_NORESERVE
#endif

#if NV_IS_EXPORT_SYMBOL_PRESENT_shmem_kernel_file_setup
        file = shmem_kernel_file_setup("nvidia-tmp", 0, NV_VMA_NORESERVE);
#else
        file = shmem_file_setup("nvidia-tmp", 0, NV_VMA_NORESERVE);
#endif
        if (!IS_ERR(file))
        {
                file->f_flags |= O_LARGEFILE;
        }
    }

    if (path)
    {
        /*
         * The filp_open() call below depends on the current task's fs_struct
         * (current->fs), which may already be NULL if this is called during
         * process teardown.
         */
        if (current->fs == NULL)
        {
            return NV_ERR_OPERATING_SYSTEM;
        }

        file = filp_open(path, flags, 0);
        if (IS_ERR(file) && path != default_path)
        {
            nv_printf(NV_DBG_ERRORS,
                      "NVRM: The temporary file path specified via the NVreg_TemporaryFilePath\n"
                      "NVRM: module parameter could not be opened (error %ld).\n",
                      PTR_ERR(file));
        }
    }
#endif

    if (IS_ERR(file))
    {
        nv_printf(NV_DBG_INFO,
                  "NVRM: os_allocate_temporary_file failed: %ld\n",
                  PTR_ERR(file));
        return NV_ERR_OPERATING_SYSTEM;
    }

#if NV_FILESYSTEM_ACCESS_AVAILABLE
    if (size > 0)
    {
        int fallocate_ret = vfs_fallocate(file, 0, 0, (loff_t)size);
        if (fallocate_ret < 0)
        {
            filp_close(file, NULL);
            if (fallocate_ret == -EOPNOTSUPP)
            {
                return NV_ERR_NOT_SUPPORTED;
            }
            return NV_ERR_INSUFFICIENT_RESOURCES;
        }
    }
#endif

    *ppFile = (void *)file;

    return NV_OK;
}

void NV_API_CALL os_close_file
(
    void *pFile
)
{
#if NV_FILESYSTEM_ACCESS_AVAILABLE
    filp_close(pFile, NULL);
#endif
}

#define NV_MAX_NUM_FILE_IO_RETRIES 10

NV_STATUS NV_API_CALL os_write_file
(
    void *pFile,
    NvU8 *pBuffer,
    NvU64 size,
    NvU64 offset
)
{
#if NV_FILESYSTEM_ACCESS_AVAILABLE
    loff_t f_pos = offset;
    ssize_t num_written;
    int num_retries = NV_MAX_NUM_FILE_IO_RETRIES;

retry:
    num_written = kernel_write(pFile, pBuffer, size, &f_pos);
    if (num_written < 0)
    {
        return NV_ERR_OPERATING_SYSTEM;
    }
    else if (num_written < size)
    {
        if (num_written > 0)
        {
            pBuffer += num_written;
            size -= num_written;
        }
        if (--num_retries > 0)
        {
            cond_resched();
            goto retry;
        }
        return NV_ERR_OPERATING_SYSTEM;
    }

    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif
}

NV_STATUS NV_API_CALL os_read_file
(
    void *pFile,
    NvU8 *pBuffer,
    NvU64 size,
    NvU64 offset
)
{
#if NV_FILESYSTEM_ACCESS_AVAILABLE
    loff_t f_pos = offset;
    ssize_t num_read;
    int num_retries = NV_MAX_NUM_FILE_IO_RETRIES;

retry:
    num_read = kernel_read(pFile, pBuffer, size, &f_pos);
    if (num_read < 0)
    {
        return NV_ERR_OPERATING_SYSTEM;
    }
    else if (num_read < size)
    {
        if (num_read > 0)
        {
            pBuffer += num_read;
            size -= num_read;
        }
        if (--num_retries > 0)
        {
            cond_resched();
            goto retry;
        }
        return NV_ERR_OPERATING_SYSTEM;
    }

    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif
}

NV_STATUS NV_API_CALL os_open_readonly_file
(
    const char  *filename,
    void       **ppFile
)
{
#if NV_FILESYSTEM_ACCESS_AVAILABLE
    struct file *file;

    /*
     * The filp_open() call below depends on the current task's fs_struct
     * (current->fs), which may already be NULL if this is called during
     * process teardown.
     */
    if (current->fs == NULL)
    {
        return NV_ERR_OPERATING_SYSTEM;
    }

    file = filp_open(filename, O_RDONLY, 0);
    if (IS_ERR(file))
    {
        return NV_ERR_OPERATING_SYSTEM;
    }

    *ppFile = (void *)file;

    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif
}

NV_STATUS NV_API_CALL os_open_and_read_file
(
    const char *filename,
    NvU8       *buf,
    NvU64       count
)
{
    void *fileHandle;
    NV_STATUS status;

    status = os_open_readonly_file(filename, &fileHandle);
    if (status != NV_OK)
    {
        return status;
    }

    status = os_read_file(fileHandle, buf, count, 0);

    os_close_file(fileHandle);

    return status;
}

NvBool NV_API_CALL os_is_nvswitch_present(void)
{
    struct pci_device_id nvswitch_pci_table[] = {
        {
            PCI_DEVICE(PCI_VENDOR_ID_NVIDIA, PCI_ANY_ID),
            .class      = PCI_CLASS_BRIDGE_OTHER << 8,
            .class_mask = PCI_ANY_ID
        },
        {0}
    };

    return !!pci_dev_present(nvswitch_pci_table);
}

/*
 * This function may sleep (interruptible).
 */
NV_STATUS NV_API_CALL os_get_random_bytes
(
    NvU8 *bytes,
    NvU16 numBytes
)
{
    if (wait_for_random_bytes() < 0)
        return NV_ERR_NOT_READY;

    get_random_bytes(bytes, numBytes);
    return NV_OK;
}

NvU32 NV_API_CALL os_get_current_process_flags
(
    void
)
{
    NvU32 flags = OS_CURRENT_PROCESS_FLAG_NONE;

    if (current->flags & PF_EXITING)
        flags |= OS_CURRENT_PROCESS_FLAG_EXITING;

    if (current->flags & PF_KTHREAD)
        flags |= OS_CURRENT_PROCESS_FLAG_KERNEL_THREAD;

    return flags;
}

NV_STATUS NV_API_CALL os_alloc_wait_queue
(
    os_wait_queue **wq
)
{
    NV_KMALLOC(*wq, sizeof(os_wait_queue));
    if (*wq == NULL)
        return NV_ERR_NO_MEMORY;

    init_completion(&(*wq)->q);

    return NV_OK;
}

void NV_API_CALL os_free_wait_queue
(
    os_wait_queue *wq
)
{
    NV_KFREE(wq, sizeof(os_wait_queue));
}

void NV_API_CALL os_wait_uninterruptible
(
    os_wait_queue *wq
)
{
    wait_for_completion(&wq->q);
}

void NV_API_CALL os_wait_interruptible
(
    os_wait_queue *wq
)
{
    wait_for_completion_interruptible(&wq->q);
}

void NV_API_CALL os_wake_up
(
    os_wait_queue *wq
)
{
    complete_all(&wq->q);
}

static bool os_platform_is_fpga(void)
{
    const struct soc_device_attribute soc_attrs[] = {
        { .revision = "*FPGA" },
        {/* sentinel */}
    };

    if (soc_device_match(soc_attrs)) {
        return true;
    }

    return false;
}

static bool os_platform_is_vdk(void)
{
    const struct soc_device_attribute soc_attrs[] = {
        { .revision = "VDK" },
        {/* sentinel */}
    };

    if (soc_device_match(soc_attrs)) {
        return true;
    }

    return false;
}

    NV_STATUS NV_API_CALL os_get_tegra_platform
(
    NvU32 *mode
)
{
#if NV_SUPPORTS_PLATFORM_DISPLAY_DEVICE
    if (os_platform_is_fpga())
    {
        *mode = NV_OS_TEGRA_PLATFORM_FPGA;
    }
    else if (os_platform_is_vdk())
    {
        *mode = NV_OS_TEGRA_PLATFORM_SIM;
    }
    else
    {
        *mode = NV_OS_TEGRA_PLATFORM_SILICON;
    }

    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif
}

nv_cap_t* NV_API_CALL os_nv_cap_init
(
    const char *path
)
{
    return nv_cap_init(path);
}

nv_cap_t* NV_API_CALL os_nv_cap_create_dir_entry
(
    nv_cap_t *parent_cap,
    const char *name,
    int mode
)
{
    return nv_cap_create_dir_entry(parent_cap, name, mode);
}

nv_cap_t* NV_API_CALL os_nv_cap_create_file_entry
(
    nv_cap_t *parent_cap,
    const char *name,
    int mode
)
{
    return nv_cap_create_file_entry(parent_cap, name, mode);
}

void NV_API_CALL os_nv_cap_destroy_entry
(
    nv_cap_t *cap
)
{
    nv_cap_destroy_entry(cap);
}

int NV_API_CALL os_nv_cap_validate_and_dup_fd
(
    const nv_cap_t *cap,
    int fd
)
{
    return nv_cap_validate_and_dup_fd(cap, fd);
}

void NV_API_CALL os_nv_cap_close_fd
(
    int fd
)
{
    nv_cap_close_fd(fd);
}

NvS32 NV_API_CALL os_imex_channel_count
(
    void
)
{
    return nv_caps_imex_channel_count();
}

NvS32 NV_API_CALL os_imex_channel_get
(
    NvU64 descriptor
)
{
    return nv_caps_imex_channel_get((int)descriptor);
}

NV_STATUS NV_API_CALL os_tegra_igpu_perf_boost
(
    void *handle,
    NvBool enable,
    NvU32 duration,
    int boost_type
)
{
#if defined(CONFIG_PM_DEVFREQ) && defined(NV_UPDATE_DEVFREQ_PRESENT)
    nv_state_t *nv = handle;
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    int (*enable_devfreq_boost_cb)(struct device *dev, unsigned int duration,
                                   int boost_type);
    int (*disable_devfreq_boost_cb)(struct device *dev);
    int err;

    if (enable)
    {
        enable_devfreq_boost_cb = READ_ONCE(nvl->enable_devfreq_boost_cb);
        if (enable_devfreq_boost_cb == NULL)
        {
            return NV_ERR_NOT_SUPPORTED;
        }

        err = enable_devfreq_boost_cb(nvl->dev, duration, boost_type);
        if (err != 0)
        {
            return NV_ERR_OPERATING_SYSTEM;
        }
    }
    else
    {
        disable_devfreq_boost_cb = READ_ONCE(nvl->disable_devfreq_boost_cb);
        if (disable_devfreq_boost_cb == NULL)
        {
            return NV_ERR_NOT_SUPPORTED;
        }

        err = disable_devfreq_boost_cb(nvl->dev);
        if (err != 0)
        {
            return NV_ERR_OPERATING_SYSTEM;
        }
    }

    return NV_OK;
#else // !defined(CONFIG_PM_DEVFREQ) || !defined(NV_UPDATE_DEVFREQ_PRESENT)
    return NV_ERR_NOT_SUPPORTED;
#endif
}

NvU64 NV_API_CALL os_get_reclaimable_memory_usage(void)
{
    return nv_get_reclaimable_memory_usage();
}

/*
 * Reads the total memory and free memory of a NUMA node from the kernel.
 */
NV_STATUS NV_API_CALL os_get_numa_node_memory_usage
(
    NvS32 node_id,
    NvU64 *free_memory_bytes,
    NvU64 *total_memory_bytes
)
{
    struct pglist_data *pgdat;
    struct zone *zone;
    NvU32 zone_id;

    if (node_id >= MAX_NUMNODES)
    {
        nv_printf(NV_DBG_ERRORS, "Invalid NUMA node ID\n");
        return NV_ERR_INVALID_ARGUMENT;
    }

    pgdat = NODE_DATA(node_id);

    *free_memory_bytes = 0;
    *total_memory_bytes = 0;

    for (zone_id = 0; zone_id < MAX_NR_ZONES; zone_id++)
    {
        zone = &(pgdat->node_zones[zone_id]);
        if (!populated_zone(zone))
            continue;
        *free_memory_bytes += (zone_page_state_snapshot(zone, NR_FREE_PAGES) * PAGE_SIZE);
        *total_memory_bytes += (zone->present_pages * PAGE_SIZE);
    }

    return NV_OK;
}

typedef struct os_numa_gpu_mem_hotplug_notifier_s
{
    NvU64 start_pa;
    NvU64 size;
    nv_pci_info_t pci_info;
    struct notifier_block memory_notifier;
} os_numa_gpu_mem_hotplug_notifier_t;

static int os_numa_verify_gpu_memory_zone(struct notifier_block *nb,
                                          unsigned long action, void *data)
{
    os_numa_gpu_mem_hotplug_notifier_t *notifier = container_of(nb,
        os_numa_gpu_mem_hotplug_notifier_t,
        memory_notifier);
    struct memory_notify *mhp = data;
    NvU64 start_pa = PFN_PHYS(mhp->start_pfn);
    NvU64 size = PFN_PHYS(mhp->nr_pages);

    if (action == MEM_GOING_ONLINE)
    {
        // Check if onlining memory falls in the GPU memory range
        if ((start_pa >= notifier->start_pa) &&
            (start_pa + size) <= (notifier->start_pa + notifier->size))
        {
            /*
             * Verify GPU memory NUMA node has memory only in ZONE_MOVABLE before
             * onlining the memory so that incorrect auto online setting doesn't
             * cause the memory onlined in a zone where kernel allocations
             * could happen, resulting in GPU memory hot unpluggable and requiring
             * system reboot.
             */
            if (page_zonenum((pfn_to_page(mhp->start_pfn))) != ZONE_MOVABLE)
            {
                nv_printf(NV_DBG_ERRORS, "NVRM: Failing GPU memory onlining as the onlining zone "
                          "is not movable. pa: 0x%llx size: 0x%llx\n"
                          "NVRM: The NVIDIA GPU %04x:%02x:%02x.%x installed in the system\n"
                          "NVRM: requires auto onlining mode online_movable enabled in\n"
                          "NVRM: /sys/devices/system/memory/auto_online_blocks\n",
                          start_pa, size, notifier->pci_info.domain, notifier->pci_info.bus,
                          notifier->pci_info.slot, notifier->pci_info.function);
                return NOTIFY_BAD;
            }
        }
    }
    return NOTIFY_OK;
}

#define ADD_REMOVE_GPU_MEMORY_NUM_SEGMENTS 128

NV_STATUS NV_API_CALL os_numa_add_gpu_memory
(
    void *handle,
    NvU64 offset,
    NvU64 size,
    NvU32 *nodeId
)
{
#if defined(NV_ADD_MEMORY_DRIVER_MANAGED_PRESENT)
    int node = 0;
    nv_linux_state_t *nvl = pci_get_drvdata(handle);
    nv_state_t *nv = NV_STATE_PTR(nvl);
    NvU64 base = offset + nvl->coherent_link_info.gpu_mem_pa;
    int ret = 0;
    NvU64 memblock_size;
    NvU64 size_remaining;
    NvU64 calculated_segment_size;
    NvU64 segment_size;
    NvU64 segment_base;
    os_numa_gpu_mem_hotplug_notifier_t notifier =
    {
        .start_pa = base,
        .size = size,
        .pci_info = nv->pci_info,
        .memory_notifier.notifier_call = os_numa_verify_gpu_memory_zone,
    };

    if (nodeId == NULL)
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    if (bitmap_empty(nvl->coherent_link_info.free_node_bitmap, MAX_NUMNODES))
    {
        return NV_ERR_IN_USE;
    }
    node = find_first_bit(nvl->coherent_link_info.free_node_bitmap, MAX_NUMNODES);
    if (node == MAX_NUMNODES)
    {
        return NV_ERR_INVALID_STATE;
    }

    NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_ONLINE_IN_PROGRESS);

    ret = register_memory_notifier(&notifier.memory_notifier);
    if (ret)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: Memory hotplug notifier registration failed\n");
        goto failed;
    }

    //
    // Adding all memory at once can take a long time. Split up memory into segments
    // with schedule() in between to prevent soft lockups. Memory segments for
    // add_memory_driver_managed() need to be aligned to memblock size.
    //
    // If there are any issues splitting into segments, then add all memory at once.
    //
    if (os_numa_memblock_size(&memblock_size) == NV_OK)
    {
        calculated_segment_size = NV_ALIGN_UP(size / ADD_REMOVE_GPU_MEMORY_NUM_SEGMENTS, memblock_size);
    }
    else
    {
        // Don't split into segments, add all memory at once
        calculated_segment_size = size;
    }

    segment_size = calculated_segment_size;
    segment_base = base;
    size_remaining = size;

    while ((size_remaining > 0) &&
           (ret == 0))
    {
        if (segment_size > size_remaining)
        {
            segment_size = size_remaining;
        }

#ifdef NV_ADD_MEMORY_DRIVER_MANAGED_HAS_MHP_FLAGS_ARG
        ret = add_memory_driver_managed(node, segment_base, segment_size, "System RAM (NVIDIA)", MHP_NONE);
#else
        ret = add_memory_driver_managed(node, segment_base, segment_size, "System RAM (NVIDIA)");
#endif
        nv_printf(NV_DBG_SETUP, "NVRM: add_memory_driver_managed() returns: %d for segment_base: 0x%llx, segment_size: 0x%llx\n",
                  ret, segment_base, segment_size);

        segment_base += segment_size;
        size_remaining -= segment_size;

        // Yield CPU to prevent soft lockups
        schedule();
    }
    unregister_memory_notifier(&notifier.memory_notifier);

    if (ret == 0)
    {
        struct zone *zone = &NODE_DATA(node)->node_zones[ZONE_MOVABLE];
        NvU64 start_pfn = base >> PAGE_SHIFT;
        NvU64 end_pfn = (base + size) >> PAGE_SHIFT;

        /* Verify the full GPU memory range passed on is onlined */
        if (zone->zone_start_pfn != start_pfn ||
            zone_end_pfn(zone) != end_pfn)
        {
            nv_printf(NV_DBG_ERRORS, "NVRM: GPU memory zone movable auto onlining failed!\n");

#ifdef NV_OFFLINE_AND_REMOVE_MEMORY_PRESENT
            // Since zone movable auto onlining failed, need to remove the added memory.
            segment_size = calculated_segment_size;
            segment_base = base;
            size_remaining = size;

            while (size_remaining > 0)
            {
                if (segment_size > size_remaining)
                {
                    segment_size = size_remaining;
                }

#ifdef NV_REMOVE_MEMORY_HAS_NID_ARG
                ret = offline_and_remove_memory(node, segment_base, segment_size);
#else
                ret = offline_and_remove_memory(segment_base, segment_size);
#endif
                nv_printf(NV_DBG_SETUP, "NVRM: offline_and_remove_memory() returns: %d for segment_base: 0x%llx, segment_size: 0x%llx\n",
                          ret, segment_base, segment_size);

                segment_base += segment_size;
                size_remaining -= segment_size;

                // Yield CPU to prevent soft lockups
                schedule();
            }
#endif
            goto failed;
        }

        /*
         * On systems with cpuset cgroup controller enabled, memory alloc on
         * this just hotplugged GPU memory node can fail if the
         * cpuset_hotplug_work is not scheduled yet. cpuset_hotplug_work is
         * where the current->mems_allowed is updated in the path
         * cpuset_hotplug_workfn->update_tasks_nodemask. When cpuset is
         * enabled and current->mems_allowed is not updated, memory allocation
         * with __GFP_THISNODE and this node id fails. cpuset_wait_for_hotplug
         * kernel function can be used to wait for the work to finish but that
         * is not exported. Adding a time loop to wait for
         * current->mems_allowed to be updated as a WAR while an upstream
         * kernel fix is being explored. Bug 4385903
         */
        if (!node_isset(node, cpuset_current_mems_allowed))
        {
            unsigned long delay;

            delay = jiffies + (HZ / 10); // 100ms
            while(time_before(jiffies, delay) &&
                  !node_isset(node, cpuset_current_mems_allowed))
            {
                os_schedule();
            }

            if (!node_isset(node, cpuset_current_mems_allowed))
            {
                nv_printf(NV_DBG_ERRORS, "NVRM: Hotplugged GPU memory NUMA node: %d "
                          "not set in current->mems_allowed!\n", node);
            }
        }

        *nodeId = node;
        clear_bit(node, nvl->coherent_link_info.free_node_bitmap);
        NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_ONLINE);
        return NV_OK;
    }
    nv_printf(NV_DBG_ERRORS, "NVRM: Memory add failed. base: 0x%lx size: 0x%lx ret: %d\n",
              base, size, ret);
failed:
    NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_ONLINE_FAILED);
    return NV_ERR_OPERATING_SYSTEM;
#endif
    return NV_ERR_NOT_SUPPORTED;
}


typedef struct {
    NvU64 base;
    NvU64 size;
    NvU32 nodeId;
    int ret;
} remove_numa_memory_info_t;

static void offline_numa_memory_callback
(
    void *args
)
{
#ifdef NV_OFFLINE_AND_REMOVE_MEMORY_PRESENT
    remove_numa_memory_info_t *pNumaInfo = (remove_numa_memory_info_t *)args;
    int ret = 0;
    NvU64 memblock_size;
    NvU64 size_remaining;
    NvU64 calculated_segment_size;
    NvU64 segment_size;
    NvU64 segment_base;

    //
    // Removing all memory at once can take a long time. Split up memory into segments
    // with schedule() in between to prevent soft lockups. Memory segments for
    // offline_and_remove_memory() need to be aligned to memblock size.
    //
    // If there are any issues splitting into segments, then remove all memory at once.
    //
    if (os_numa_memblock_size(&memblock_size) == NV_OK)
    {
        calculated_segment_size = NV_ALIGN_UP(pNumaInfo->size / ADD_REMOVE_GPU_MEMORY_NUM_SEGMENTS, memblock_size);
    }
    else
    {
        // Don't split into segments, remove all memory at once
        calculated_segment_size = pNumaInfo->size;
    }

    segment_size = calculated_segment_size;
    segment_base = pNumaInfo->base;
    size_remaining = pNumaInfo->size;

    while (size_remaining > 0)
    {
        if (segment_size > size_remaining)
        {
            segment_size = size_remaining;
        }

#ifdef NV_REMOVE_MEMORY_HAS_NID_ARG
        ret = offline_and_remove_memory(pNumaInfo->nodeId,
                                        segment_base,
                                        segment_size);
#else
        ret = offline_and_remove_memory(segment_base,
                                        segment_size);
#endif
        nv_printf(NV_DBG_SETUP, "NVRM: offline_and_remove_memory() returns: %d for segment_base: 0x%llx, segment_size: 0x%llx\n",
                  ret, segment_base, segment_size);
        pNumaInfo->ret |= ret;

        segment_base += segment_size;
        size_remaining -= segment_size;

        // Yield CPU to prevent soft lockups
        schedule();
    }
#endif
}

NV_STATUS NV_API_CALL os_numa_remove_gpu_memory
(
    void *handle,
    NvU64 offset,
    NvU64 size,
    NvU32 nodeId
)
{
#ifdef NV_ADD_MEMORY_DRIVER_MANAGED_PRESENT
    nv_linux_state_t *nvl = pci_get_drvdata(handle);
#ifdef NV_OFFLINE_AND_REMOVE_MEMORY_PRESENT
    NvU64 base = offset + nvl->coherent_link_info.gpu_mem_pa;
    remove_numa_memory_info_t numa_info;
    nv_kthread_q_item_t remove_numa_memory_q_item;
    int ret;
#endif

    if (nodeId >= MAX_NUMNODES)
    {
        return NV_ERR_INVALID_ARGUMENT;
    }
    if ((nodeId == NUMA_NO_NODE) || test_bit(nodeId, nvl->coherent_link_info.free_node_bitmap))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_OFFLINE_IN_PROGRESS);

#ifdef NV_OFFLINE_AND_REMOVE_MEMORY_PRESENT
    numa_info.base   = base;
    numa_info.size   = size;
    numa_info.nodeId = nodeId;
    numa_info.ret    = 0;

    if (unlikely(nvl->remove_numa_memory_q.q_kthread == NULL))
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: NUMA memory remove queue is not initialized. base: 0x%lx size: 0x%lx\n",
                  base, size);
        NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_OFFLINE_FAILED);
        return NV_ERR_INVALID_STATE;
    }

    nv_kthread_q_item_init(&remove_numa_memory_q_item,
                           offline_numa_memory_callback,
                           &numa_info);
    nv_kthread_q_schedule_q_item(&nvl->remove_numa_memory_q,
                                 &remove_numa_memory_q_item);
    nv_kthread_q_flush(&nvl->remove_numa_memory_q);

    ret = numa_info.ret;

    if (ret == 0)
    {
        set_bit(nodeId, nvl->coherent_link_info.free_node_bitmap);

        NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_OFFLINE);
        return NV_OK;
    }

    nv_printf(NV_DBG_ERRORS, "NVRM: Memory remove failed. base: 0x%lx size: 0x%lx ret: %d\n",
              base, size, ret);
#endif
    NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_OFFLINE_FAILED);
    return NV_ERR_OPERATING_SYSTEM;
#endif
    return NV_ERR_NOT_SUPPORTED;
}

NV_STATUS NV_API_CALL os_offline_page_at_address
(
    NvU64 address
)
{
#if defined(CONFIG_MEMORY_FAILURE)
    int flags = 0;
    NvU64 pfn;
    struct page *page = NV_GET_PAGE_STRUCT(address);

    if (page == NULL)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: Failed to get page struct for address: 0x%llx\n",
                  address);
        return NV_ERR_INVALID_ARGUMENT;
    }

    pfn = page_to_pfn(page);

#ifdef NV_MEMORY_FAILURE_MF_SW_SIMULATED_DEFINED
    //
    // Set MF_SW_SIMULATED flag so Linux kernel can differentiate this from a HW
    // memory failure. HW memory failures cannot be unset via unpoison_memory() API.
    //
    // Currently, RM does not use unpoison_memory(), so it makes no difference
    // whether or not MF_SW_SIMULATED is set. Regardless, it is semantically more
    // correct to set MF_SW_SIMULATED.
    //
    flags |= MF_SW_SIMULATED;
#endif

    nv_printf(NV_DBG_INFO, "NVRM: offlining page at address: 0x%llx pfn: 0x%llx\n",
              address, pfn);

#ifdef NV_MEMORY_FAILURE_QUEUE_HAS_TRAPNO_ARG
    memory_failure_queue(pfn, 0, flags);
#else
    memory_failure_queue(pfn, flags);
#endif

    return NV_OK;
#else // !defined(CONFIG_MEMORY_FAILURE)
    nv_printf(NV_DBG_ERRORS, "NVRM: memory_failure_queue() not supported by kernel. page offlining failed. address: 0x%llx\n",
              address);
    return NV_ERR_NOT_SUPPORTED;
#endif
}

void* NV_API_CALL os_get_pid_info(void)
{
#if defined(NV_HAS_ENUM_PIDTYPE_TGID)
    return get_task_pid(current, PIDTYPE_TGID);
#else
    return get_task_pid(current->group_leader, PIDTYPE_PID);
#endif
}

void NV_API_CALL os_put_pid_info(void *pid_info)
{
    if (pid_info != NULL)
        put_pid(pid_info);
}

NV_STATUS NV_API_CALL os_find_ns_pid(void *pid_info, NvU32 *ns_pid)
{
    if ((pid_info == NULL) || (ns_pid == NULL))
        return NV_ERR_INVALID_ARGUMENT;

    *ns_pid = pid_vnr((struct pid *)pid_info);

    // The call returns 0 if the PID is not found in the current ns
    if (*ns_pid == 0)
        return NV_ERR_OBJECT_NOT_FOUND;

    return NV_OK;
}

NvBool NV_API_CALL os_is_init_ns(void)
{
    return (task_active_pid_ns(current) == &init_pid_ns);
}

NV_STATUS NV_API_CALL os_device_vm_present(void)
{
#if defined(NV_DEVICE_VM_BUILD)
    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif
}

//
// Realm device-attestation (DA) object fetch over the RSI/RHI host-call ABI.
//
// On an Arm CCA realm guest the host caches per-device attestation objects
// (certificate, measurements, ...). RM reads one back the same way the
// CCA-guest driver's rhi_read_cached_object() does: a size query followed by a
// read into host-shared memory. The transport is the mainline SMCCC helper
// arm_smccc_1_1_invoke(); the shared buffer uses set_memory_decrypted().
//
// The RSI/RHI identifiers below are the fixed hypervisor ABI. They are defined
// locally rather than pulled from the downstream <asm/rhi.h> /
// <linux/arm-smccc-rsi.h> (absent on most kernels) so RM stays portable.
//
#if defined(NVCPU_AARCH64) && NV_HAVE_MEMORY_ENCRYPT_DECRYPT

//
// Guest -> RMM transport call. The RHI DA selector is placed in gprs[0]; the
// RMM relays the block to the host as a host call.
// Documentation of the host call can be found at:
// https://support.arm.com/documentation/den0137/2-0bet2-1/?lang=en
//
#define NV_SMC_RSI_HOST_CALL                                            \
    ARM_SMCCC_CALL_VAL(ARM_SMCCC_FAST_CALL, ARM_SMCCC_SMC_64,           \
                       ARM_SMCCC_OWNER_STANDARD, 0x199)

//
// RHI DA function selectors (host-serviced), placed in gprs[0]. These use the
// Standard-Hyp owner range.
//
#define NV_SMC_RHI_CALL(n)                                              \
    ARM_SMCCC_CALL_VAL(ARM_SMCCC_FAST_CALL, ARM_SMCCC_SMC_64,           \
                       ARM_SMCCC_OWNER_STANDARD_HYP, (n))
#define NV_RHI_DA_OBJECT_SIZE           NV_SMC_RHI_CALL(0x4C)
#define NV_RHI_DA_OBJECT_READ           NV_SMC_RHI_CALL(0x4D)

#define NV_RHI_DA_OBJECT_CERTIFICATE    0x1

#define NV_RSI_SUCCESS                  0x0
#define NV_RHI_DA_SUCCESS               0x0

// Host-side cap on a cached DA object (SZ_16M).
#define NV_RHI_DA_MAX_OBJECT_SIZE       (16 * 1024 * 1024)

//
// Mirror of the RSI host-call block. It is handed to the RMM by physical
// address, so it must live in the kernel linear map (kmalloc, never a
// VMAP_STACK local) for virt_to_phys() to be valid. 256-byte aligned per ABI.
//
struct nv_rsi_host_call
{
    union
    {
        NvU16 imm;
        NvU64 padding0;
    };
    NvU64 gprs[31];
} __aligned(0x100);

static NV_STATUS _nv_rhi_host_call(struct nv_rsi_host_call *pCall)
{
    struct arm_smccc_res res;

    arm_smccc_1_1_invoke(NV_SMC_RSI_HOST_CALL, virt_to_phys(pCall), &res);

    if (res.a0 != NV_RSI_SUCCESS)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: %s: RSI host call failed (0x%lx)\n",
                  __FUNCTION__, res.a0);
        return NV_ERR_GENERIC;
    }
    if (pCall->gprs[0] != NV_RHI_DA_SUCCESS)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: %s: RHI DA call failed (0x%llx)\n",
                  __FUNCTION__, pCall->gprs[0]);
        return NV_ERR_GENERIC;
    }
    return NV_OK;
}

//
// Linux uses the device requester id as the vdev id:
//   (PCI segment << 16) | (bus << 8) | devfn
//
static NvU32 _nv_rhi_vdev_id(struct pci_dev *pdev)
{
    return (pci_domain_nr(pdev->bus) << 16) |
           (pdev->bus->number << 8) |
           pdev->devfn;
}

static NV_STATUS _nv_rhi_read_cached_object(struct pci_dev *pdev,
                                            NvU32           objectType,
                                            NvU8           *pBuffer,
                                            NvU32          *pBufferSize)
{
    NV_STATUS                status;
    struct nv_rsi_host_call *pCall;
    struct page             *pShared;
    void                    *pSharedBuf;
    NvU32                    vdevId    = _nv_rhi_vdev_id(pdev);
    NvU32                    capacity  = *pBufferSize;
    NvU32                    objectSize;
    int                      order;

    pCall = kmalloc(sizeof(*pCall), GFP_KERNEL);
    if (pCall == NULL)
    {
        return NV_ERR_NO_MEMORY;
    }

    // Step 1: query the object size.
    memset(pCall, 0, sizeof(*pCall));
    pCall->gprs[0] = NV_RHI_DA_OBJECT_SIZE;
    pCall->gprs[1] = vdevId;
    pCall->gprs[2] = objectType;

    status = _nv_rhi_host_call(pCall);
    if (status != NV_OK)
    {
        goto free_call;
    }

    if ((pCall->gprs[1] == 0) || (pCall->gprs[1] > NV_RHI_DA_MAX_OBJECT_SIZE))
    {
        status = NV_ERR_INVALID_DATA;
        goto free_call;
    }

    objectSize = (NvU32)pCall->gprs[1];

    // Report the required size whether or not it fits the caller's buffer.
    *pBufferSize = objectSize;
    if (objectSize > capacity)
    {
        status = NV_ERR_BUFFER_TOO_SMALL;
        goto free_call;
    }

    // Allocate a host-shared buffer for the host to write the object into.
    order = get_order(objectSize);
    pShared = alloc_pages(GFP_KERNEL | __GFP_ZERO, order);
    if (pShared == NULL)
    {
        status = NV_ERR_NO_MEMORY;
        goto free_call;
    }
    pSharedBuf = page_address(pShared);

    if (set_memory_decrypted((unsigned long)pSharedBuf, 1 << order) != 0)
    {
        //
        // On failure the page state is indeterminate and unsafe to free back
        // to the encrypted pool, so leak it (set_memory_decrypted has WARNed).
        //
        status = NV_ERR_OPERATING_SYSTEM;
        goto free_call;
    }

    // Step 2: read the object into the shared buffer.
    memset(pCall, 0, sizeof(*pCall));
    pCall->gprs[0] = NV_RHI_DA_OBJECT_READ;
    pCall->gprs[1] = vdevId;
    pCall->gprs[2] = objectType;
    pCall->gprs[3] = virt_to_phys(pSharedBuf);
    pCall->gprs[4] = objectSize;
    pCall->gprs[5] = 0; // offset to read from

    status = _nv_rhi_host_call(pCall);
    if (status != NV_OK)
    {
        goto free_shared;
    }

    if ((NvU32)pCall->gprs[1] != objectSize)
    {
        // Short read.
        status = NV_ERR_INVALID_DATA;
        goto free_shared;
    }

    memcpy(pBuffer, pSharedBuf, objectSize);
    status = NV_OK;

free_shared:
    if (set_memory_encrypted((unsigned long)pSharedBuf, 1 << order) == 0)
    {
        __free_pages(pShared, order);
    }
free_call:
    kfree(pCall);
    return status;
}

//
// RSI selector serviced by the RMM itself rather than relayed to the host.
// The RMM is the trusted bridge, so its view of the device certificate is the
// authority on which GPU the guest is really bound to; the chain fetched over
// RHI comes from the untrusted host and can be swapped for another GPU's.
//
#define NV_SMC_RSI_VDEV_GET_INFO                                        \
    ARM_SMCCC_CALL_VAL(ARM_SMCCC_FAST_CALL, ARM_SMCCC_SMC_64,           \
                       ARM_SMCCC_OWNER_STANDARD, 0x19D)

// Digest algorithm as encoded by RSI, reported in hashAlgo below.
#define NV_RSI_HASH_SHA_256             0x0
#define NV_RSI_HASH_SHA_512             0x1
#define NV_RSI_HASH_SHA_384             0x2

#define NV_RSI_SHA_256_DIGEST_SIZE      32
#define NV_RSI_SHA_512_DIGEST_SIZE      64
#define NV_RSI_SHA_384_DIGEST_SIZE      48

//
// Mirror of the RMM's vdevice info block. Only hashAlgo and identityDigest are
// consumed, but every preceding field is load-bearing for the offsets that
// follow it, so the layout is reproduced whole. The u8 fields genuinely occupy
// 8-byte slots.
// Source: https://support.arm.com/documentation/den0137/2-0bet3/?lang=en
// See the RmmVdev type at C2.78
//
struct nv_rsi_vdevice_info
{
    NvU64 flags;
    NvU64 idIndex;
    union
    {
        NvU8  hashAlgo;
        NvU64 padding0;
    };
    NvU64 lockNonce;
    NvU64 measNonce;
    NvU64 reportNonce;
    union
    {
        NvU8  formatType;
        NvU64 padding1;
    };
    NvU64 formatVersion;
    union
    {
        NvU8  state;
        NvU64 padding2;
    };
    NvU8  reserved0[0x80 - 0x48];
    NvU8  protocolDataDigest[64];
    NvU8  identityDigest[64];
    NvU8  pubkeyDigest[64];
    NvU8  measDigest[64];
    NvU8  reportDigest[64];
    NvU64 vsmmuAddr;
    NvU64 vsmuVsid;
    NvU8  reserved1[0x200 - 0x1D0];
};

static NV_STATUS _nv_rsi_vdev_get_info(struct pci_dev             *pdev,
                                       struct nv_rsi_vdevice_info *pInfo)
{
    struct arm_smccc_res res = {0};

    BUILD_BUG_ON(sizeof(struct nv_rsi_vdevice_info) != 0x200);
    BUILD_BUG_ON(offsetof(struct nv_rsi_vdevice_info, hashAlgo) != 0x10);
    BUILD_BUG_ON(offsetof(struct nv_rsi_vdevice_info, identityDigest) != 0xC0);

    arm_smccc_1_1_invoke(NV_SMC_RSI_VDEV_GET_INFO,
                         _nv_rhi_vdev_id(pdev), virt_to_phys(pInfo), &res);

    if (res.a0 != NV_RSI_SUCCESS)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: %s: RSI VDEV_GET_INFO failed (0x%lx)\n",
                  __FUNCTION__, res.a0);
        return NV_ERR_GENERIC;
    }
    return NV_OK;
}

// Without the kernel crypto API this check cannot run, and a check that cannot
// run must fail.
static NV_STATUS _nv_hash_buffer(const char *pAlgName,
                                 const void *pData,
                                 NvU32       dataSize,
                                 NvU8       *pHash)
{
#if defined(NV_USE_KERNEL_CRYPTO_HASH)
    struct crypto_shash *pAlg;
    int                  ret;

    pAlg = crypto_alloc_shash(pAlgName, 0, 0);
    if (IS_ERR(pAlg))
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: %s: crypto_alloc_shash(%s) failed (%ld)\n",
                  __FUNCTION__, pAlgName, PTR_ERR(pAlg));
        return NV_ERR_NOT_SUPPORTED;
    }

    ret = crypto_shash_tfm_digest(pAlg, pData, dataSize, pHash);
    crypto_free_shash(pAlg);

    if (ret != 0)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: %s: %s digest failed (%d)\n",
                  __FUNCTION__, pAlgName, ret);
        return NV_ERR_GENERIC;
    }
    return NV_OK;
#else
    nv_printf(NV_DBG_ERRORS,
              "NVRM: %s: kernel crypto API unavailable, cannot hash with %s\n",
              __FUNCTION__, pAlgName);
    return NV_ERR_NOT_SUPPORTED;
#endif // NV_USE_KERNEL_CRYPTO_HASH
}

NV_STATUS NV_API_CALL os_read_device_cert_digests(void       *nv_state,
                                                  const NvU8 *pCertChain,
                                                  NvU32       certChainSize,
                                                  NvU8       *pTsmDigest,
                                                  NvU8       *pLocalDigest,
                                                  NvU32      *pDigestSize)
{
    nv_state_t                 *nv = nv_state;
    nv_linux_state_t           *nvl;
    struct nv_rsi_vdevice_info *pInfo;
    const char                 *pAlgName;
    NvU32                       digestSize;
    NV_STATUS                   status;

    if ((nv == NULL) || (pCertChain == NULL) || (certChainSize == 0) ||
        (pTsmDigest == NULL) || (pLocalDigest == NULL) || (pDigestSize == NULL))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    if ((nvl == NULL) || (nvl->pci_dev == NULL))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    //
    // Handed to the RMM by physical address, so it must live in the kernel
    // linear map. Unlike the RHI shared buffer this stays encrypted: the RMM
    // writes it, and decrypting it would let the host forge the very digest
    // this path exists to check.
    //
    pInfo = kmalloc(sizeof(*pInfo), GFP_KERNEL | __GFP_ZERO);
    if (pInfo == NULL)
    {
        return NV_ERR_NO_MEMORY;
    }

    status = _nv_rsi_vdev_get_info(nvl->pci_dev, pInfo);
    if (status != NV_OK)
    {
        goto done;
    }

    switch (pInfo->hashAlgo)
    {
        case NV_RSI_HASH_SHA_256:
            pAlgName   = "sha256";
            digestSize = NV_RSI_SHA_256_DIGEST_SIZE;
            break;
        case NV_RSI_HASH_SHA_512:
            pAlgName   = "sha512";
            digestSize = NV_RSI_SHA_512_DIGEST_SIZE;
            break;
        case NV_RSI_HASH_SHA_384:
            pAlgName   = "sha384";
            digestSize = NV_RSI_SHA_384_DIGEST_SIZE;
            break;
        default:
            nv_printf(NV_DBG_ERRORS,
                      "NVRM: %s: RMM reported unknown hash algorithm %u\n",
                      __FUNCTION__, pInfo->hashAlgo);
            status = NV_ERR_NOT_SUPPORTED;
            goto done;
    }

    if (*pDigestSize < digestSize)
    {
        *pDigestSize = digestSize;
        status = NV_ERR_BUFFER_TOO_SMALL;
        goto done;
    }

    status = _nv_hash_buffer(pAlgName, pCertChain, certChainSize, pLocalDigest);
    if (status != NV_OK)
    {
        goto done;
    }

    // Only the leading digestSize bytes of the 64-byte slot are meaningful.
    memcpy(pTsmDigest, pInfo->identityDigest, digestSize);
    *pDigestSize = digestSize;

done:
    kfree(pInfo);
    return status;
}

NV_STATUS NV_API_CALL os_read_device_certificate(void  *nv_state,
                                                 NvU8  *pBuffer,
                                                 NvU32 *pBufferSize)
{
    nv_state_t       *nv = nv_state;
    nv_linux_state_t *nvl;

    if ((nv == NULL) || (pBuffer == NULL) || (pBufferSize == NULL))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    if ((nvl == NULL) || (nvl->pci_dev == NULL))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    return _nv_rhi_read_cached_object(nvl->pci_dev,
                                      NV_RHI_DA_OBJECT_CERTIFICATE,
                                      pBuffer, pBufferSize);
}

#else // defined(NVCPU_AARCH64) && NV_HAVE_MEMORY_ENCRYPT_DECRYPT

NV_STATUS NV_API_CALL os_read_device_certificate(void  *nv_state,
                                                 NvU8  *pBuffer,
                                                 NvU32 *pBufferSize)
{
    return NV_ERR_NOT_SUPPORTED;
}

NV_STATUS NV_API_CALL os_read_device_cert_digests(void       *nv_state,
                                                  const NvU8 *pCertChain,
                                                  NvU32       certChainSize,
                                                  NvU8       *pTsmDigest,
                                                  NvU8       *pLocalDigest,
                                                  NvU32      *pDigestSize)
{
    return NV_ERR_NOT_SUPPORTED;
}

#endif // defined(NVCPU_AARCH64) && NV_HAVE_MEMORY_ENCRYPT_DECRYPT

NvBool NV_API_CALL os_supports_kernel_suspend_notifiers(void)
{
    return (NVreg_UseKernelSuspendNotifiers == 1);
}

NvU32 NV_API_CALL os_cgroup_implementation(void)
{
#if defined(NV_DMEM_CGROUP_PRESENT)
    if (cgroup_subsys_enabled(dmem_cgrp_subsys))
        return OS_CGROUP_IMPL_DMEM;
#endif
#if defined(NV_MISC_CGROUP_PRESENT)
    if (cgroup_subsys_enabled(misc_cgrp_subsys))
        return OS_CGROUP_IMPL_MISC;
#endif
    return OS_CGROUP_IMPL_NONE;
}

void* NV_API_CALL os_cgroup_for_pid(int pid, void *pidInfo, int impl)
{
    void *cgrp = NULL;

#if defined(NV_DMEM_CGROUP_PRESENT) || defined(NV_MISC_CGROUP_PRESENT)
    struct task_struct *task;
    struct pid *p;
    int subsys_id;

    //
    // pid_task() and task_cgroup() (task_css internally) require
    // rcu_read_lock() (or one of cgroup_mutex / css_set_lock) to be
    // held. The returned cgroup pointer is used by the caller only as
    // an opaque key in the memacct map, so no extra reference is needed
    // once it has been read out.
    //
    rcu_read_lock();

    p = pidInfo ? pidInfo : find_vpid(pid);
    if (!p)
        goto out;

    task = pid_task(p, PIDTYPE_PID);
    if (!task)
        goto out;

    switch (impl)
    {
#if defined(NV_DMEM_CGROUP_PRESENT)
        case OS_CGROUP_IMPL_DMEM:
            subsys_id = dmem_cgrp_id;
            break;
#endif
#if defined(NV_MISC_CGROUP_PRESENT)
        case OS_CGROUP_IMPL_MISC:
            subsys_id = misc_cgrp_id;
            break;
#endif
        default:
            goto out;
    }
    cgrp = task_cgroup(task, subsys_id);

out:
    rcu_read_unlock();
#endif
    return cgrp;
}

#if defined(NV_DMEM_CGROUP_PRESENT) || defined(NV_MISC_CGROUP_PRESENT)
void* NV_API_CALL os_cgroup_parent(void *cgroup)
{
    if (cgroup == NULL)
        return NULL;

    return cgroup_parent(cgroup);
}
#else
void* NV_API_CALL os_cgroup_parent(void *cgroup) { return NULL; }
#endif

#if defined(NV_DMEM_CGROUP_PRESENT)
void* NV_API_CALL os_dmem_cgroup_register_region(const char *name, NvU64 size, NvU64 precharge, void **prechargePool)
{
    void *region;
#if defined(NV_DMEM_CGROUP_REGISTER_REGION_HAS_INIT_ARG)
    const struct dmem_cgroup_init init =
    {
        .size = size,
    };
    region = dmem_cgroup_register_region(&init, name);
#else
    region = dmem_cgroup_register_region(size, name);
#endif
    if (IS_ERR(region))
    {
        return NULL;
    }

    if (precharge > 0)
    {
        int err = dmem_cgroup_try_charge(region, precharge, (struct dmem_cgroup_pool_state **)prechargePool, NULL);
        if (err)
        {
            dmem_cgroup_unregister_region(region);
            region = NULL;
        }
    }

    return region;
}

void NV_API_CALL os_dmem_cgroup_unregister_region(void *region, void *prechargePool, NvU64 precharge)
{
    if (precharge > 0)
        dmem_cgroup_uncharge(prechargePool, precharge);
    dmem_cgroup_unregister_region(region);
}

NV_STATUS NV_API_CALL os_dmem_cgroup_try_charge(void *region, NvU64 size, void **ret_pool, void **ret_limit_pool)
{
    int err = dmem_cgroup_try_charge(region, size, (struct dmem_cgroup_pool_state **)ret_pool,
        (struct dmem_cgroup_pool_state **)ret_limit_pool);

    if (err == -EAGAIN)
        return NV_ERR_RESOURCE_ACCOUNTING_HARD_LIMIT_EXCEEDED;
    else if (err < 0)
        return NV_ERR_OPERATING_SYSTEM;

    return NV_OK;
}

void NV_API_CALL os_dmem_cgroup_uncharge(void *pool, NvU64 size)
{
    dmem_cgroup_uncharge(pool, size);
}

void NV_API_CALL os_dmem_cgroup_pool_state_put(void *pool)
{
    dmem_cgroup_pool_state_put(pool);
}

NvBool NV_API_CALL os_dmem_cgroup_state_evict_valuable(void *limit_pool, void *test_pool, NvBool ignore_low, NvBool *ret_hit_low)
{
    bool kernel_ret_hit_low;
    NvBool kernel_result = dmem_cgroup_state_evict_valuable(limit_pool, test_pool, ignore_low, &kernel_ret_hit_low);
    if (ret_hit_low)
        *ret_hit_low = kernel_ret_hit_low;
    return kernel_result;
}
#else // !defined()
void* NV_API_CALL os_dmem_cgroup_register_region(const char *name, NvU64 size, NvU64 precharge, void **prechargePool) { return NULL; }
void NV_API_CALL os_dmem_cgroup_unregister_region(void *region, void *prechargePool, NvU64 precharge) {}
NV_STATUS NV_API_CALL os_dmem_cgroup_try_charge(void *region, NvU64 size, void **ret_pool, void **ret_limit_pool) { return NV_OK; }
void NV_API_CALL os_dmem_cgroup_uncharge(void *pool, NvU64 size) {}
void NV_API_CALL os_dmem_cgroup_pool_state_put(void *pool) {}
NvBool NV_API_CALL os_dmem_cgroup_state_evict_valuable(void *limit_pool, void *test_pool, NvBool ignore_low, NvBool *ret_hit_low) { return NV_FALSE; }
#endif

#if defined(NV_MISC_CGROUP_PRESENT)
void* NV_API_CALL os_cgroup_get_from_fd(NvU32 fd)
{
    void *cgroup = cgroup_get_from_fd(fd);
    if (IS_ERR(cgroup))
        return NULL;
    return cgroup;
}

void NV_API_CALL os_cgroup_put(void *cgroup)
{
    if (cgroup != NULL)
        cgroup_put(cgroup);
}

void NV_API_CALL os_cgroup_get(void *cgroup)
{
    cgroup_get(cgroup);
}
#else // !defined(NV_MISC_CGROUP_PRESENT)
void* NV_API_CALL os_cgroup_get_from_fd(NvU32 fd) { return NULL; }
void NV_API_CALL os_cgroup_put(void *cgroup) {}
void NV_API_CALL os_cgroup_get(void *cgroup) {}
#endif
