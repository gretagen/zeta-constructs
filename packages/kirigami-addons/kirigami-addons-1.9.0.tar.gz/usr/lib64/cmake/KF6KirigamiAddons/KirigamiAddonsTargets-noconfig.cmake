#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KirigamiAddonsStatefulApp" for configuration ""
set_property(TARGET KirigamiAddonsStatefulApp APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KirigamiAddonsStatefulApp PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "KF6::I18n;KF6::CoreAddons"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigamiAddonsStatefulApp.so.1.9.0"
  IMPORTED_SONAME_NOCONFIG "libKirigamiAddonsStatefulApp.so.6"
  )

list(APPEND _cmake_import_check_targets KirigamiAddonsStatefulApp )
list(APPEND _cmake_import_check_files_for_KirigamiAddonsStatefulApp "${_IMPORT_PREFIX}/lib64/libKirigamiAddonsStatefulApp.so.1.9.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
