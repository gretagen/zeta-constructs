#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cxx-rust-cssparser" for configuration ""
set_property(TARGET cxx-rust-cssparser APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(cxx-rust-cssparser PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libcxx-rust-cssparser.so.1.1.0"
  IMPORTED_SONAME_NOCONFIG "libcxx-rust-cssparser.so.1"
  )

list(APPEND _cmake_import_check_targets cxx-rust-cssparser )
list(APPEND _cmake_import_check_files_for_cxx-rust-cssparser "${_IMPORT_PREFIX}/lib64/libcxx-rust-cssparser.so.1.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
