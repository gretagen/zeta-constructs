#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::KWaylandClient" for configuration ""
set_property(TARGET Plasma::KWaylandClient APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(Plasma::KWaylandClient PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Concurrent"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKWaylandClient.so.6.3.6"
  IMPORTED_SONAME_NOCONFIG "libKWaylandClient.so.6"
  )

list(APPEND _cmake_import_check_targets Plasma::KWaylandClient )
list(APPEND _cmake_import_check_files_for_Plasma::KWaylandClient "${_IMPORT_PREFIX}/lib64/libKWaylandClient.so.6.3.6" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
