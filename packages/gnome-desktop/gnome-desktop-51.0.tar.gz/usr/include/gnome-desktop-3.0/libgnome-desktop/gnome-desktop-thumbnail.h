/*
 * gnome-thumbnail.h: Utilities for handling thumbnails
 *
 * Copyright (C) 2002 Red Hat, Inc.
 *
 * This file is part of the Gnome Library.
 *
 * The Gnome Library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * The Gnome Library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with the Gnome Library; see the file COPYING.LIB.  If not,
 * write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 * Author: Alexander Larsson <alexl@redhat.com>
 */

#ifndef GNOME_DESKTOP_THUMBNAIL_H
#define GNOME_DESKTOP_THUMBNAIL_H

#ifndef GNOME_DESKTOP_USE_UNSTABLE_API
#error    GnomeDesktopThumbnail is unstable API. You must define GNOME_DESKTOP_USE_UNSTABLE_API before including gnome-desktop-thumbnail.h
#endif

#include <glib.h>
#include <glib-object.h>
#include <time.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include <libgnome-desktop/gnome-desktop-version.h>

G_BEGIN_DECLS

typedef enum {
  GNOME_DESKTOP_THUMBNAIL_SIZE_NORMAL,
  GNOME_DESKTOP_THUMBNAIL_SIZE_LARGE,
  GNOME_DESKTOP_THUMBNAIL_SIZE_XLARGE,
  GNOME_DESKTOP_THUMBNAIL_SIZE_XXLARGE,
} GnomeDesktopThumbnailSize;

#define GNOME_DESKTOP_TYPE_THUMBNAIL_FACTORY		(gnome_desktop_thumbnail_factory_get_type ())
#define GNOME_DESKTOP_THUMBNAIL_FACTORY(obj)	(G_TYPE_CHECK_INSTANCE_CAST ((obj), GNOME_DESKTOP_TYPE_THUMBNAIL_FACTORY, GnomeDesktopThumbnailFactory))
#define GNOME_DESKTOP_THUMBNAIL_FACTORY_CLASS(klass)	(G_TYPE_CHECK_CLASS_CAST ((klass), GNOME_DESKTOP_TYPE_THUMBNAIL_FACTORY, GnomeDesktopThumbnailFactoryClass))
#define GNOME_DESKTOP_IS_THUMBNAIL_FACTORY(obj)		(G_TYPE_CHECK_INSTANCE_TYPE ((obj), GNOME_DESKTOP_TYPE_THUMBNAIL_FACTORY))
#define GNOME_DESKTOP_IS_THUMBNAIL_FACTORY_CLASS(klass)	(G_TYPE_CLASS_CHECK_CLASS_TYPE ((klass), GNOME_DESKTOP_TYPE_THUMBNAIL_FACTORY))

typedef struct _GnomeDesktopThumbnailFactory        GnomeDesktopThumbnailFactory;
typedef struct _GnomeDesktopThumbnailFactoryClass   GnomeDesktopThumbnailFactoryClass;
typedef struct _GnomeDesktopThumbnailFactoryPrivate GnomeDesktopThumbnailFactoryPrivate;

struct _GnomeDesktopThumbnailFactory {
	GObject parent;

	GnomeDesktopThumbnailFactoryPrivate *priv;
};

struct _GnomeDesktopThumbnailFactoryClass {
	GObjectClass parent;
};

G_DEFINE_AUTOPTR_CLEANUP_FUNC(GnomeDesktopThumbnailFactory, g_object_unref)

GType                  gnome_desktop_thumbnail_factory_get_type (void);
GnomeDesktopThumbnailFactory *gnome_desktop_thumbnail_factory_new      (GnomeDesktopThumbnailSize     size);

char *                 gnome_desktop_thumbnail_factory_lookup   (GnomeDesktopThumbnailFactory *factory,
								 const char            *uri,
								 time_t                 mtime);

gboolean               gnome_desktop_thumbnail_factory_has_valid_failed_thumbnail (GnomeDesktopThumbnailFactory *factory,
										   const char            *uri,
										   time_t                 mtime);
gboolean               gnome_desktop_thumbnail_factory_can_thumbnail (GnomeDesktopThumbnailFactory *factory,
								      const char            *uri,
								      const char            *mime_type,
								      time_t                 mtime);
GdkPixbuf * gnome_desktop_thumbnail_factory_generate_thumbnail (GnomeDesktopThumbnailFactory *factory,
                                                                const char                   *uri,
                                                                const char                   *mime_type,
                                                                GCancellable                 *cancellable,
                                                                GError                      **error);
gboolean               gnome_desktop_thumbnail_factory_save_thumbnail (GnomeDesktopThumbnailFactory *factory,
                                                                       GdkPixbuf                    *thumbnail,
                                                                       const char                   *uri,
                                                                       time_t                        original_mtime,
                                                                       GCancellable                 *cancellable,
                                                                       GError                      **error);
gboolean               gnome_desktop_thumbnail_factory_create_failed_thumbnail (GnomeDesktopThumbnailFactory *factory,
                                                                                const char                   *uri,
                                                                                time_t                        mtime,
                                                                                GCancellable                 *cancellable,
                                                                                GError                      **error);

void                   gnome_desktop_thumbnail_factory_generate_thumbnail_async (GnomeDesktopThumbnailFactory *factory,
                                                                                 const char                   *uri,
                                                                                 const char                   *mime_type,
                                                                                 GCancellable                 *cancellable,
                                                                                 GAsyncReadyCallback           callback,
                                                                                 gpointer                      user_data);

GdkPixbuf *            gnome_desktop_thumbnail_factory_generate_thumbnail_finish (GnomeDesktopThumbnailFactory *factory,
                                                                                  GAsyncResult                 *result,
                                                                                  GError                      **error);

void                   gnome_desktop_thumbnail_factory_save_thumbnail_async (GnomeDesktopThumbnailFactory *factory,
                                                                             GdkPixbuf                    *thumbnail,
                                                                             const char                   *uri,
                                                                             time_t                        original_mtime,
                                                                             GCancellable                 *cancellable,
                                                                             GAsyncReadyCallback           callback,
                                                                             gpointer                      user_data);

gboolean               gnome_desktop_thumbnail_factory_save_thumbnail_finish (GnomeDesktopThumbnailFactory *factory,
                                                                              GAsyncResult                 *result,
                                                                              GError                      **error);

void                   gnome_desktop_thumbnail_factory_create_failed_thumbnail_async (GnomeDesktopThumbnailFactory *factory,
                                                                                      const char                   *uri,
                                                                                      time_t                        original_mtime,
                                                                                      GCancellable                 *cancellable,
                                                                                      GAsyncReadyCallback           callback,
                                                                                      gpointer                      user_data);

gboolean               gnome_desktop_thumbnail_factory_create_failed_thumbnail_finish (GnomeDesktopThumbnailFactory *factory,
                                                                                       GAsyncResult                 *result,
                                                                                       GError                      **error);

/* Thumbnailing utils: */
gboolean   gnome_desktop_thumbnail_is_valid          (GdkPixbuf          *pixbuf,
						      const char         *uri,
						      time_t              mtime);
char *     gnome_desktop_thumbnail_path_for_uri      (const char         *uri,
						      GnomeDesktopThumbnailSize  size);

G_END_DECLS

#endif /* GNOME_DESKTOP_THUMBNAIL_H */
