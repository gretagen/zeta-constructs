/* gnome-desktop-version.h
 *
 * Copyright (C) 2022 Sergio Costas
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * as published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 */

#ifndef __GNOME_DESKTOP_VERSION_H__
#define __GNOME_DESKTOP_VERSION_H__

#define GNOME_DESKTOP_PLATFORM_VERSION 51

int gnome_get_platform_version (void);
#endif

