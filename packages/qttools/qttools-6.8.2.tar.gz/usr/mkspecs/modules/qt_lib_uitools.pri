QT.uitools.VERSION = 6.8.2
QT.uitools.name = QtUiTools
QT.uitools.module = Qt6UiTools
QT.uitools.libs = $$QT_MODULE_LIB_BASE
QT.uitools.ldflags = 
QT.uitools.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtUiTools
QT.uitools.frameworks = 
QT.uitools.bins = $$QT_MODULE_BIN_BASE
QT.uitools.depends =  core gui widgets
QT.uitools.run_depends = uiplugin
QT.uitools.uses = 
QT.uitools.module_config = v2
QT.uitools.DEFINES = QT_UITOOLS_LIB
QT.uitools.enabled_features = 
QT.uitools.disabled_features = 
QT_CONFIG += 
QT_MODULES += uitools

