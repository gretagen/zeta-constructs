#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6KirigamiPrimitives" for configuration ""
set_property(TARGET KF6KirigamiPrimitives APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6KirigamiPrimitives PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Qml;Qt6::Core;Qt6::Quick;KF6::KirigamiPlatform"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigamiPrimitives.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKirigamiPrimitives.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiPrimitives )
list(APPEND _cmake_import_check_files_for_KF6KirigamiPrimitives "${_IMPORT_PREFIX}/lib64/libKirigamiPrimitives.so.6.13.0" )

# Import target "KF6KirigamiDelegates" for configuration ""
set_property(TARGET KF6KirigamiDelegates APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6KirigamiDelegates PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Qml;Qt6::Core"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigamiDelegates.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKirigamiDelegates.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiDelegates )
list(APPEND _cmake_import_check_files_for_KF6KirigamiDelegates "${_IMPORT_PREFIX}/lib64/libKirigamiDelegates.so.6.13.0" )

# Import target "KF6KirigamiDialogs" for configuration ""
set_property(TARGET KF6KirigamiDialogs APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6KirigamiDialogs PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Qml;Qt6::Core;Qt6::Quick;KF6::KirigamiPlatform"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigamiDialogs.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKirigamiDialogs.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiDialogs )
list(APPEND _cmake_import_check_files_for_KF6KirigamiDialogs "${_IMPORT_PREFIX}/lib64/libKirigamiDialogs.so.6.13.0" )

# Import target "KF6KirigamiLayouts" for configuration ""
set_property(TARGET KF6KirigamiLayouts APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6KirigamiLayouts PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Qml;Qt6::Core;Qt6::Quick;Qt6::QuickControls2;KF6::KirigamiPlatform"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigamiLayouts.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKirigamiLayouts.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiLayouts )
list(APPEND _cmake_import_check_files_for_KF6KirigamiLayouts "${_IMPORT_PREFIX}/lib64/libKirigamiLayouts.so.6.13.0" )

# Import target "KF6KirigamiPrivate" for configuration ""
set_property(TARGET KF6KirigamiPrivate APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6KirigamiPrivate PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Qml;Qt6::Gui"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigamiPrivate.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKirigamiPrivate.so.6"
  )

list(APPEND _cmake_import_check_targets KF6KirigamiPrivate )
list(APPEND _cmake_import_check_files_for_KF6KirigamiPrivate "${_IMPORT_PREFIX}/lib64/libKirigamiPrivate.so.6.13.0" )

# Import target "KF6Kirigami" for configuration ""
set_property(TARGET KF6Kirigami APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6Kirigami PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Concurrent;KF6KirigamiDelegates;KF6KirigamiPrimitives;KF6KirigamiDialogs;KF6KirigamiLayouts;KF6KirigamiPrivate"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKirigami.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKirigami.so.6"
  )

list(APPEND _cmake_import_check_targets KF6Kirigami )
list(APPEND _cmake_import_check_files_for_KF6Kirigami "${_IMPORT_PREFIX}/lib64/libKirigami.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
