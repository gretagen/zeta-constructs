QT.multimediaquick_private.VERSION = 6.8.2
QT.multimediaquick_private.name = QtMultimediaQuick
QT.multimediaquick_private.module = Qt6MultimediaQuick
QT.multimediaquick_private.libs = $$QT_MODULE_LIB_BASE
QT.multimediaquick_private.ldflags = 
QT.multimediaquick_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtMultimediaQuick $$QT_MODULE_INCLUDE_BASE/QtMultimediaQuick/6.8.2 $$QT_MODULE_INCLUDE_BASE/QtMultimediaQuick/6.8.2/QtMultimediaQuick
QT.multimediaquick_private.frameworks = 
QT.multimediaquick_private.bins = $$QT_MODULE_BIN_BASE
QT.multimediaquick_private.depends =  core multimedia_private quick quick_private
QT.multimediaquick_private.run_depends = qml qml_private
QT.multimediaquick_private.uses = 
QT.multimediaquick_private.module_config = v2 internal_module
QT.multimediaquick_private.DEFINES = QT_MULTIMEDIAQUICK_LIB
QT.multimediaquick_private.enabled_features = 
QT.multimediaquick_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += multimediaquick_private

