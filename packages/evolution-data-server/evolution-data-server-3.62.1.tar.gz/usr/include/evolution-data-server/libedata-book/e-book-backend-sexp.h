/*
 * SPDX-FileCopyrightText: (C) 1999-2008 Novell, Inc. (www.novell.com)
 * SPDX-FileCopyrightText: (C) 2012 Intel Corporation
 * SPDX-License-Identifier: LGPL-2.0-or-later
 * SPDX-FileContributor: Chris Lahey <clahey@ximian.com>
 * SPDX-FileContributor: Tristan Van Berkom <tristanvb@openismus.com>
 */

#if !defined (__LIBEDATA_BOOK_H_INSIDE__) && !defined (LIBEDATA_BOOK_COMPILATION)
#error "Only <libedata-book/libedata-book.h> should be included directly."
#endif

#ifndef E_BOOK_BACKEND_SEXP_H
#define E_BOOK_BACKEND_SEXP_H

#include <libebook-contacts/libebook-contacts.h>

/* Standard GObject macros */
#define E_TYPE_BOOK_BACKEND_SEXP \
	(e_book_backend_sexp_get_type ())
#define E_BOOK_BACKEND_SEXP(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST \
	((obj), E_TYPE_BOOK_BACKEND_SEXP, EBookBackendSExp))
#define E_BOOK_BACKEND_SEXP_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_CAST \
	((cls), E_TYPE_BOOK_BACKEND_SEXP, EBookBackendSExpClass))
#define E_IS_BOOK_BACKEND_SEXP(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE \
	((obj), E_TYPE_BOOK_BACKEND_SEXP))
#define E_IS_BOOK_BACKEND_SEXP_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_TYPE \
	((cls), E_TYPE_BOOK_BACKEND_SEXP))
#define E_BOOK_BACKEND_SEXP_GET_CLASS(cls) \
	(G_TYPE_INSTANCE_GET_CLASS \
	((obj), E_TYPE_BOOK_BACKEND_SEXP, EBookBackendSExpClass))

G_BEGIN_DECLS

typedef struct _EBookBackendSExp EBookBackendSExp;
typedef struct _EBookBackendSExpClass EBookBackendSExpClass;
typedef struct _EBookBackendSExpPrivate EBookBackendSExpPrivate;

/**
 * EBookBackendSexp:
 */
struct _EBookBackendSExp {
	/*< private >*/
	GObject parent;
	EBookBackendSExpPrivate *priv;
};

/**
 * EBookBackendSexpClass:
 *
 * Class structure for the #EBookBackendSexp class.
 */
struct _EBookBackendSExpClass {
	/*< private >*/
	GObjectClass parent_class;
};

GType		e_book_backend_sexp_get_type	(void) G_GNUC_CONST;
EBookBackendSExp *
		e_book_backend_sexp_new		(const gchar *text);
const gchar *	e_book_backend_sexp_text	(EBookBackendSExp *sexp);
gboolean	e_book_backend_sexp_match_vcard	(EBookBackendSExp *sexp,
						 const gchar *vcard);
gboolean	e_book_backend_sexp_match_contact
						(EBookBackendSExp *sexp,
						 EContact *contact);
void		e_book_backend_sexp_lock	(EBookBackendSExp *sexp);
void		e_book_backend_sexp_unlock	(EBookBackendSExp *sexp);

/**
 * EBookBackendSexpCompareKind:
 * @E_BOOK_BACKEND_SEXP_COMPARE_KIND_UNKNOWN: Unknown compare kind
 * @E_BOOK_BACKEND_SEXP_COMPARE_KIND_BEGINS_WITH: Check whether a value begins with a string
 * @E_BOOK_BACKEND_SEXP_COMPARE_KIND_ENDS_WITH: Check whether a value ends with a string
 * @E_BOOK_BACKEND_SEXP_COMPARE_KIND_CONTAINS: Check whether a value contains a string
 * @E_BOOK_BACKEND_SEXP_COMPARE_KIND_IS: Check whether a value exactly matches a string
 *
 * What compare function should be used when comparing two values.
 *
 * Since: 3.50
 **/
typedef enum _EBookBackendSexpCompareKind {
	E_BOOK_BACKEND_SEXP_COMPARE_KIND_UNKNOWN,
	E_BOOK_BACKEND_SEXP_COMPARE_KIND_BEGINS_WITH,
	E_BOOK_BACKEND_SEXP_COMPARE_KIND_ENDS_WITH,
	E_BOOK_BACKEND_SEXP_COMPARE_KIND_CONTAINS,
	E_BOOK_BACKEND_SEXP_COMPARE_KIND_IS
} EBookBackendSexpCompareKind;

gboolean	e_book_backend_sexp_util_phone_compare
						(const gchar *phone_value,
						 const gchar *lookup_value,
						 EBookBackendSexpCompareKind compare_kind);

G_END_DECLS

#endif /* E_BOOK_BACKEND_SEXP_H */
