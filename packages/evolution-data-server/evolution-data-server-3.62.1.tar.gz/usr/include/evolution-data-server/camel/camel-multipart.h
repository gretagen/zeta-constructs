/*
 * SPDX-FileCopyrightText: (C) 1999-2008 Novell, Inc. (www.novell.com)
 * SPDX-License-Identifier: LGPL-2.0-or-later
 * SPDX-FileContributor: Bertrand Guiheneuf <bertrand@helixcode.com>
 */

#if !defined (__CAMEL_H_INSIDE__) && !defined (CAMEL_COMPILATION)
#error "Only <camel/camel.h> can be included directly."
#endif

#ifndef CAMEL_MULTIPART_H
#define CAMEL_MULTIPART_H

#include <camel/camel-data-wrapper.h>
#include <camel/camel-mime-parser.h>
#include <camel/camel-mime-part.h>

/* Standard GObject macros */
#define CAMEL_TYPE_MULTIPART \
	(camel_multipart_get_type ())
#define CAMEL_MULTIPART(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST \
	((obj), CAMEL_TYPE_MULTIPART, CamelMultipart))
#define CAMEL_MULTIPART_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_CAST \
	((cls), CAMEL_TYPE_MULTIPART, CamelMultipartClass))
#define CAMEL_IS_MULTIPART(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE \
	((obj), CAMEL_TYPE_MULTIPART))
#define CAMEL_IS_MULTIPART_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_TYPE \
	((cls), CAMEL_TYPE_MULTIPART))
#define CAMEL_MULTIPART_GET_CLASS(obj) \
	(G_TYPE_INSTANCE_GET_CLASS \
	((obj), CAMEL_TYPE_MULTIPART, CamelMultipartClass))

G_BEGIN_DECLS

typedef struct _CamelMultipart CamelMultipart;
typedef struct _CamelMultipartClass CamelMultipartClass;
typedef struct _CamelMultipartPrivate CamelMultipartPrivate;

struct _CamelMultipart {
	CamelDataWrapper parent;
	CamelMultipartPrivate *priv;
};

struct _CamelMultipartClass {
	CamelDataWrapperClass parent_class;

	void		(*add_part)		(CamelMultipart *multipart,
						 CamelMimePart *part);
	CamelMimePart *	(*get_part)		(CamelMultipart *multipart,
						 guint index);
	guint		(*get_number)		(CamelMultipart *multipart);
	const gchar *	(*get_boundary)		(CamelMultipart *multipart);
	void		(*set_boundary)		(CamelMultipart *multipart,
						 const gchar *boundary);
	gint		(*construct_from_parser)
						(CamelMultipart *multipart,
						 CamelMimeParser *parser);
	gchar *		(*generate_preview)	(CamelMultipart *multipart,
						 CamelGeneratePreviewFunc func,
						 gpointer user_data);

	/* Padding for future expansion */
	gpointer reserved[19];
};

GType		camel_multipart_get_type	(void) G_GNUC_CONST;
CamelMultipart *
		camel_multipart_new		(void);
void		camel_multipart_add_part	(CamelMultipart *multipart,
						 CamelMimePart *part);
CamelMimePart *	camel_multipart_get_part	(CamelMultipart *multipart,
						 guint index);
guint		camel_multipart_get_number	(CamelMultipart *multipart);
const gchar *	camel_multipart_get_boundary	(CamelMultipart *multipart);
void		camel_multipart_set_boundary	(CamelMultipart *multipart,
						 const gchar *boundary);
const gchar *	camel_multipart_get_preface	(CamelMultipart *multipart);
void		camel_multipart_set_preface	(CamelMultipart *multipart,
						 const gchar *preface);
const gchar *	camel_multipart_get_postface	(CamelMultipart *multipart);
void		camel_multipart_set_postface	(CamelMultipart *multipart,
						 const gchar *postface);
gint		camel_multipart_construct_from_parser
						(CamelMultipart *multipart,
						 CamelMimeParser *parser);
gchar *		camel_multipart_generate_preview(CamelMultipart *multipart,
						 CamelGeneratePreviewFunc func,
						 gpointer user_data);

G_END_DECLS

#endif /* CAMEL_MULTIPART_H */
