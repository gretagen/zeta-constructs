/*
 * SPDX-FileCopyrightText: (C) 1999-2008 Novell, Inc. (www.novell.com)
 * SPDX-License-Identifier: LGPL-2.0-or-later
 * SPDX-FileContributor: Michael Zucchi <notzed@ximian.com>
 */

#if !defined (__CAMEL_H_INSIDE__) && !defined (CAMEL_COMPILATION)
#error "Only <camel/camel.h> can be included directly."
#endif

#ifndef CAMEL_MIME_FILTER_BASIC_H
#define CAMEL_MIME_FILTER_BASIC_H

#include <camel/camel-enums.h>
#include <camel/camel-mime-filter.h>

/* Standard GObject macros */
#define CAMEL_TYPE_MIME_FILTER_BASIC \
	(camel_mime_filter_basic_get_type ())
#define CAMEL_MIME_FILTER_BASIC(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST \
	((obj), CAMEL_TYPE_MIME_FILTER_BASIC, CamelMimeFilterBasic))
#define CAMEL_MIME_FILTER_BASIC_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_CAST \
	((cls), CAMEL_TYPE_MIME_FILTER_BASIC, CamelMimeFilterBasicClass))
#define CAMEL_IS_MIME_FILTER_BASIC(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE \
	((obj), CAMEL_TYPE_MIME_FILTER_BASIC))
#define CAMEL_IS_MIME_FILTER_BASIC_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_TYPE \
	((cls), CAMEL_TYPE_MIME_FILTER_BASIC))
#define CAMEL_MIME_FILTER_BASIC_GET_CLASS(obj) \
	(G_TYPE_INSTANCE_GET_CLASS \
	((obj), CAMEL_TYPE_MIME_FILTER_BASIC, CamelMimeFilterBasicClass))

G_BEGIN_DECLS

typedef struct _CamelMimeFilterBasic CamelMimeFilterBasic;
typedef struct _CamelMimeFilterBasicClass CamelMimeFilterBasicClass;
typedef struct _CamelMimeFilterBasicPrivate CamelMimeFilterBasicPrivate;

struct _CamelMimeFilterBasic {
	CamelMimeFilter parent;
	CamelMimeFilterBasicPrivate *priv;
};

struct _CamelMimeFilterBasicClass {
	CamelMimeFilterClass parent_class;

	/* Padding for future expansion */
	gpointer reserved[20];
};

GType		camel_mime_filter_basic_get_type (void);
CamelMimeFilter *
		camel_mime_filter_basic_new	(CamelMimeFilterBasicType type);

G_END_DECLS

#endif /* CAMEL_MIME_FILTER_BASIC_H */
