/*
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#ifndef LIBEDATASERVERUI_H
#define LIBEDATASERVERUI_H

#define __LIBEDATASERVERUI_H_INSIDE__

#include <libedataserverui/e-buffer-tagger.h>
#include <libedataserverui/e-cell-renderer-color.h>
#include <libedataserverui/e-certificate-widget.h>
#include <libedataserverui/e-credentials-prompter.h>
#include <libedataserverui/e-credentials-prompter-impl.h>
#include <libedataserverui/e-credentials-prompter-impl-oauth2.h>
#include <libedataserverui/e-credentials-prompter-impl-password.h>
#include <libedataserverui/e-reminders-widget.h>
#include <libedataserverui/e-trust-prompt.h>
#include <libedataserverui/e-webdav-discover-widget.h>

#undef __LIBEDATASERVERUI_H_INSIDE__

#endif /* LIBEDATASERVERUI_H */
