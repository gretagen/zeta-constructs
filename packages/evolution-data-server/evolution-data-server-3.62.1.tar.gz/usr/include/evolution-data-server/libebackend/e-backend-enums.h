/*
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#if !defined (__LIBEBACKEND_H_INSIDE__) && !defined (LIBEBACKEND_COMPILATION)
#error "Only <libebackend/libebackend.h> should be included directly."
#endif

#ifndef E_BACKEND_ENUMS_H
#define E_BACKEND_ENUMS_H

/**
 * EAuthenticationSessionResult:
 * @E_AUTHENTICATION_SESSION_ERROR:
 *   An error occurred while authenticating.
 * @E_AUTHENTICATION_SESSION_SUCCESS:
 *   Client reported successful authentication.
 * @E_AUTHENTICATION_SESSION_DISMISSED:
 *   User dismissed the authentication prompt.
 *
 * Completion codes used by #EAuthenticationSession.
 *
 * Since: 3.6
 **/
typedef enum {
	E_AUTHENTICATION_SESSION_ERROR,
	E_AUTHENTICATION_SESSION_SUCCESS,
	E_AUTHENTICATION_SESSION_DISMISSED
} EAuthenticationSessionResult;

/**
 * EDBusServerExitCode:
 * @E_DBUS_SERVER_EXIT_NONE:
 *   The server's run state is unchanged.
 * @E_DBUS_SERVER_EXIT_NORMAL:
 *   Normal termination.  The process itself may now terminate.
 * @E_DBUS_SERVER_EXIT_RELOAD:
 *   The server should reload its configuration and start again.
 *   Servers that do not support reloading may wish to intercept
 *   this exit code and stop the #EDBusServer::quit-server emission.
 *
 * Exit codes submitted to e_dbus_server_quit() and returned by
 * e_dbus_server_run().
 *
 * Since: 3.6
 **/
typedef enum {
	E_DBUS_SERVER_EXIT_NONE,
	E_DBUS_SERVER_EXIT_NORMAL,
	E_DBUS_SERVER_EXIT_RELOAD
} EDBusServerExitCode;

/**
 * ESourcePermissionFlags:
 * @E_SOURCE_PERMISSION_NONE:
 *   The data source gets no initial permissions.
 * @E_SOURCE_PERMISSION_WRITABLE:
 *   The data source is initially writable.
 * @E_SOURCE_PERMISSION_REMOVABLE:
 *   The data source is initially removable.
 *
 * Initial permissions for a newly-loaded data source key file.
 *
 * Since: 3.6
 **/
typedef enum { /*< flags >*/
	E_SOURCE_PERMISSION_NONE = 0,
	E_SOURCE_PERMISSION_WRITABLE = 1 << 0,
	E_SOURCE_PERMISSION_REMOVABLE = 1 << 1
} ESourcePermissionFlags;

/**
 * EOfflineState:
 * @E_OFFLINE_STATE_UNKNOWN: Unknown offline state.
 * @E_OFFLINE_STATE_SYNCED: The object if synchnized with no local changes.
 * @E_OFFLINE_STATE_LOCALLY_CREATED: The object is locally created.
 * @E_OFFLINE_STATE_LOCALLY_MODIFIED: The object is locally modified.
 * @E_OFFLINE_STATE_LOCALLY_DELETED: The object is locally deleted.
 *
 * Defines offline state of an object. Locally changed objects require
 * synchronization with their remote storage.
 *
 * Since: 3.26
 **/
typedef enum {
	E_OFFLINE_STATE_UNKNOWN = -1,
	E_OFFLINE_STATE_SYNCED,
	E_OFFLINE_STATE_LOCALLY_CREATED,
	E_OFFLINE_STATE_LOCALLY_MODIFIED,
	E_OFFLINE_STATE_LOCALLY_DELETED
} EOfflineState;

/**
 * ECollectionBackendParts:
 * @E_COLLECTION_BACKEND_PART_NONE: None part.
 * @E_COLLECTION_BACKEND_PART_CALENDAR: Check the calendar part.
 * @E_COLLECTION_BACKEND_PART_CONTACTS: Check the contacts part.
 * @E_COLLECTION_BACKEND_PART_MAIL: Check the mail part.
 * @E_COLLECTION_BACKEND_PART_ANY: Shortcut to have all parts checked.
 *
 * Flags to check whether at least one of the asked for parts is enabled.
 *
 * Since: 3.40
 **/
typedef enum { /*< flags >*/
	E_COLLECTION_BACKEND_PART_NONE = 0,
	E_COLLECTION_BACKEND_PART_CALENDAR = 1 << 0,
	E_COLLECTION_BACKEND_PART_CONTACTS = 1 << 1,
	E_COLLECTION_BACKEND_PART_MAIL = 1 << 2,
	E_COLLECTION_BACKEND_PART_ANY = ~0
} ECollectionBackendParts;

#endif /* E_BACKEND_ENUMS_H */
