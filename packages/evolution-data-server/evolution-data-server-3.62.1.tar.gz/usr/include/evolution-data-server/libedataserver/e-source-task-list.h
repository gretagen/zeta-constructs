/*
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#if !defined (__LIBEDATASERVER_H_INSIDE__) && !defined (LIBEDATASERVER_COMPILATION)
#error "Only <libedataserver/libedataserver.h> should be included directly."
#endif

#ifndef E_SOURCE_TASK_LIST_H
#define E_SOURCE_TASK_LIST_H

#include <libedataserver/e-source-selectable.h>

/* Standard GObject macros */
#define E_TYPE_SOURCE_TASK_LIST \
	(e_source_task_list_get_type ())
#define E_SOURCE_TASK_LIST(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST \
	((obj), E_TYPE_SOURCE_TASK_LIST, ESourceTaskList))
#define E_SOURCE_TASK_LIST_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_CAST \
	((cls), E_TYPE_SOURCE_TASK_LIST, ESourceTaskListClass))
#define E_IS_SOURCE_TASK_LIST(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE \
	((obj), E_TYPE_SOURCE_TASK_LIST))
#define E_IS_SOURCE_TASK_LIST_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_TYPE \
	((cls), E_TYPE_SOURCE_TASK_LIST))
#define E_SOURCE_TASK_LIST_GET_CLASS(obj) \
	(G_TYPE_INSTANCE_GET_CLASS \
	((obj), E_TYPE_SOURCE_TASK_LIST, ESourceTaskListClass))

/**
 * E_SOURCE_EXTENSION_TASK_LIST:
 *
 * Pass this extension name to e_source_get_extension() to access
 * #ESourceTaskList.  This is also used as a group name in key files.
 *
 * Since: 3.6
 **/
#define E_SOURCE_EXTENSION_TASK_LIST "Task List"

G_BEGIN_DECLS

typedef struct _ESourceTaskList ESourceTaskList;
typedef struct _ESourceTaskListClass ESourceTaskListClass;
typedef struct _ESourceTaskListPrivate ESourceTaskListPrivate;

/**
 * ESourceTaskList:
 * Since: 3.6
 **/
struct _ESourceTaskList {
	/*< private >*/
	ESourceSelectable parent;
	ESourceTaskListPrivate *priv;
};

struct _ESourceTaskListClass {
	ESourceSelectableClass parent_class;
};

GType		e_source_task_list_get_type	(void);

G_END_DECLS

#endif /* E_SOURCE_TASK_LIST_H */
