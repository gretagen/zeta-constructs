/*
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#if !defined (__LIBEDATASERVER_H_INSIDE__) && !defined (LIBEDATASERVER_COMPILATION)
#error "Only <libedataserver/libedataserver.h> should be included directly."
#endif

#ifndef E_SOURCE_SELECTABLE_H
#define E_SOURCE_SELECTABLE_H

#include <libedataserver/e-source-backend.h>

/* Standard GObject macros */
#define E_TYPE_SOURCE_SELECTABLE \
	(e_source_selectable_get_type ())
#define E_SOURCE_SELECTABLE(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST \
	((obj), E_TYPE_SOURCE_SELECTABLE, ESourceSelectable))
#define E_SOURCE_SELECTABLE_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_CAST \
	((cls), E_TYPE_SOURCE_SELECTABLE, ESourceSelectableClass))
#define E_IS_SOURCE_SELECTABLE(obj) \
	(G_TYPE_CHECK_INSTANCE_TYPE \
	((obj), E_TYPE_SOURCE_SELECTABLE))
#define E_IS_SOURCE_SELECTABLE_CLASS(cls) \
	(G_TYPE_CHECK_CLASS_TYPE \
	((cls), E_TYPE_SOURCE_SELECTABLE))
#define E_SOURCE_SELECTABLE_GET_CLASS(obj) \
	(G_TYPE_INSTANCE_GET_CLASS \
	((obj), E_TYPE_SOURCE_SELECTABLE, ESourceSelectableClass))

G_BEGIN_DECLS

typedef struct _ESourceSelectable ESourceSelectable;
typedef struct _ESourceSelectableClass ESourceSelectableClass;
typedef struct _ESourceSelectablePrivate ESourceSelectablePrivate;

/**
 * ESourceSelectable:
 * Since: 3.6
 **/
struct _ESourceSelectable {
	/*< private >*/
	ESourceBackend parent;
	ESourceSelectablePrivate *priv;
};

struct _ESourceSelectableClass {
	ESourceBackendClass parent_class;
};

GType		e_source_selectable_get_type	(void) G_GNUC_CONST;
const gchar *	e_source_selectable_get_color	(ESourceSelectable *extension);
gchar *		e_source_selectable_dup_color	(ESourceSelectable *extension);
void		e_source_selectable_set_color	(ESourceSelectable *extension,
						 const gchar *color);
gboolean	e_source_selectable_get_selected
						(ESourceSelectable *extension);
void		e_source_selectable_set_selected
						(ESourceSelectable *extension,
						 gboolean selected);
guint		e_source_selectable_get_order	(ESourceSelectable *extension);
void		e_source_selectable_set_order	(ESourceSelectable *extension,
						 guint order);
const gchar *	e_source_selectable_get_groups	(ESourceSelectable *extension);
gchar *		e_source_selectable_dup_groups	(ESourceSelectable *extension);
void		e_source_selectable_set_groups	(ESourceSelectable *extension,
						 const gchar *groups);

G_END_DECLS

#endif /* E_SOURCE_SELECTABLE_H */
