/*
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#ifndef LIBEDATASERVERUI4_H
#define LIBEDATASERVERUI4_H

#define __LIBEDATASERVERUI_H_INSIDE__

#include <libedataserverui4/e-buffer-tagger.h>
#include <libedataserverui4/e-cell-renderer-color.h>
#include <libedataserverui4/e-certificate-widget.h>
#include <libedataserverui4/e-credentials-prompter.h>
#include <libedataserverui4/e-credentials-prompter-impl.h>
#include <libedataserverui4/e-credentials-prompter-impl-oauth2.h>
#include <libedataserverui4/e-credentials-prompter-impl-password.h>
#include <libedataserverui4/e-reminders-widget.h>
#include <libedataserverui4/e-trust-prompt.h>
#include <libedataserverui4/e-webdav-discover-widget.h>

#undef __LIBEDATASERVERUI_H_INSIDE__

#endif /* LIBEDATASERVERUI4_H */
