#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::ConfigWidgets" for configuration ""
set_property(TARGET KF6::ConfigWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6::ConfigWidgets PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "KF6::CoreAddons;KF6::GuiAddons;KF6::I18n;KF6::Codecs;Qt6::DBus"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKF6ConfigWidgets.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKF6ConfigWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::ConfigWidgets )
list(APPEND _cmake_import_check_files_for_KF6::ConfigWidgets "${_IMPORT_PREFIX}/lib64/libKF6ConfigWidgets.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
