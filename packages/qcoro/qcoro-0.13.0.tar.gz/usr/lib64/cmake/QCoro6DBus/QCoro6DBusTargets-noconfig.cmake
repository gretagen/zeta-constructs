#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QCoro6::DBus" for configuration ""
set_property(TARGET QCoro6::DBus APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(QCoro6::DBus PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libQCoro6DBus.a"
  )

list(APPEND _cmake_import_check_targets QCoro6::DBus )
list(APPEND _cmake_import_check_files_for_QCoro6::DBus "${_IMPORT_PREFIX}/lib64/libQCoro6DBus.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
