#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QCoro6::WebSockets" for configuration ""
set_property(TARGET QCoro6::WebSockets APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(QCoro6::WebSockets PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libQCoro6WebSockets.a"
  )

list(APPEND _cmake_import_check_targets QCoro6::WebSockets )
list(APPEND _cmake_import_check_files_for_QCoro6::WebSockets "${_IMPORT_PREFIX}/lib64/libQCoro6WebSockets.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
