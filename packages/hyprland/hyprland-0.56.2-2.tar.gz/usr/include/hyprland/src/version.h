#pragma once
#define GIT_COMMIT_HASH    "unknown"
#define GIT_BRANCH         "unknown"
#define GIT_COMMIT_MESSAGE "unknown"
#define GIT_COMMIT_DATE    "unknown"
#define GIT_DIRTY          "unknown"
#define GIT_TAG            "unknown"
#define GIT_COMMITS        "0"

#define AQUAMARINE_VERSION "0.12.0"
// clang-format off
#define AQUAMARINE_VERSION_MAJOR 0
#define AQUAMARINE_VERSION_MINOR 12
#define AQUAMARINE_VERSION_PATCH 0
// clang-format on
#define HYPRLANG_VERSION     "0.6.8"
#define HYPRUTILS_VERSION    "0.14.0"
#define HYPRCURSOR_VERSION   "0.1.13"
#define HYPRGRAPHICS_VERSION "0.5.1"
