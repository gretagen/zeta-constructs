#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::StatusNotifierItem" for configuration ""
set_property(TARGET KF6::StatusNotifierItem APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6::StatusNotifierItem PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "KF6::WindowSystem"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKF6StatusNotifierItem.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKF6StatusNotifierItem.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::StatusNotifierItem )
list(APPEND _cmake_import_check_files_for_KF6::StatusNotifierItem "${_IMPORT_PREFIX}/lib64/libKF6StatusNotifierItem.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
