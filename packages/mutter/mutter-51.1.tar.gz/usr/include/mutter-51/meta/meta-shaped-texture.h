/*
 * shaped texture
 *
 * An actor to draw a texture clipped to a list of rectangles
 *
 * Authored By Neil Roberts  <neil@linux.intel.com>
 *
 * Copyright (C) 2008 Intel Corporation
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "clutter/clutter.h"
#include "cogl/cogl.h"
#include "meta/common.h"
#include "meta/meta-multi-texture.h"

G_BEGIN_DECLS

#define META_TYPE_SHAPED_TEXTURE (meta_shaped_texture_get_type ())

META_EXPORT
G_DECLARE_FINAL_TYPE (MetaShapedTexture,
                      meta_shaped_texture,
                      META, SHAPED_TEXTURE,
                      GObject)


META_EXPORT
void meta_shaped_texture_set_create_mipmaps (MetaShapedTexture *stex,
					     gboolean           create_mipmaps);

META_EXPORT
MetaMultiTexture * meta_shaped_texture_get_texture (MetaShapedTexture *stex);

META_EXPORT
void meta_shaped_texture_set_mask_texture (MetaShapedTexture *stex,
                                           CoglTexture       *mask_texture);

META_EXPORT
CoglBitmap * meta_shaped_texture_paint_to_bitmap (MetaShapedTexture *stex,
                                                  MtkRectangle      *clip,
                                                  CoglPixelFormat    format);

G_END_DECLS
