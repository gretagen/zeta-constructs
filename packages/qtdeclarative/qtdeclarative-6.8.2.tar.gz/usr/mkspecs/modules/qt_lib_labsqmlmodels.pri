QT.labsqmlmodels.VERSION = 6.8.2
QT.labsqmlmodels.name = QtLabsQmlModels
QT.labsqmlmodels.module = Qt6LabsQmlModels
QT.labsqmlmodels.libs = $$QT_MODULE_LIB_BASE
QT.labsqmlmodels.ldflags = 
QT.labsqmlmodels.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtLabsQmlModels
QT.labsqmlmodels.frameworks = 
QT.labsqmlmodels.bins = $$QT_MODULE_BIN_BASE
QT.labsqmlmodels.depends =  qmlmodels_private qml_private
QT.labsqmlmodels.run_depends = qml
QT.labsqmlmodels.uses = 
QT.labsqmlmodels.module_config = v2
QT.labsqmlmodels.DEFINES = QT_LABSQMLMODELS_LIB
QT.labsqmlmodels.enabled_features = 
QT.labsqmlmodels.disabled_features = 
QT_CONFIG += 
QT_MODULES += labsqmlmodels

