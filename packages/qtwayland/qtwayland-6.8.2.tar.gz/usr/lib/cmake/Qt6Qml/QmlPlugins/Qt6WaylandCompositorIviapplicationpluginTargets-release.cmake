#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::WaylandCompositorIviapplicationplugin" for configuration "Release"
set_property(TARGET Qt6::WaylandCompositorIviapplicationplugin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Qt6::WaylandCompositorIviapplicationplugin PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/qml/QtWayland/Compositor/IviApplication/libwaylandcompositoriviapplicationplugin.so"
  IMPORTED_NO_SONAME_RELEASE "TRUE"
  )

list(APPEND _cmake_import_check_targets Qt6::WaylandCompositorIviapplicationplugin )
list(APPEND _cmake_import_check_files_for_Qt6::WaylandCompositorIviapplicationplugin "${_IMPORT_PREFIX}/qml/QtWayland/Compositor/IviApplication/libwaylandcompositoriviapplicationplugin.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
