QT.waylandglobal_private.VERSION = 6.8.2
QT.waylandglobal_private.name = QtWaylandGlobal
QT.waylandglobal_private.module = 
QT.waylandglobal_private.libs = $$QT_MODULE_LIB_BASE
QT.waylandglobal_private.ldflags = 
QT.waylandglobal_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtWaylandGlobal $$QT_MODULE_INCLUDE_BASE/QtWaylandGlobal/6.8.2 $$QT_MODULE_INCLUDE_BASE/QtWaylandGlobal/6.8.2/QtWaylandGlobal
QT.waylandglobal_private.frameworks = 
QT.waylandglobal_private.bins = $$QT_MODULE_BIN_BASE
QT.waylandglobal_private.depends =  
QT.waylandglobal_private.uses = 
QT.waylandglobal_private.module_config = v2 internal_module
QT.waylandglobal_private.CONFIG = no_link
QT.waylandglobal_private.DEFINES = QT_WAYLANDGLOBAL_LIB
QT.waylandglobal_private.enabled_features = 
QT.waylandglobal_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += waylandglobal_private

