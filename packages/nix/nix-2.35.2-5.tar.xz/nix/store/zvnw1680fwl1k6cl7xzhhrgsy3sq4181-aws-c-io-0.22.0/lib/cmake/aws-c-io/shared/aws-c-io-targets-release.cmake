#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AWS::aws-c-io" for configuration "Release"
set_property(TARGET AWS::aws-c-io APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AWS::aws-c-io PROPERTIES
  IMPORTED_LOCATION_RELEASE "/nix/store/zvnw1680fwl1k6cl7xzhhrgsy3sq4181-aws-c-io-0.22.0/lib/libaws-c-io.so.1.0.0"
  IMPORTED_SONAME_RELEASE "libaws-c-io.so.1.0.0"
  )

list(APPEND _cmake_import_check_targets AWS::aws-c-io )
list(APPEND _cmake_import_check_files_for_AWS::aws-c-io "/nix/store/zvnw1680fwl1k6cl7xzhhrgsy3sq4181-aws-c-io-0.22.0/lib/libaws-c-io.so.1.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
