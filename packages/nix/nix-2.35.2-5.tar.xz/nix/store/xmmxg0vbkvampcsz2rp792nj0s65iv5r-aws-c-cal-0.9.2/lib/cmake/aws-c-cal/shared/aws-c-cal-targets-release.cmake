#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AWS::aws-c-cal" for configuration "Release"
set_property(TARGET AWS::aws-c-cal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AWS::aws-c-cal PROPERTIES
  IMPORTED_LOCATION_RELEASE "/nix/store/xmmxg0vbkvampcsz2rp792nj0s65iv5r-aws-c-cal-0.9.2/lib/libaws-c-cal.so.1.0.0"
  IMPORTED_SONAME_RELEASE "libaws-c-cal.so.1.0.0"
  )

list(APPEND _cmake_import_check_targets AWS::aws-c-cal )
list(APPEND _cmake_import_check_files_for_AWS::aws-c-cal "/nix/store/xmmxg0vbkvampcsz2rp792nj0s65iv5r-aws-c-cal-0.9.2/lib/libaws-c-cal.so.1.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
