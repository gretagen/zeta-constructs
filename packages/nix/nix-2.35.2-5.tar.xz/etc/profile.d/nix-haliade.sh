# Haliade system: expose the system nix profile on PATH for every login shell,
# so packages declared in definition.lua's ["nixpkgs"] (applied as root)
# are runnable by all users. Sourced after nix.sh alphabetically, so a
# user's own ~/.nix-profile takes precedence over the system profile.
case ":${PATH:-}:" in
  *:/nix/var/nix/profiles/default/bin:*) ;;
  *) PATH="/nix/var/nix/profiles/default/bin${PATH:+:$PATH}" ;;
esac
export PATH
