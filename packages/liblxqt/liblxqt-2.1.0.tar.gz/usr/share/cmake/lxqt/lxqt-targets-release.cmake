#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lxqt" for configuration "Release"
set_property(TARGET lxqt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(lxqt PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblxqt.so.2.1.0"
  IMPORTED_SONAME_RELEASE "liblxqt.so.2"
  )

list(APPEND _cmake_import_check_targets lxqt )
list(APPEND _cmake_import_check_files_for_lxqt "${_IMPORT_PREFIX}/lib/liblxqt.so.2.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
