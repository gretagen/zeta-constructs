#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6XdgIconLoader" for configuration "Release"
set_property(TARGET Qt6XdgIconLoader APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Qt6XdgIconLoader PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libQt6XdgIconLoader.so.4.1.0"
  IMPORTED_SONAME_RELEASE "libQt6XdgIconLoader.so.4"
  )

list(APPEND _cmake_import_check_targets Qt6XdgIconLoader )
list(APPEND _cmake_import_check_files_for_Qt6XdgIconLoader "${_IMPORT_PREFIX}/lib/libQt6XdgIconLoader.so.4.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
