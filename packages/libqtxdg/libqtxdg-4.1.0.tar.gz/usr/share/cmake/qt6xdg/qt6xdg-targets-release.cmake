#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6Xdg" for configuration "Release"
set_property(TARGET Qt6Xdg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Qt6Xdg PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libQt6Xdg.so.4.1.0"
  IMPORTED_SONAME_RELEASE "libQt6Xdg.so.4"
  )

list(APPEND _cmake_import_check_targets Qt6Xdg )
list(APPEND _cmake_import_check_files_for_Qt6Xdg "${_IMPORT_PREFIX}/lib/libQt6Xdg.so.4.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
