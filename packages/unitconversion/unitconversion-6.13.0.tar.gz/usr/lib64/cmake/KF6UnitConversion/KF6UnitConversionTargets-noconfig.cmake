#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::UnitConversion" for configuration ""
set_property(TARGET KF6::UnitConversion APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KF6::UnitConversion PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Network;KF6::I18n"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib64/libKF6UnitConversion.so.6.13.0"
  IMPORTED_SONAME_NOCONFIG "libKF6UnitConversion.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::UnitConversion )
list(APPEND _cmake_import_check_files_for_KF6::UnitConversion "${_IMPORT_PREFIX}/lib64/libKF6UnitConversion.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
