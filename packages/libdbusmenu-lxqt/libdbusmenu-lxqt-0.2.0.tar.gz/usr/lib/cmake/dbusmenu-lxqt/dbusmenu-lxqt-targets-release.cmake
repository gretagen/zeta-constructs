#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dbusmenu-lxqt" for configuration "Release"
set_property(TARGET dbusmenu-lxqt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(dbusmenu-lxqt PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libdbusmenu-lxqt.so.0.2.0"
  IMPORTED_SONAME_RELEASE "libdbusmenu-lxqt.so.0"
  )

list(APPEND _cmake_import_check_targets dbusmenu-lxqt )
list(APPEND _cmake_import_check_files_for_dbusmenu-lxqt "${_IMPORT_PREFIX}/lib/libdbusmenu-lxqt.so.0.2.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
