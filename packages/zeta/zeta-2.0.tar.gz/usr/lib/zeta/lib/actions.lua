-- actions.lua -- command handlers. Thin wiring between the CLI, dependency
-- resolution, the builder, and the database. All confirmation prompts honor
-- the --pass flag (skip Y/N and proceed immediately).
--
-- Install/delete commands accept one or more package names and operate on
-- each one in turn, stopping at the first hard failure. Installed state is
-- split into explicit "packages" and auto-installed "dependencies"; -Delete
-- warns about dependents and --with-deps cascades into orphaned
-- dependencies.

local actions = {}

local config = require("config")
local log = require("log")
local path = require("path")
local db = require("db")
local repo = require("repo")
local deps = require("deps")
local builder = require("builder")
local manifest = require("manifest")
local vercmp = require("vercmp")
local hooks = require("hooks")
local fetch = require("fetch")
local spinner = require("spinner")
local reserve = require("reserve")
local quotes = require("quotes")
local profile = require("profile")

local HELP = [[

                                                           
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                    %%%%%%%%%%%%%%%%%%                     
                           %%%                             
                           %%%                             
                           %%%                             
                           %%%                             
                           %%%               %             
                           %%%%             %%%            
      %%%%%%%%%%%        %%%@@%%%%         %%%%%           
     %%%%%%%%%%%%%%   %%%%%%   %%%%%%     %%%%%%%          
    %%%%%%%%%%%%%%%%%%%%%         %%%%%% %%%%%%%%%         
   %%%%%%%%%%%%%%%%%%%               %%%%%%%%%%%%%%        
   %%%%%%%%%%%%%%%%%%                  %%%%%%%%%%%%%       
   %%%%%%%%%%%%%%%%%                  %%%%%%%%%%%%%%%      
    %%%%%%%%%%%%%%%%                %%%%%%%%%%%%%%%%%%     
     %%%%%%%%%%%%%                 %%%%%%%%%%%%%%%%%%%%    
       %%%%%%%%%                  %%%%%%%%%%%%%%%%%%%%%%   
                                                           
                                                           

zeta | construct management system of Haliade

Usage: zeta <command> [arguments] [flags]

Commands:
  -Provide <pkg>...       Provide constructs and their dependents from the remote repository
  -ReProvide <pkg>...     Reinstall constructs even if they are already installed
  -LocalProvide <pkg>...  Install constructs from the local /packages tree
  -Solve <pkg>...         Repair a construct by reproviding its direct
                          dependents (the construct itself is left intact).
                          With --isolate, rebuild its whole reserved store
                          instead.
  -Transcend              Transcend all provided constructs to their latest versions
  -Delete <pkg>...        Delete constructs (see --with-deps)
  -List <registry>        List installed constructs and dependents
                          For listing, you must provide precisely 1 registery
                          supported registeries : constructs, depends, isolated
                          To show all registeries at once, use "all"

  -Localize <query>       Search the index of constructs
  -Test <pkg>             Verify a construct offline WITHOUT installing it
  -Forget                 Delete all cached constructs
  -Help                   Show this help

Flags:
  --pass                  Proceed immediately with an action
  --force                 Force an operation
  --with-deps             Paired with -Delete, also delete dependents that are no longer
                          required by any installed construct (never deletes constructs
                          installed explicitly)
  --silence               Suppress tar extraction file listings
  --isolate               With -Provide/-ReProvide/-LocalProvide: install into a
                          self-contained store at <root>/zeta/reserve/<pkg>-<version>
                          (construct + full dependency closure, exposed through
                          <root>/zeta/reserve/profile/bin and linked into
                          /usr/bin / /usr/sbin, skipping names already taken).
                          With -Solve: rebuild that store in place.
                          With -Delete: delete the isolated store instead of
                          the system copy.
  --no-quote              Disable random startup quotes
  --jobs=N                How many constructs may be provided at the same time
                          (default: 2; `jobs = nproc` in the config file
                          uses every core)

Configuration:
  /etc/zeta/configuration.lua   System-wide configuration

  Example:

    return {
      repos = {
        "https://github.com/gretagen/zeta-index",
        "https://github.com/gretagen/declarative-plugins",
      },
      root = "/",
      verbose = false,
      quotes = false,
      jobs = nproc, -- every core (or a plain number)
      -- Constructs -Solve never reinstalls. REPLACES the built-in list
      -- (glibc, ncurses, bash, gcc, openssl, ...), so copy those names
      -- first if you want to extend it rather than swap it out.
      do_not_solve = { "glibc", "ncurses" },
    }

Installed state is tracked in three registries under /var/db/zeta:
  packages/<name>      every construct you installed explicitly
  dependencies/<name>  constructs pulled in automatically as dependencies
  isolated/<name>      constructs installed with --isolate (meta carries reserve_root)

Environment:
  ZETA_ROOT            Filesystem root constructs are installed into   (default: /)
  ZETA_REPOS           Remote repository URLs, space-separated, tried in order  (default: https://github.com/gretagen/zeta-index)
  ZETA_REPO            Single remote repo base URL (one-entry ZETA_REPOS)  (default: https://github.com/gretagen/zeta-index)
                       raw.githubusercontent.com)
  ZETA_LOCAL_PACKAGES  Local /packages tree                          (default: /usr/share/packages)
  ZETA_CACHE           Download cache                                (default: $ZETA_ROOT/var/cache/zeta)
  ZETA_STATE           Construct database                              (default: $ZETA_ROOT/var/db/zeta)
  ZETA_VERBOSE         Verbose output (1 or true to enable)          (default: false)
  ZETA_RESERVE         Isolated construct store location               (default: $ZETA_ROOT/zeta/reserve)
  ZETA_JOBS            Constructs provided at the same time (or "nproc")  (default: 2)

Construct format (one package.lua per construct, returning a table):
  return {
    name="glib", version="2.88.1", url="https://.../glib-2.88.1.tar.xz",
    sha256="...", deps={"libffi","pcre2"},
    archive={ strip=1 },          -- binary install: fetch, unpack, install
    -- or: install=function(p) ... end,   or: build=function(p) ... end
    test=function(p) ... end,     -- optional verification hook for -Test
  }

-Test runs the package's full pipeline (fetch, checksum, unpack/build) into a
scratch directory and then runs its `test` hook when declared; without a hook
it passes on payload integrity plus a non-empty staging tree. It is strictly
offline and never installs anything or touches the package database.
]]

function actions.help()
	io.write(HELP)
end

-- Y/N confirmation. --pass skips it. Returns true to proceed.
-- When `default_no` is true, an empty line cancels (default: " [y/N]").
-- Otherwise an empty line proceeds (default: " [Y/n]").
local function confirm(msg, pass, suffix, default_no)
  suffix = suffix or (default_no and "  Proceed? [y/N]" or "  Proceed? [Y/n]")
  if pass then
    return true
  end
  io.write(msg .. suffix .. " ")
  io.flush()
  local line = io.read("*l")
  if not line then
    return false
  end
  line = line:lower()
  if line == "" then return not default_no end
  return line == "y" or line == "yes"
end

-- Closing lines of a completed run: the completion banner, a random success
-- quote (unless quotes are disabled), and what was done in parentheses.
local function finish(done_line)
	log.step("Complete.")
	if quotes.is_enabled() then
		local q = quotes.pick(quotes.success)
		if q then print(q) end
	end
	print(done_line)
end

-- Post-install sanity check: run ldd over the package's binaries and report
-- any shared library that does not resolve. Non-fatal by design -- a missing
-- library is a packaging problem to report, not a failed install.
local function check_libraries(files, root)
	local bins = {}
	for _, rel in ipairs(files or {}) do
		if rel:match("^usr/bin/") or rel:match("^usr/sbin/")
			 or rel:match("^bin/") or rel:match("^sbin/") then
			bins[#bins + 1] = path.join(root, rel)
		end
	end
	if #bins == 0 then return end
	-- No ldd on this system: skip the check quietly.
	local probe = path.popen("command -v ldd 2>/dev/null")
	if not probe then return end
	local where = probe:read("*l")
	probe:close()
	if not where or where == "" then return end

	log.step("Checking if libraries behave fine.")
	local unresolved = {}
	for _, bin in ipairs(bins) do
		if #bins > 1 then log.detail(bin) end
		local f = path.popen("ldd " .. path.quote(bin) .. " 2>/dev/null")
		if f then
			for line in f:lines() do
				print(line)
				local name = line:match("^%s*(%S+)%s+=>%s+not found")
				if name then unresolved[#unresolved + 1] = name end
			end
			f:close()
		end
	end
	if #unresolved > 0 then
		log.warn(("%d Library(ies) aren't unresolved, you may need to report to construct maintenance."):format(#unresolved))
		print(("unresolved libraries: %s,"):format(table.concat(unresolved, ", ")))
	else
		log.ok("All libraries have been resolved.")
	end
end

-- The database kind for a plan item: the explicit target becomes a package
-- unless it already lives as a dependency (a -ReProvide of a dependency stays
-- a dependency); every other item becomes a dependency unless it is already
-- an explicitly installed package (never demoted).

local function plan_kind(item, target)
	local cur = db.kind(item)
	if item == target then
		return (cur == "dependency") and "dependency" or "package"
	end
	return (cur == "package") and "package" or "dependency"
end

-- The pre-target extract row: one line that rewrites in place while every
-- dependency (or upgrade) stages, showing the phase, its own counter and the
-- entry being extracted.
--
-- Narration is gated off for the duration because any print between two
-- redraws would push the row down and make it repaint on a new line; member
-- listings are gated off through the same switch --silence uses
-- (log.is_file_silent), so tar/Arch/.deb/zip all inherit it. Only step and
-- detail are gated: error/warn/ok/info stay live, and they settle the row
-- first through log.on_settle so a failure never lands on top of it.
--
-- Returns draw(i, label) and finish(completed). finish() settles the row and
-- restores every gate, so callers call it on both the success and the failure
-- path; pass `completed` on success so the row is repainted in its finished
-- colour first -- a failure must never leave a green "all done" line behind.

local function begin_extract_row(noun, total)
	local prev_silent = log.is_file_silent()
	local prev_narration = log.set_narration(false)
	log.set_file_silent(true)
	local tty = spinner.enabled()

	-- row_open: a row has been written but not newline-terminated. animated: a
	-- background loop is drawing it, so settle has to kill it (keeping what it
	-- drew) instead of just ending the line.

	local row_open = false
	local animated = false
	local last_label

	-- The row body: everything that follows the meter. `label` is nil for the
	-- opening [ 0/N ] state so the line does not end in a space.
	--
	-- The progress number is cyan while dependencies land and green only once
	-- every one of them has staged. Completion is passed in explicitly rather
	-- than derived from `i >= total`: with a single dependency that test is
	-- already true on the first (and only) iteration, which would turn the row
	-- green while it was still extracting. The total stays cyan and the label
	-- is grey, matching the colours the provide counter uses.

	local function body(i, label, completed)
		local s = (" - Extracting %s... [ %s/%s ]"):format(noun,
			log.paint(completed and "green" or "cyan", tostring(i)),
			log.paint("cyan", tostring(total)))
		if label then s = s .. " " .. log.paint("dim", label) end
		return s
	end

	-- Settle the row: kill the animation (TTY) or end the line (piped).
	-- keep_row leaves whatever the meter last drew in place as a record of the
	-- phase. Wired into log so a warn/error printed mid-extraction never lands
	-- on top of the live row; finish() calls it too, and both no-op once
	-- settled.

	local function settle()
		if not row_open then return end
		row_open = false
		if animated then
			animated = false
			spinner.stop(true)
		else
			io.write("\n")
		end
	end
	log.on_settle(settle)

	-- Paint the row: the meter animates at column 0 on a terminal, and is
	-- frozen to its first frame when output is going somewhere piped. Clearing
	-- first also drops any row left over from an earlier phase, so start_row
	-- always gets the line to itself.
	local function paint(post, animate)
		local animate_row = tty and animate
		if tty then spinner.stop() end
		if animate_row then
			spinner.start_row("", post)
		else
			io.write("\r\27[K" .. spinner.METRO[1] .. post)
			io.flush()
		end
		animated = animate_row
		row_open = true
	end

	paint(body(0, nil, false), true)

	local function draw(i, label)
		last_label = label
		paint(body(i, label, false), true)
	end

	local function finish(completed)
		if completed then paint(body(total, last_label, true), false) end
		settle()
		log.on_settle(nil)
		log.set_narration(prev_narration)
		log.set_file_silent(prev_silent)
	end

	return draw, finish
end

-- Space preflight before the extract phase. Every payload is unpacked into
-- tmp_dir up front, and on HaliadeSYS that directory sits on a tmpfs -- a
-- set that cannot fit there dies halfway through extraction instead of
-- failing up front with a hint. Warn only: payloads can shrink on extract
-- (xz/gz), and the remedy is one environment variable away.
local function warn_stage_fit(payloads)
	local total = 0
	for _, p in ipairs(payloads) do
		local f = io.open(p, "rb")
		if f then
			total = total + (f:seek("end") or 0)
			f:close()
		end
	end
	if total == 0 then return end
	local tmp = config.get().tmp_dir
	local df = path.popen("df -Pk " .. path.quote(tmp) .. " 2>/dev/null")
	local avail_kb
	if df then
		for line in df:lines() do
			local _, _, avail = line:match("%s(%d+)%s+(%d+)%s+(%d+)%s+%d+%%")
			if avail then avail_kb = tonumber(avail) end
		end
		df:close()
	end
	if not avail_kb then return end
	if total > avail_kb * 1024 * 0.8 then
		log.warn(("payloads total ~%d MB but only %d MB is free in %s -- extraction may run out of space (set ZETA_TMP to a disk-backed directory if this is a tmpfs)"):format(
			math.floor(total / 1048576), math.floor(avail_kb / 1024), tmp))
	end
end

-- Shared install flow for -Provide / -LocalProvide / -ReProvide / -Solve.
-- flags.isolate: install into a self-contained store under the reserve dir
-- (package + full dependency closure), exposed through the profile bin dir.
-- flags.solve: reinstall a package's dependencies without touching the target.
-- In system mode only the target's direct dependencies are reinstalled; with
-- --isolate the whole store is rebuilt as a unit (target included).

function actions._install(name, flags, opts)
	profile.mark("resolve")
	local source = opts.source
	local base = config.get().local_packages
	local isolate = flags.isolate == true
	local solve = flags.solve == true
	-- -Solve (system) repairs a package by reinstalling only what it depends on
	-- directly; an isolated store is a self-contained unit, rebuilt whole.
	local direct_only = solve and not isolate

	local fetch_manifest
	if source == "local" then
		-- Local packages resolve from the local tree; deps missing there fall
		-- back to the remote repository, so mixed trees keep working.
		fetch_manifest = function(n)
			local m, err = manifest.load(path.join(base, n, "package.lua"))
			if m then
				local ok, cerr = manifest.check_name(m, n)
				if not ok then
					return nil, cerr
				end
				m._local_dir = path.join(base, n)
				return m
			end
			log.detail(("local construct %q not found, falling back to remote"):format(n))
			return repo.fetch_manifest(n)
		end
	else
		fetch_manifest = function(n)
			return repo.fetch_manifest(n)
		end
	end

	-- Prefetch all manifests in parallel (breadth-first discovery).
	-- This replaces sequential per-package fetching with a single batch
	-- download, significantly speeding up dependency resolution.

	local manifest_cache = {}
	local seen = { [name] = true }
	local queue = { name }
	local cfg = config.get()

	while #queue > 0 do
		local batch = {}
		for _, n in ipairs(queue) do
			-- Isolated installs and -Solve prefetch everything: a system-installed
			-- dep does not satisfy a self-contained store, and -Solve must be able
			-- to rebuild already-installed deps.
			if not manifest_cache[n] and (isolate or solve or not db.is_installed(n)) then
				batch[#batch + 1] = n
			end
		end
		queue = {}

		if #batch > 0 then
			local items = {}
			for _, n in ipairs(batch) do
				items[#items + 1] = {
					url = repo.manifest_url(n),
					dest = path.join(cfg.tmp_dir, "prefetch-" .. n .. "-" .. tostring(math.random(10000, 99999)) .. ".lua"),
					_name = n,
				}
			end

	local results = fetch.get_parallel(items)
			for i, result in ipairs(results) do
				local n = batch[i]
				if result.dest then
					local f = io.open(result.dest, "rb")
					if f then
						local src = f:read("*a")
						f:close()
						os.remove(result.dest)
						local m, merr = manifest.load_string(src, repo.manifest_url(n))
						if m then
							local ok, cerr = manifest.check_name(m, n)
							if ok then
								manifest_cache[n] = m
								-- -Solve (system) only needs the target's direct
								-- deps, so stop the walk after the first level.
								if not direct_only or n == name then
									for _, dep in ipairs(m.deps or {}) do
										if not seen[dep.name] then
											seen[dep.name] = true
											queue[#queue + 1] = dep.name
										end
									end
								end
							end
						end
					end
				end
			end
			-- Multi-repo: the parallel prefetch only knows the first
			-- repository, so any package that lives in a later one (or a
			-- local tree) is resolved here serially before the next BFS
			-- round. Manifests are tiny, so this only costs the missers.
			for _, n in ipairs(batch) do
				if not manifest_cache[n] then
					local m = fetch_manifest(n)
					if m then
						manifest_cache[n] = m
						if not direct_only or n == name then
							for _, dep in ipairs(m.deps or {}) do
								if not seen[dep.name] then
									seen[dep.name] = true
									queue[#queue + 1] = dep.name
								end
							end
						end
					end
				end
			end
		end
	end

	-- what a zigzag holy

	-- Wrap fetch_manifest with the prefetch cache.
	local function cached_fetch_manifest(n)
		if manifest_cache[n] then return manifest_cache[n] end
		return fetch_manifest(n)
	end

	spinner.start("Resolving dependents")
	local target_manifest
	local ok, plan
	if direct_only then
		-- -Solve repairs the target by reinstalling only the packages
		-- it directly depends on. The target itself and everything deeper in
		-- the tree are left untouched.
		ok = true
		plan = {}
		target_manifest = cached_fetch_manifest(name)
		if not target_manifest then
			ok, plan = false, ("cannot resolve package %q"):format(name)
		else
			-- Base libraries are never reinstalled from here: swapping them
			-- under a running system is what makes every later shell print
			-- "no version information available". `direct_only` is only true
			-- when not isolating, so the isolate exemption is already handled
			-- by that flag. Skipping before the fetch also avoids pulling the
			-- manifest for a dep we are not going to touch.
			local protected = config.get().do_not_solve
			for _, dep in ipairs(target_manifest.deps or {}) do
				if protected[dep.name] then
					log.detail(("skipping %s as solving it would just break the system"):format(dep.name))
				else
					local m = cached_fetch_manifest(dep.name)
					if not m then
						ok, plan = false, ("can not resolve dependent %q"):format(dep.name)
						break
					end
					plan[#plan + 1] = { name = dep.name, manifest = m }
				end
			end
		end
	else
		ok, plan = pcall(deps.resolve, name, {
			fetch_manifest = cached_fetch_manifest,
			installed_version = function(n)
				-- An isolated store is self-contained: it gets its own copy of
				-- the whole closure instead of accepting system-installed deps.
				-- if you've ever used Nix or Guix, you may already know that
				if isolate then return nil end
				local m = db.get(n)
				return m and m.version or nil
			end,
		})
		if ok and #plan > 0 then
			target_manifest = plan[#plan].manifest
		end
	end
	spinner.stop()
	if not ok then
		log.error(tostring(plan))
		return 1
	end
	if #plan == 0 then
		if solve then
			log.info(("no dependents to reprovide for %s"):format(name))
		end
		return 0
	end

	-- Identify which repo the target package belongs to by inspecting the
	-- manifest URL. The repo name lives in the path between the host and the
	-- packages/ prefix: .../zeta-<kind>/.../<name>/package.lua
	if target_manifest and target_manifest.url then
		local repo_name = target_manifest.url:match("zeta%-([^/]+)")
		if repo_name then
			log.step("Core construct found at: zeta-" .. repo_name)
		end
	end

	-- Isolated install: the store path is derived from the target's version.
	local store
	if isolate then
		store = reserve.store_path(name, target_manifest and target_manifest.version)
	end

	local verb = solve and "will reprovide" or "will provide"
	for _, item in ipairs(plan) do
		print(("  %s %s-%s"):format(verb, item.name, item.manifest.version))
	end
	if isolate then
		print(("  isolated at %s"):format(store))
	end
	print("")

	local confirm_msg
	if solve and isolate then
		confirm_msg = ("Reconstruct the isolated store at %s (%d constructs)?"):format(store, #plan)
	elseif solve then
		confirm_msg = ("Solve the %d direct dependents of %s?"):format(#plan, name)
	elseif isolate then
		confirm_msg = ("Provide %d construct(s) isolated at %s?"):format(#plan, store)
	else
		confirm_msg = ("Provided %d construct(s)?"):format(#plan)
	end
	-- Wow fancy words
	-- The plan is on screen: end resolve here so time spent thinking at the
	-- prompt is not billed to any phase (the receipt reports work, not you).
	profile.close()
	if not confirm(confirm_msg, flags.pass) then
		log.abort("aborted by user")
		return 0
	end
	profile.mark("fetch")

	local installed = {}
	local pre_fetched = {}

	-- Phase 1: Resolve and download all payloads in parallel.
	local fetch_items = {}
	for _, item in ipairs(plan) do
		if isolate or not (db.is_installed(item.name) and not flags.force) then
			local info, err = builder.fetch_payload(item.manifest, {
				local_dir = item.manifest._local_dir,
			})
			if info then
				if info.cached then
					pre_fetched[item.name] = info.cached
				elseif info.url then
					fetch_items[#fetch_items + 1] = {
						url = info.url,
						dest = info.dest,
						label = item.manifest.name .. "-" .. item.manifest.version,
						_name = item.name,
					}
				end
			elseif err then
				log.warn(("could not resolve payload for %s: %s"):format(item.name, tostring(err)))
			end
		end
	end

	if #fetch_items > 0 then
		local results = fetch.get_parallel(fetch_items)
		for i, result in ipairs(results) do
			local item_name = fetch_items[i]._name
			if result.err then
				log.error(("download failed for %s: %s"):format(item_name, result.err))
				return 1
			elseif result.dest then
				pre_fetched[item_name] = result.dest
			end
		end
	end

	-- The work list: everything that is really going to be staged. An isolated
	-- install stages the whole plan; a system install skips what is already
	-- provided (unless --force says otherwise).
	local todo = {}
	for _, item in ipairs(plan) do
		if isolate or not (db.is_installed(item.name) and not flags.force) then
			todo[#todo + 1] = item
		else
			log.warn(("%s already provided, skipping"):format(item.name))
		end
	end

	-- Phase 2: Verify every downloaded payload before touching the system:
	-- a corrupt archive aborts here, with nothing extracted or committed.
	profile.mark("verify")
	local verify_items = {}
	for _, item in ipairs(todo) do
		verify_items[#verify_items + 1] = {
			manifest = item.manifest,
			payload = pre_fetched[item.name],
		}
	end
	local vok, verr = pcall(builder.verify_all, verify_items)
	if not vok then
		log.error(tostring(verr))
		return 1
	end
	warn_stage_fit((function()
		local ps = {}
		for _, it in ipairs(verify_items) do
			if it.payload then ps[#ps + 1] = it.payload end
		end
		return ps
	end)())
	profile.mark("extract")

	-- A store is self-contained: nothing outside references its internals
	-- (only profile wrappers, recreated below), so a reinstall starts clean.
	-- Wiped only after the user confirmed AND every payload checked out.
	-- Wrappers of the previous incarnation go first so a version upgrade
	-- cannot leave stale entries pointing at a store that no longer exists.
	if isolate then
		log.step("starting essentials.")
		local old = db.isolated_meta(name)
		if old and old.reserve_root then
			-- System links first: they are attributed by reading the wrapper
			-- body, so the wrappers must still exist when we scan.
			local nl = reserve.unlink_system(old.reserve_root)
			if nl > 0 then
				log.detail(("deleted %d system link(s) from a previous install"):format(nl))
			end
			local n = reserve.unlink_profile(old.reserve_root)
			if n > 0 then
				log.detail(("deleted %d stale profile wrapper(s)"):format(n))
			end
			if old.reserve_root ~= store then
				local ok, err = reserve.delete_store(old.reserve_root)
				if not ok then log.warn(tostring(err)) end
			end
		end
		if path.exists(store) then
			log.detail(("clearing previous store at %s"):format(store))
			path.run("rm -rf " .. path.quote(store))
		end
	end

	-- Phase 3: Extract and build every package into its staging tree. Nothing
	-- commits until every package has been staged successfully.
	--
	-- Two phases, each with its own counter: the dependencies stage behind one
	-- row that rewrites in place, then the last archive extracts alone with
	-- its member listing -- that final listing is the package the user
	-- actually asked for. --silence still suppresses it.
	local staged = {}
	local total = #todo
	local n_deps = total - 1

	if n_deps > 0 then
		local draw, finish = begin_extract_row("dependents", n_deps)
		for i = 1, n_deps do
			local item = todo[i]
			local m = item.manifest
			local payload = pre_fetched[item.name]
			draw(i, payload and path.basename(payload) or (m.name .. "-" .. m.version))
			local sok, staged_item = pcall(builder.stage_one, m, {
				local_dir = m._local_dir,
				payload = payload,
				verified = true,
			})
			if not sok then
				finish()
				for _, s in pairs(staged) do builder.discard_staged(s) end
				log.error(tostring(staged_item))
				return 1
			end
			staged[item.name] = staged_item
		end
		finish(true)
	end

	-- The last archive: the member listing the user asked for. Guarded --
	-- `todo` is empty when every plan item was already provided and nothing
	-- was --force'd, and todo[0] would be nil.
	if total > 0 then
		local last = todo[total]
		local m = last.manifest
		local payload = pre_fetched[last.name]
		log.step(("Extracting %s... - [ 1/1 ]"):format(
			payload and path.basename(payload) or (m.name .. "-" .. m.version)))
		local sok, staged_item = pcall(builder.stage_one, m, {
			local_dir = m._local_dir,
			payload = payload,
			verified = true,
		})
		if not sok then
			for _, s in pairs(staged) do builder.discard_staged(s) end
			log.error(tostring(staged_item))
			return 1
		end
		staged[last.name] = staged_item
	end

	-- Phase 4: Commit and record each staged package. Up to N provides run at
	-- a time; the next one starts as soon as a slot frees.
	profile.mark("commit")
	local commit_items = {}
	for _, item in ipairs(todo) do
		commit_items[#commit_items + 1] = {
			manifest = item.manifest,
			staged = staged[item.name],
			kind = plan_kind(item.name, name),
			source = source,
			isolate_root = store,
			-- Only the target is registered; its deps are store internals
			-- and disappear with the store on deletion.
			record = (not isolate) or item.name == name,
			-- The target's "provided" line is folded into the closing block.
			announce = item.name ~= name,
		}
	end
	local cok, cerr = builder.commit_all(commit_items, {
		force = flags.force,
		jobs = flags.jobs or config.get().jobs,
	})
	profile.close()
	if not cok then
		log.error(tostring(cerr))
		return 1
	end
	for _, item in ipairs(todo) do
		installed[item.name] = true
	end

	-- Isolated: stamp the store's ELF objects with store RPATHs (so wrappers
	-- can stay env-free), expose the target's own binaries through the
	-- profile, then link them into the FHS system bin dirs so they run from
	-- the default PATH.
	if isolate then
		local patched = reserve.patch_rpaths(store)
		if patched then
			log.ok(("%d ELF object(s) stamped with store RPATHs"):format(patched))
		end
		local files = db.isolated_files(name)
		local created = reserve.link_profile(store, files)
		if #created > 0 then
			log.ok(("%d binary/binaries exposed in %s/profile/bin"):format(
				#created, config.get().reserve_dir))
		end
		local sys = reserve.link_system(store, files)
		if sys.linked > 0 then
			log.ok(("%d binary/binaries linked into %s"):format(
				sys.linked, path.join(config.get().root, "usr/bin")))
		end
	end

	-- Library resolution check: ldd over the target's binaries. Non-fatal.
	check_libraries(isolate and db.isolated_files(name) or db.files(name),
		isolate and store or config.get().root)

	-- Post-transaction hooks (deps already present on disk at this point).
	-- Isolated stores never run host hooks: hooks are system-level.
	if next(installed) and not isolate then
		local hfail = pcall(hooks.run_installed, installed)
		if not hfail then
			log.error("hook runner failed")
		end
	end

	finish(("(provided %s-%s)"):format(name, target_manifest and target_manifest.version or "?"))
	return 0
end

-- Shown when a normal (non-isolated) install targets a package that only
-- exists as an isolated store: the two registries are separate, and the user
-- must consciously drop the store before a system copy can replace it.
local ISOLATED_CONFLICT_MSG = ("this construct has already been provided as isolated! "
  .. "you will have to delete the isolated construct first before reproviding it normally, "
  .. "if you are sure about this, please use --force flag")

  -- wow stupid design I really gotta rewrite this

function actions.provide(names, flags)
	for _, raw in ipairs(names) do
		local name = path.sanitize_name(raw)
		if not name then
			log.error("construct name is not valid: " .. tostring(raw))
			return 1
		end
		-- Isolated stores live in their own registry: a normal install of an
		-- isolated package needs an explicit --force acknowledgment first.
		if not flags.isolate and not flags.force and db.isolated(name) then
			log.warn(ISOLATED_CONFLICT_MSG)
		else
			-- Isolated installs live in their own registry: a system copy does
			-- not block them (and vice versa).
			local already
			if flags.isolate then
				already = db.isolated(name)
			else
				already = db.is_installed(name)
			end
			if not flags.force and already then
				local m = flags.isolate and db.isolated_meta(name) or db.get(name)
				log.warn(("%s-%s has already been provided -- use -ReProvide instead, maybe you wanted to check if it was?"):format(name, m and m.version or "?"))
			else
				local ok = actions._install(name, flags, { source = "remote" })
				if ok ~= 0 then
					return ok
				end
			end
		end
	end
	return 0
end

function actions.reprovide(names, flags)
	for _, raw in ipairs(names) do
		local name = path.sanitize_name(raw)
		if not name then
			log.error("invalid construct name: " .. tostring(raw))
			return 1
		end
		if not flags.isolate and not flags.force and db.isolated(name) then
			log.warn(ISOLATED_CONFLICT_MSG)
		else
			local ok = actions._install(name, {
				pass = flags.pass,
				force = true,
				isolate = flags.isolate,
			}, { source = "remote" })
			if ok ~= 0 then
				return ok
			end
		end
	end
	return 0
end

-- -Solve repairs a package by reinstalling its direct dependencies.
-- In system mode the target is left untouched; with --isolate the package's
-- self-contained store is rebuilt whole, target included.
function actions.solve(names, flags)
	local isolate = flags.isolate == true
	for _, raw in ipairs(names) do
		local name = path.sanitize_name(raw)
		if not name then
			log.error("invalid construct name: " .. tostring(raw))
			return 1
		end
		-- Repair targets an existing install: the two registries are separate,
		-- so point the user at the matching mode when they pick the wrong one.
		if isolate then
			if not db.isolated(name) then
				if db.kind(name) then
					log.error(("%s is provided normally -- use -Solve %s without --isolate."):format(name, name))
				else
					log.error(("%s is not provided as isolated -- provide it with -Provide %s --isolate first."):format(name, name))
				end
				return 1
			end
		else
			if not db.kind(name) then
				if db.isolated(name) then
					log.error(("%s is provided as isolated -- use -Solve %s --isolate."):format(name, name))
				else
					log.error(("%s has not been provided."):format(name))
				end
				return 1
			end
		end
		-- Replacing a base library under a running system floods every
		-- subsequent shell with "no version information available" --
		-- ZETA spawns shells for nearly every operation, so it ends up
		-- drowning in its own output. Isolated solves are exempt: they
		-- stage into /zeta/reserve/... and never touch the system copy.
		if not isolate and config.get().do_not_solve[name] then
			log.error(("%s is on the do-not-solve list; replacing it under a running system destabilises every linked process (use -ReProvide %s if you really mean to)"):format(name, name))
			return 1
		end
		local ok = actions._install(name, {
			pass = flags.pass,
			force = true,
			isolate = isolate,
			solve = true,
		}, { source = "remote" })
		if ok ~= 0 then
			return ok
		end
	end
	return 0
end

function actions.localprovide(names, flags)
	for _, raw in ipairs(names) do
		local name = path.sanitize_name(raw)
		if not name then
			log.error("invalid construct name: " .. tostring(raw))
			return 1
		end
		if not flags.isolate and not flags.force and db.isolated(name) then
			log.warn(ISOLATED_CONFLICT_MSG)
		else
			local already
			if flags.isolate then
				already = db.isolated(name)
			else
				already = db.is_installed(name)
			end
			if not flags.force and already then
				local m = flags.isolate and db.isolated_meta(name) or db.get(name)
				log.warn(("%s-%s has already been provided, you should -ReProvide instead, maybe you just wanted to check if it was?"):format(name, m and m.version or "?"))
			else
				local ok = actions._install(name, flags, { source = "local" })
				if ok ~= 0 then
					return ok
				end
			end
		end
	end
	return 0
end

-- A meta list (deps or dependents) as a table cell: names joined by spaces,
-- "-" when there is nothing to show. Both lists are stored as plain names
-- (db.record), so no shaping is needed.
local function cell(list)
	return (list and #list > 0) and table.concat(list, " ") or "-"
end

-- Rows in both directions: DEPENDENTS is what the entry needs (its
-- dependencies), ASSIGNED TO is what needs it (its dependents) -- either
-- column alone hides half the picture, so both are always printed. The rule
-- is sized from the header so it can never drift.
local function print_section(title, names)
	print(title)
	local header = ("%-20s %-16s %-24s %s"):format("CONSTRUCT", "VERSION", "DEPENDENTS", "ASSIGNED TO")
	print(header)
	print(string.rep("-", #header))
	for _, n in ipairs(names) do
		local m = db.get(n)
		print(("%-20s %-16s %-24s %s"):format(n, m and m.version or "?", cell(m and m.deps), cell(m and m.dependents)))
	end
end

local function print_isolated_section(names)
	print(("ISOLATED (%d)"):format(#names))
	print(("%-20s %-16s %s"):format("CONSTRUCT", "VERSION", "RESERVE"))
	print(string.rep("-", 60))
	for _, n in ipairs(names) do
		local m = db.isolated_meta(n)
		print(("%-20s %-16s %s"):format(n, m and m.version or "?", m and m.reserve_root or "?"))
	end
end

-- -List <registry> action: constructs | depends | isolated | all, they are all
-- resolved by cli.parse against  LIST_CANON (in lib/cli.lua). A named
-- registry always prints its header, even at (0), so the command answers
-- visibly; `all` keeps the historic behavior of skipping empty sections.
function actions.list(args)
	local which = args[1]
	if which == "all" then
		local packages = db.list_packages()
		local dependencies = db.list_dependencies()
		local isolated = db.list_isolated()
		if #packages == 0 and #dependencies == 0 and #isolated == 0 then
			log.info("no constructs provided")
			return 0
		end
		local first = true
		if #packages > 0 then
			print_section(("CONSTRUCTS (%d)"):format(#packages), packages)
			first = false
		end
		if #dependencies > 0 then
			if not first then print("") end
			print_section(("DEPENDENTS (%d)"):format(#dependencies), dependencies)
			first = false
		end
		if #isolated > 0 then
			if not first then print("") end
			print_isolated_section(isolated)
		end
		return 0
	end
	if which == "constructs" then
		local names = db.list_packages()
		print_section(("CONSTRUCTS (%d)"):format(#names), names)
	elseif which == "depends" then
		local names = db.list_dependencies()
		print_section(("DEPENDENTS (%d)"):format(#names), names)
	else -- "isolated"; cli.parse guarantees the value is Ubuntu's company (get it, cuz of canonical?)
		local names = db.list_isolated()
		print_isolated_section(names)
	end
	return 0
end

function actions.localize(query)
	local matches, err = repo.search(query)
	if not matches then
		log.error(tostring(err))
		return 1
	end
	if #matches == 0 then
		log.info(("no constructs match %q"):format(query))
		return 0
	end

	-- Newer indexes carry a per-entry `origin`. When absent (older index),
	-- resolve it from each package's manifest url in one batched pass so the
	-- REPO column is always filled.
	local missing = {}
	for _, m in ipairs(matches) do
		if not m.origin or m.origin == "" then
			missing[#missing + 1] = m.name
		end
	end
	if #missing > 0 then
		local resolved = repo.origins(missing)
		for _, m in ipairs(matches) do
			if not m.origin or m.origin == "" then
				m.origin = resolved[m.name] or "unknown"
			end
		end
	end

	-- Size columns to the actual rows: package names (e.g.
	-- nix-declarative-helper) and repository labels (e.g. declarative-plugins)
	-- can exceed the historical fixed widths, which would push SUMMARY out of
	-- line.
	local rows = {}
	for _, m in ipairs(matches) do
		rows[#rows + 1] = { m.name, m.version or "?", m.origin or "unknown", m.summary or "" }
	end

	local widths = { #"CONSTRUCT", #"VERSION", #"REPOSITORY" }
	for _, r in ipairs(rows) do
		for i = 1, 3 do
			if #r[i] > widths[i] then widths[i] = #r[i] end
		end
	end
	local fmt = ("%%-%ds %%-%ds %%-%ds %%s"):format(widths[1], widths[2], widths[3])
	local header = fmt:format("CONSTRUCT", "VERSION", "REPOSITORY", "SUMMARY")
	print(header)
	print(string.rep("-", math.max(#header, 84)))
	for _, r in ipairs(rows) do
		print(fmt:format(r[1], r[2], r[3], r[4]))
	end
	return 0
end

-- -Test <pkg>: strictly offline validation. Resolution is local-tree only
-- (no remote fallback) and any manifest whose payload is a remote url is
-- refused. Nothing is installed, committed, or recorded -- build + test run
-- against a scratch tree that is discarded afterwards.
function actions.test(name, flags)
	name = path.sanitize_name(name)
	if not name then
		log.error("invalid construct name")
		return 1
	end
	local base = config.get().local_packages

	local fetch_manifest = function(n)
		local dir = path.join(base, n)
		local m, err = manifest.load(path.join(dir, "package.lua"))
		if not m then
			return nil, ("package %q not found in local tree %s (offline test, no remote fallback)"):format(n, base)
		end
		local ok, cerr = manifest.check_name(m, n)
		if not ok then
			return nil, cerr
		end
		if m.url and m.url:match("^https?://") then
			return nil, ("offline test refused: %s-%s has a remote url %s"):format(m.name, m.version, m.url)
		end
		m._local_dir = dir
		return m
	end

	local ok, plan = pcall(deps.resolve, name, {
		fetch_manifest = fetch_manifest,
		installed_version = function(n)
			local m = db.get(n)
			return m and m.version or nil
		end,
	})
	if not ok then
		log.error(tostring(plan))
		return 1
	end
	if #plan == 0 then
		return 0
	end

	print("")
	for _, item in ipairs(plan) do
		print(("  will test %s-%s"):format(item.name, item.manifest.version))
	end
	print("")

	for _, item in ipairs(plan) do
		local tok, terr = pcall(builder.test, item.manifest, {
			local_dir = item.manifest._local_dir,
		})
		if not tok then
			log.error(tostring(terr))
			return 1
		end
	end
	return 0
end

-- System directories that must never be deleted. This is a safety net: even
-- if a package's file list contains these paths (due to legacy record-keeping),
-- delete_files will refuse to unlink or rmdir them.
-- DO NOT DELETE THE PROTECTED DIRECTORIES UNLESS YOU WANT TO DESTROY YO SHI

local PROTECTED_DIRS = {}
for _, d in ipairs({
  "/", "/bin", "/sbin", "/boot",
  "/usr", "/usr/bin", "/usr/sbin", "/usr/lib", "/usr/lib64", "/usr/share",
  "/etc", "/var", "/tmp", "/opt",
  "/dev", "/proc", "/sys", "/run",
  "/home", "/root", "/subspace", "/systems",
}) do
  PROTECTED_DIRS[d] = true
end

-- ANSI colors for the deletion progress line (mirrors commit.lua).
local function wants_color()
  local t = os.getenv("TERM")
  if not t or t == "" or t == "dumb" then return false end
  if os.getenv("NO_COLOR") then return false end
  return true
end
local DEL_COLOR = wants_color()
local DEL_C = {
  reset = "\27[0m",
  blue  = "\27[34m",
  green = "\27[32m",
  cyan  = "\27[36m",
  dim   = "\27[2m",
}
local function del_paint(color, s)
  if not DEL_COLOR then return s end
  return DEL_C[color] .. s .. DEL_C.reset
end

-- Unlink the owned files of an entry, skipping unsafe paths, protected
-- directories, and shared files, then prune now-empty parents.
-- `owner_index` is a prebuilt db.file_owner_index(), so shared-file checks
-- are O(1) lookups instead of full database rescans.
-- Non-verbose TTY mode renders a live progress line (like install does);
-- skip/verbose notes are buffered and flushed in one write afterwards.
local function delete_files(files, pkg_name, owner_index)
  local cfg = config.get()
  local root = cfg.root
  local verbose = cfg.verbose
  local use_tty = spinner.enabled()
  local dirs = {}
  local seen = {}
  local notes = {}
  local total = #files
  local done = 0
  local show_progress = use_tty and not verbose and total > 0

  for _, rel in ipairs(files) do
    if rel == "" or rel == "." or rel:match("^/") or rel:match("^%.%.")
       or rel:match("%.%.%/") then
      notes[#notes + 1] = ("skipping unsafe path %q"):format(rel)
    else
      local p = path.join(root, rel)
      if PROTECTED_DIRS[p] then
        notes[#notes + 1] = ("skipping protected directory %s"):format(rel)
      else
        local others = db.other_owners(pkg_name, rel, owner_index)
        if #others > 0 then
          notes[#notes + 1] = ("skipping %s (shared with %s)"):format(
            rel, table.concat(others, ", "))
        else
          os.remove(p)
          if verbose then
            notes[#notes + 1] = ("deleted %s"):format(rel)
          end
          local d = path.dirname(p)
          while d ~= "/" and d ~= "." and not seen[d] do
            seen[d] = true
            if not PROTECTED_DIRS[d] then
              dirs[#dirs + 1] = d
            end
            d = path.dirname(d)
          end
        end
      end
    end

    done = done + 1
    if show_progress then
      -- path.join, not the `p` below: that one is scoped to the else-branch
      -- above and would resolve to a global here.
      io.write(("\r\27[K%s - [ deleted %s | %s entries ] %s"):format(
        spinner.next_frame(),
        del_paint("blue", tostring(done)),
        del_paint("cyan", tostring(total)),
        del_paint("dim", path.join(root, rel))))
      io.flush()
    end
  end

  -- Final green count; replaces the live line.

  if show_progress then
    io.write(("\r\27[K%s - [ deleted %s | %s entries ]\n"):format(
      spinner.next_frame(),
      del_paint("green", tostring(total)),
      del_paint("cyan", tostring(total))))
    io.flush()
  end

  -- Skips and verbose notes in a single write (no per-line redraws).

  if #notes > 0 then
    log.detail_batch(notes)
  end

  table.sort(dirs, function(a, b)
    return #a > #b
  end)
  for _, d in ipairs(dirs) do
    os.remove(d) -- rmdir; silently fails when non-empty
  end
end

-- Helper: return reverse dependents of `name` that are NOT in `planned`.

local function remaining_dependents(name, planned)
  local out = {}
  for _, d in ipairs(db.reverse_dependents(name)) do
    if not planned[d] then
      out[#out + 1] = d
    end
  end
  return out
end

-- Determine the transitive set of dependency-kind entries that would
-- become orphaned if everything in `planned` were deleted.  `seed` gives the
-- starting deletion order (the explicit targets, dependents first).  Returns
-- two values: the full deletion order (seed then cascaded deps) and a table
-- of { dep = rd_list } for deps that were skipped because they are still
-- required by something outside the plan.

local function resolve_cascade(planned, seed)
  local order = {}
  for _, n in ipairs(seed) do
    order[#order + 1] = n
  end
  local skip = {}
  local i = 1
  while i <= #order do
    local n = order[i]
    local m = db.get(n)
    for _, dep in ipairs(m and m.deps or {}) do
      if db.kind(dep) == "dependency" and not planned[dep] then
        local rd = remaining_dependents(dep, planned)
        if #rd == 0 then
          planned[dep] = true
          order[#order + 1] = dep
        else
          skip[dep] = rd
        end
      end
    end
    i = i + 1
  end
  return order, skip
end

-- -Delete --isolate: delete isolated stores wholesale. Each isolated package
-- is a self-contained environment, so deleting any member (there is only the
-- target registered anyway) deletes the whole store: profile wrappers first,
-- then the store directory, then the registry entry.

function actions.delete_isolated(names, flags)
  local targets = {}
  for _, raw in ipairs(names) do
    local name = path.sanitize_name(raw)
    if not name then
      log.error("construct is invalid: " .. tostring(raw))
      return 1
    end
    if not db.isolated(name) then
      log.error(("%s is not an isolated construct."):format(name))
      return 1
    end
    targets[#targets + 1] = name
  end

  print("")
  local plan = {}
  for _, n in ipairs(targets) do
    local m = db.isolated_meta(n)
    local entry = { name = n, version = m and m.version or "?", store = m and m.reserve_root }
    plan[#plan + 1] = entry
    print(("  will delete %s-%s (isolated store %s)"):format(entry.name, entry.version, entry.store or "?"))
  end
  print("")

  local noun = #plan == 1 and "1 isolated construct" or (#plan .. " isolated constructs")
  if not confirm(("Delete %s?"):format(noun), flags.pass, " [y/N]", true) then
    log.abort("aborted by user")
    return 0
  end

  for _, e in ipairs(plan) do
    if e.store then
      -- System links before wrappers: link attribution reads the wrapper body.
      local nl = reserve.unlink_system(e.store)
      if nl > 0 then
        log.detail(("deleted %d system link(s)"):format(nl))
      end
      local n = reserve.unlink_profile(e.store)
      if n > 0 then
        log.detail(("deleted %d profile wrapper(s)"):format(n))
      end
      local ok, err = reserve.delete_store(e.store)
      if not ok then
        log.error(tostring(err))
        return 1
      end
    end
    db.delete_isolated(e.name)
    log.ok(("deleted %s"):format(e.name))
  end
  return 0
end

function actions.delete(names, flags)
  if flags.isolate then
    return actions.delete_isolated(names, flags)
  end
  -- 1) Sanitize and validate all names up-front.
  local targets = {}
  for _, raw in ipairs(names) do
    local name = path.sanitize_name(raw)
    if not name then
      log.error("construct is invalid: " .. tostring(raw))
      return 1
    end
    targets[#targets + 1] = name
  end
  for _, n in ipairs(targets) do
    if not db.kind(n) then
      if db.isolated(n) then
        log.error(("%s is provided as isolated -- use -Delete --isolate."):format(n))
      else
        log.error(("%s has not been provided."):format(n))
      end
      return 1
    end
  end

  -- 2) Build planned set from explicit targets.
  local planned = {}
  for _, n in ipairs(targets) do
    planned[n] = true
  end

  -- 3) Hard reverse-dependency check for every explicit target.
  if not flags.force then
    for _, n in ipairs(targets) do
      local rd = remaining_dependents(n, planned)
      if #rd > 0 then
        log.error(("Unable to delete %s as it is still required by %s, if you are sure about this, use --force flag"):format(
          n, table.concat(rd, ", ")))
        return 1
      end
    end
  end

  -- 4) Cascade into orphaned dependencies if --with-deps.
  local delete_order = targets
  local skipped = {}
  if flags.with_deps then
    delete_order, skipped = resolve_cascade(planned, targets)
  end

  -- 5) Build the full deletion plan. One ownership index for the whole
  -- transaction: every shared-file check becomes a hash lookup instead of a
  -- full database rescan per file (which dominated deletion time on large
  -- packages).
  local owner_index = db.file_owner_index()
  local root = config.get().root

  local plan = {}
  for _, n in ipairs(delete_order) do
    local m = db.get(n)
    local files = db.files(n)
    local will_delete, will_keep = {}, {}
    for _, rel in ipairs(files) do
      local others = db.other_owners(n, rel, owner_index)
      if #others > 0 then
        will_keep[#will_keep + 1] = { rel = rel, others = others }
      else
        will_delete[#will_delete + 1] = rel
      end
    end
    plan[#plan + 1] = {
      name = n,
      version = m and m.version or "?",
      kind = db.kind(n),
      files = files,
      will_delete = will_delete,
      will_keep = will_keep,
      shared = #will_keep,
      dependents = remaining_dependents(n, planned),
    }
  end

  if #plan == 0 then
    return 0
  end

  -- 6) Print the plan: a package header plus every file that will actually
  -- change (mirrors "will provide" lines). Shared files are listed as keep --
  -- they survive the deletion. The whole listing is built as one string and
  -- printed in a single write: thousands of print() calls would drag on slow
  -- terminals, the same reason install output is batched.
  local listing = {}
  for _, e in ipairs(plan) do
    listing[#listing + 1] = ("  will delete %s-%s"):format(e.name, e.version)
    for _, rel in ipairs(e.will_delete) do
      listing[#listing + 1] = ("      will delete %s"):format(path.join(root, rel))
    end
    for _, k in ipairs(e.will_keep) do
      listing[#listing + 1] = ("      keep %s (also owned by %s)"):format(
        path.join(root, k.rel), table.concat(k.others, ", "))
    end
    if #e.dependents > 0 then
      listing[#listing + 1] = ("    !! deleting %s breaks: %s"):format(
        e.name, table.concat(e.dependents, ", "))
    end
  end
  for dep, rd in pairs(skipped) do
    listing[#listing + 1] = ("  keep %s (still required by %s)"):format(
      dep, table.concat(rd, ", "))
  end
  print("")
  print(table.concat(listing, "\n"))
  print("")

  -- 7) Single confirmation, default NO.
  local noun = #plan == 1 and "1 construct" or (#plan .. " constructs")
  if not confirm(("Delete %s?"):format(noun), flags.pass, " [y/N]", true) then
    log.abort("aborted by user")
    return 0
  end

  -- 8) Execute deletions.
  for _, e in ipairs(plan) do
    local m = db.get(e.name)
    log.step(("deleting %s-%s (%d entries)"):format(e.name, e.version, #e.files))
    delete_files(e.files, e.name, owner_index)
    db.delete(e.name)
    for _, d in ipairs(m and m.deps or {}) do
      db.delete_dependent(d, e.name)
    end
    log.ok(("deleted %s"):format(e.name))
  end
  return 0
end

function actions.transcend(flags)
	local installed = db.list()
	if #installed == 0 then
		log.info("no constructs provided")
		return 0
	end

	local cfg = config.get()

	-- Phase 1: Fetch all manifests in parallel to check for upgrades.
	local items = {}
	local installed_info = {}
	for _, name in ipairs(installed) do
		local cur = db.get(name)
		if cur then
			installed_info[name] = cur
			items[#items + 1] = {
				url = repo.manifest_url(name),
				dest = path.join(cfg.tmp_dir, "transcend-" .. name .. "-" .. tostring(math.random(10000, 99999)) .. ".lua"),
				_name = name,
			}
		end
	end

	if #items == 0 then
		log.info("no constructs have been provided")
		return 0
	end

	-- Marked after the no-op guards above: a run that never checks anything
	-- records nothing and prints no receipt.
	profile.mark("resolve")
	local results = fetch.get_parallel(items, { label = "checking for constructs to transcend" })
	local manifest_cache = {}
	for i, result in ipairs(results) do
		local name = items[i]._name
		if result.dest then
			local f = io.open(result.dest, "rb")
			if f then
				local src = f:read("*a")
				f:close()
				os.remove(result.dest)
				local m, merr = manifest.load_string(src, repo.manifest_url(name))
				if m then
					local ok, cerr = manifest.check_name(m, name)
					if ok then
						manifest_cache[name] = m
					end
				end
			end
		end
	end
	-- Multi-repo: the parallel pass only knows the first repository. Resolve
	-- anything it missed (a package living in a later repository) serially so
	-- -Transcend can still upgrade it.
	for _, name in ipairs(installed) do
		if not manifest_cache[name] then
			local m = repo.fetch_manifest(name)
			if m then manifest_cache[name] = m end
		end
	end

	-- Compare versions to find upgrades.
	local upgrades = {}
	for _, name in ipairs(installed) do
		local cur = installed_info[name]
		local remote = manifest_cache[name]
		if cur and remote then
			local cmp = vercmp.compare(cur.version, remote.version)
			if cmp < 0 then
				upgrades[#upgrades + 1] = {
					name = name,
					from = cur.version,
					to = remote.version,
					manifest = remote,
				}
			end
		end
	end

	if #upgrades == 0 then
		log.info("all constructs are up to date")
		return 0
	end

	print("")
	for _, u in ipairs(upgrades) do
		print(("  will transcend %s %s -> %s"):format(u.name, u.from, u.to))
	end
	print("")

	-- Description only: chronos already timestamps the generation itself and
	-- `chronos list` shows it in the DATE column. Without chronos the transcend
	-- still runs -- there is just no rollback point.
	local desc = ("pre-transcending of %d construct(s)"):format(#upgrades)

	-- Same rule as -Provide: the prompt's think time belongs to no phase.
	profile.close()
	if not confirm(("Transcend %d construct(s)?"):format(#upgrades), flags.pass) then
		log.abort("aborted by user")
		return 0
	end

	-- We create a generation before a transcend
	-- more atomic, more safe
	-- Only when installing into the real system root: snapshotting the live
	-- root is meaningless for a test/alternate ZETA_ROOT -- and dangerous if
	-- the test suite happens to run as root (it would touch /boot/limine.conf).
	if cfg.root == "/" then
		if not path.run("chronos create " .. path.quote(desc)) then
			log.warn("ZETA could not create a chronos generation, transcending without a rollback point.")
		end
	end
	profile.mark("fetch")

	-- Phase 2: Pre-fetch all payloads in parallel.
	local pre_fetched = {}
	local fetch_items = {}
	for _, u in ipairs(upgrades) do
		local info, err = builder.fetch_payload(u.manifest, { force = true, source = "remote" })
		if info then
			if info.cached then
				pre_fetched[u.name] = info.cached
			elseif info.url then
				fetch_items[#fetch_items + 1] = {
					url = info.url,
					dest = info.dest,
					label = u.manifest.name .. "-" .. u.manifest.version,
					_name = u.name,
				}
			end
		elseif err then
			log.warn(("could not resolve payload for %s: %s"):format(u.name, tostring(err)))
		end
	end

	if #fetch_items > 0 then
		local dl_results = fetch.get_parallel(fetch_items)
		for i, result in ipairs(dl_results) do
			local item_name = fetch_items[i]._name
			if result.err then
				log.error(("download failed for %s: %s"):format(item_name, result.err))
				return 1
			elseif result.dest then
				pre_fetched[item_name] = result.dest
			end
		end
	end

	-- Phase 3: Verify every downloaded payload before touching the system:
	-- a corrupt archive aborts here, with nothing extracted or committed.
	profile.mark("verify")
	local verify_items = {}
	for _, u in ipairs(upgrades) do
		verify_items[#verify_items + 1] = {
			manifest = u.manifest,
			payload = pre_fetched[u.name],
		}
	end
	local vok, verr = pcall(builder.verify_all, verify_items)
	if not vok then
		log.error(tostring(verr))
		return 1
	end
	warn_stage_fit((function()
		local ps = {}
		for _, it in ipairs(verify_items) do
			if it.payload then ps[#ps + 1] = it.payload end
		end
		return ps
	end)())
	profile.mark("extract")

	-- Phase 4: Extract and build every upgrade into its staging tree. Nothing
	-- commits until every package has been staged successfully.
	--
	-- Same shape as the install flow: the upgrades stage behind one row that
	-- rewrites in place, then the last one extracts with its member listing.
	local staged = {}
	local total = #upgrades
	local n_up = total - 1

	if n_up > 0 then
		local draw, finish = begin_extract_row("upgrades", n_up)
		for i = 1, n_up do
			local u = upgrades[i]
			local payload = pre_fetched[u.name]
			draw(i, payload and path.basename(payload) or (u.name .. "-" .. u.to))
			local sok, staged_item = pcall(builder.stage_one, u.manifest, {
				payload = payload,
				verified = true,
			})
			if not sok then
				finish()
				for _, s in pairs(staged) do builder.discard_staged(s) end
				log.error(tostring(staged_item))
				return 1
			end
			staged[u.name] = staged_item
		end
		finish(true)
	end

	if total > 0 then
		local last = upgrades[total]
		local payload = pre_fetched[last.name]
		log.step(("Extracting %s... - [ 1/1 ]"):format(
			payload and path.basename(payload) or (last.name .. "-" .. last.to)))
		local sok, staged_item = pcall(builder.stage_one, last.manifest, {
			payload = payload,
			verified = true,
		})
		if not sok then
			for _, s in pairs(staged) do builder.discard_staged(s) end
			log.error(tostring(staged_item))
			return 1
		end
		staged[last.name] = staged_item
	end

	-- Phase 5: Commit and record each staged upgrade. Up to N provides run at
	-- a time; the next one starts as soon as a slot frees.
	profile.mark("commit")
	local commit_items = {}
	for _, u in ipairs(upgrades) do
		commit_items[#commit_items + 1] = {
			manifest = u.manifest,
			staged = staged[u.name],
			source = "remote",
			kind = db.kind(u.name) or "package",
		}
	end
	local cok, cerr = builder.commit_all(commit_items, {
		force = true,
		jobs = flags.jobs or config.get().jobs,
	})
	profile.close()
	if not cok then
		log.error(tostring(cerr))
		return 1
	end
	-- Library resolution check for every upgraded package that shipped
	-- binaries. Non-fatal.
	for _, u in ipairs(upgrades) do
		check_libraries(db.files(u.name), config.get().root)
	end
	finish(("(transcended %d construct(s))"):format(#upgrades))
	return 0
end

function actions.forget(pass)
	local cfg = config.get()
	if not confirm("Delete all cached constructs?", pass, " [y/N]", true) then
		log.abort("aborted by user")
		return 0
	end
	path.run("rm -rf " .. path.quote(cfg.cache_dir) .. "/*")
	log.info("cache has been cleared")
	return 0
end

return actions
