-- commit.lua -- merge a staged install root into the filesystem.
--
-- The staged tree is walked (via `find -printf`, available on all mainstream
-- find implementations), every entry is validated (symlink safety, path
-- hygiene) BEFORE anything is copied, and only then are files copied into
-- ZETA_ROOT. Zeta installs whatever a package ships; init-system and
-- distro-identity paths are not special-cased.

local commit = {}

local path = require("path")
local config = require("config")
local log = require("log")
local spinner = require("spinner")

-- ANSI color support for the progress line.
local function wants_color()
  local t = os.getenv("TERM")
  if not t or t == "" or t == "dumb" then return false end
  if os.getenv("NO_COLOR") then return false end
  return true
end
local COLOR = wants_color()
local C = {
  reset  = "\27[0m",
  blue   = "\27[34m",
  green  = "\27[32m",
  red    = "\27[31m",
  cyan   = "\27[36m",
  dim    = "\27[2m",
}
local function paint(color, s)
  if not COLOR then return s end
  return C[color] .. s .. C.reset
end

-- Walk a staged tree: returns entries { { rel, type, target } } where type is
-- "file", "dir" or "symlink". Uses find -printf ('%y|%l|%P') which gives
-- type, symlink target, and root-relative path on a single line.
local function walk_staging(staging)
  local f = path.popen("find " .. path.quote(staging)
    .. " -mindepth 1 -printf '%y|%l|%P\\n' 2>/dev/null")
  if not f then
    error(("could not scan staging directory %s"):format(staging), 0)
  end
  local out = {}
  for line in f:lines() do
    local typ, rest = line:match("^([%w])%|(.*)$")
      if typ then
        local link, rel = rest:match("^([^%|]*)%|(.*)$")
        if not link then link = "" end
        out[#out + 1] = {
          rel = rel,
          type = (typ == "d" and "dir" or (typ == "l" and "symlink" or "file")),
          target = (link ~= "" and link or nil),
        }
      end
  end
  f:close()
  return out
end

-- collect_owned(staging, whitelist) -> owned entries, ordered
--
-- The staged-tree walk, validation, whitelist filter and owned-entry
-- computation shared by apply and count_owned. Non-symlinks come before
-- symlinks (see the note below), so the caller can commit in this order.
local function collect_owned(staging, whitelist)
  local entries = walk_staging(staging)

  -- Validate every staged entry BEFORE anything is copied: relative paths
  -- must never climb out of the install root, and symlink targets must not
  -- escape it (absolute targets are fine -- they resolve at runtime against
  -- the real root). Same rules archive.validate enforces on tarball members,
  -- enforced again here because commit.apply can be fed any staging tree.
  for _, e in ipairs(entries) do
    if e.rel == "" or e.rel:match("^/") or not path.relative_inside(e.rel) then
      error(("staging entry %q escapes the root"):format(e.rel), 0)
    end
    if e.type == "symlink" and path.symlink_escapes(e.rel, e.target) then
      error(("symlink %q -> %q escapes the root"):format(e.rel, e.target), 0)
    end
  end

  if whitelist then
    local wl = {}
    for _, w in ipairs(whitelist) do wl[w] = true end
    local filtered = {}
    for _, e in ipairs(entries) do
      if e.type == "dir" or wl[e.rel] then filtered[#filtered + 1] = e end
    end
    entries = filtered
  end

  -- Owned entries are all concrete paths a package ships. Filter out directory
  -- entries that are prefixes of other entries: if a package owns usr/bin/hello,
  -- we don't record usr/ or usr/bin/ -- delete_files collects parents dynamically.
  -- This prevents deletion from ever attempting to rmdir system directories.
  --
  -- A directory is "dominated" exactly when some non-dir entry has it as a
  -- strict ancestor, so marking every ancestor of every non-dir entry gives
  -- the same set as the old dirs x files prefix scan -- in O(total path
  -- components) instead. The scan went quadratic on huge packages (10k dirs
  -- x 100k files is 1e9 string compares, and it runs once per package in
  -- the counting phase before the first file moves).
  local dominated = {}
  for _, e in ipairs(entries) do
    if e.type ~= "dir" then
      local parent = e.rel:match("^(.*)/[^/]+$")
      while parent and parent ~= "" do
        dominated[parent] = true
        parent = parent:match("^(.*)/[^/]+$")
      end
    end
  end
  local owned = {}
  for _, e in ipairs(entries) do
    if e.type ~= "dir" or not dominated[e.rel] then
      owned[#owned + 1] = e
    end
  end

  -- Commit non-symlinks before symlinks: a library symlink (libfoo.so.1 ->
  -- libfoo.so.1.2.3) must never point at a file that has not been installed
  -- yet. During an upgrade the target filename may be new, so flipping the
  -- link first leaves a window where every binary that loads the library
  -- fails to exec (e.g. bash dies when libncursesw.so.6 dangles). Stable,
  -- so the walk order is preserved within each group.
  local non_sym, sym = {}, {}
  for _, e in ipairs(owned) do
    if e.type == "symlink" then sym[#sym + 1] = e else non_sym[#non_sym + 1] = e end
  end
  owned = non_sym
  for _, e in ipairs(sym) do owned[#owned + 1] = e end

  return owned
end

-- count_owned(staging, whitelist) -> number of entries apply would commit.
-- The batch commit draws one aggregate counter across every package and
-- needs the denominator before the first file moves.
function commit.count_owned(staging, whitelist)
  return #collect_owned(staging, whitelist)
end

-- counter(done, total, final, rel) -- the live progress line the batch commit
-- redraws across the whole transaction: glyph, count, then the entry that was
-- just placed. Written in place, and settled with a newline when final -- the
-- path is a live detail, so it drops off the settled summary line. The braille
-- glyph leads so the row shows something is still moving between entries.
function commit.counter(done, total, final, rel)
  local n = paint(final and "green" or "blue", tostring(done))
  local tot = paint("cyan", tostring(total))
  local g = spinner.next_frame()
  local where = (not final and rel) and (" " .. paint("dim", rel)) or ""
  if final then
    io.write(("\r\27[K%s - [ provided %s | %s entries ]%s\n"):format(g, n, tot, where))
  else
    io.write(("\r\27[K%s - [ provided %s | %s entries ]%s"):format(g, n, tot, where))
  end
  io.flush()
end

-- apply(staging, opts) -> owned entries (files + symlinks + dirs).
-- opts: whitelist (list of rel paths to commit), force, pkg_name,
--       root (explicit install root — overrides config; set for isolated
--       installs so the host filesystem and linker cache are never touched),
--       defer_system (skip the linker-cache/schema work here; the caller runs
--       commit.run_system_ops once at the end of the transaction),
--       on_progress (called as (done, total, rel) after every committed
--       entry, rel being the root-relative path that just landed; when set,
--       the caller owns all progress output and the per-type summary, and
--       apply prints neither).
function commit.apply(staging, opts)
  opts = opts or {}
  local owned = collect_owned(staging, opts.whitelist)

  local root = opts.root or config.get().root
  local isolated = opts.root ~= nil

  -- When the target path is a symlink (e.g. /sbin -> usr/sbin from the
  -- filesystem package), create the real directory the link points at
  -- instead: mkdir -p refuses to follow a dangling symlink. Targets are
  -- relative by construction (symlink_escapes rejects absolute ones), so
  -- resolving against the parent is safe.
  -- Creating a directory costs two forks (readlink + mkdir -p) and the commit
  -- used to pay that for every one of ~1500 entries. io.open answers "already
  -- a usable directory" with no fork at all, and the result is memoised, so a
  -- package now pays roughly one pair per distinct parent instead of per file.
  local made_dirs = {}

  local function ensure_dir(d)
    if made_dirs[d] then return end
    local probe = io.open(d, "rb")
    if probe then
      probe:close()
      made_dirs[d] = true
      return
    end
    local target = path.readlink(d)
    local goal = target and path.join(path.dirname(d), target) or d
    if not path.mkdir_p(goal) then
      error(("failed to create directory %q"):format(goal), 0)
    end
    made_dirs[d] = true
    made_dirs[goal] = true
  end

  -- Copy phase. Non-verbose TTY mode shows a live updating progress line
  -- that overwrites itself in place. Verbose mode shows detailed per-file
  -- messages. Non-TTY mode skips per-file output entirely. With an
  -- on_progress callback the caller owns all progress output.
  local verbose = config.get().verbose
  local use_tty = spinner.enabled()
  local batch = opts.on_progress ~= nil
  local total = #owned
  local done = 0
  local file_count, sym_count, dir_count = 0, 0, 0

  -- Report one finished entry: the live counter first, then the verbose line.
  local function emit(e, src, dest)
    done = done + 1
    if opts.on_progress then
      opts.on_progress(done, total, e.rel)
    elseif use_tty and not verbose and total > 0 then
      local n = paint("blue", tostring(done))
      local tot = paint("cyan", tostring(total))
      io.write(("\r\27[K%s - [ provided %s | %s entries ] %s"):format(
        spinner.next_frame(), n, tot, paint("dim", path.join(root, e.rel))))
      io.flush()
    end
    if verbose then
      if e.type == "dir" then
        log.detail(("  mkdir %s"):format(dest))
      elseif e.type == "symlink" then
        log.detail(("  link %s -> %s"):format(dest, e.target))
      else
        log.detail(("  install %s -> %s"):format(src, dest))
      end
    end
  end

  -- Capability probes for the placement helpers below. Probed once per
  -- process, like bulk_supported(): `mv --help` text decides which swap
  -- primitives exist (GNU and uutils both advertise both flags today, but
  -- a stripped mv must degrade to the legacy path, not to a wrong one).
  local mv_flags
  local function have_mv(flag)
    if mv_flags == nil then
      local f = path.popen("mv --help 2>/dev/null")
      local txt = f and f:read("*a") or ""
      if f then f:close() end
      mv_flags = {
        T = txt:find("--no-target-directory", 1, true) ~= nil,
        t = txt:find("--target-directory", 1, true) ~= nil,
      }
    end
    return mv_flags[flag]
  end

  -- Filesystem device id of an existing directory (-L so a symlinked dir
  -- reports the filesystem it points at, matching how a rename through it
  -- resolves). nil when unprovable: callers then use the per-entry path,
  -- which is atomic by construction because its temp file lives in the
  -- destination's own directory.
  local dev_cache = {}
  local function device_of(dir)
    local d = dev_cache[dir]
    if d == nil then
      local f = path.popen("stat -Lc %d " .. path.quote(dir) .. " 2>/dev/null")
      local out = f and f:read("*l") or ""
      if f then f:close() end
      d = tonumber(out) or false
      dev_cache[dir] = d
    end
    if d then return d end
    return nil
  end

  -- The shadow tree bulk chunks are copied into before they are swapped
  -- onto the live path. The direct alternative -- `cp --parents` straight
  -- onto the final paths -- opens every existing destination O_TRUNC and
  -- follows destination symlinks, which rewrites shared libraries that
  -- running daemons have mmap'd: page cache mutates under them and
  -- bluetoothd/pipewire/connmand segfault mid-transaction (dmesg: bursts of
  -- identical garbage instruction addresses right after a huge commit).
  -- Shadow + rename() keeps the batch speed AND the guarantee the old
  -- per-entry `cp tmp && mv` had: the old inode stays valid for every
  -- reader until the instant it is replaced.
  local shadow, shadow_dev, shadow_tried
  local function pick_shadow()
    if shadow_tried then return shadow end
    shadow_tried = true
    local root_dev = device_of(root)
    if not root_dev then return nil end
    local stamp = table.concat({
      tostring(os.time()), tostring(math.random(1000, 9999)),
      -- Concurrent commit workers start from the same unseeded RNG, so the
      -- package name keeps two shadows launched in the same second apart
      -- (a worker never handles one package twice at once).
      tostring(opts.pkg_name or "pkg"),
    }, "-")
    -- Preferred: the configured tmp dir, when it shares the install root's
    -- filesystem (on HaliadeSYS /var/tmp is a tmpfs, so it does not, and
    -- the fallback below is taken instead).
    local tmp = config.get().tmp_dir
    if tmp and tmp ~= "" then
      path.mkdir_p(tmp)
      local cand = path.join(tmp, "shadow-" .. stamp)
      if path.mkdir_p(cand) and device_of(cand) == root_dev then
        shadow, shadow_dev = cand, root_dev
        return shadow
      end
      path.run("rm -rf " .. path.quote(cand))
    end
    -- Fallback: a dot-directory directly inside the install root, which by
    -- construction sits on the root's own filesystem. Swept by gc on the
    -- next run (builder.gc_tmp) if this process is ever SIGKILLed first.
    local cand = path.join(root, ".zeta-commit-" .. stamp)
    if path.mkdir_p(cand) and device_of(cand) == root_dev then
      shadow, shadow_dev = cand, root_dev
    else
      path.run("rm -rf " .. path.quote(cand))
      shadow = false -- unprovable -> bulk disabled, place_one everywhere
    end
    return shadow
  end

  -- One entry at a time, kept as the fallback: slow (four processes per entry
  -- counting the shells) but it works wherever `cp --parents` does not, and it
  -- reports a real per-entry error instead of a silent miss. Its temp file
  -- lives in the destination's own directory, so the final mv is always a
  -- same-filesystem rename -- atomic whether or not the shadow path applies.
  local function place_one(e, src, dest)
    ensure_dir(path.dirname(dest))
    if e.type == "symlink" then
      -- Swap through a private name + rename(): `mv -T` replaces a
      -- destination symlink *itself* instead of following it into a
      -- symlinked directory, and rename() never exposes a moment where the
      -- path is missing -- a service restarting in that window used to fail
      -- its start and stay down. Creating the temp link fresh also sidesteps
      -- uutils-coreutils ln 0.13's ENOTDIR when -f-replacing an entry under
      -- a symlinked parent (/sbin -> usr/sbin): ln never sees the old entry.
      local tmp = dest .. ".zeta-link-" .. tostring(math.random(100000, 999999))
      if not path.run("ln -sfn " .. path.quote(e.target) .. " " .. path.quote(tmp)) then
        error(("failed to create symlink %q"):format(dest), 0)
      end
      local ok
      if have_mv("T") then
        ok = path.run("mv -Tf " .. path.quote(tmp) .. " " .. path.quote(dest))
      else
        -- No -T: unlink first so the rename cannot be read as a move *into*
        -- an existing symlinked directory. Narrow window, best effort.
        path.run("rm -f " .. path.quote(dest))
        ok = path.run("mv -f " .. path.quote(tmp) .. " " .. path.quote(dest))
      end
      if not ok then
        os.remove(tmp)
        error(("failed to create symlink %q"):format(dest), 0)
      end
    else
      local tmp = dest .. ".zeta-tmp-" .. tostring(math.random(100000, 999999))
      if not path.run("cp -a " .. path.quote(src) .. " " .. path.quote(tmp)) then
        os.remove(tmp)
        error(("failed to install %q"):format(e.rel), 0)
      end
      if not path.run("mv -f " .. path.quote(tmp) .. " " .. path.quote(dest)) then
        os.remove(tmp)
        error(("failed to install %q"):format(e.rel), 0)
      end
    end
  end

  -- `cp --parents` rebuilds the whole relative tree under the root in a single
  -- process -- mode, ownership, timestamps and symlinks all included -- instead
  -- of a `cp` plus an `mv` (four processes with their shells) for every entry.
  -- That per-entry cost was the 31 second commit phase. The copy lands in the
  -- shadow tree (see pick_shadow) and each entry is then renamed() into place,
  -- grouped per destination directory so a chunk costs one mv process per
  -- directory instead of per entry. Capabilities are probed once; any failure
  -- drops this chunk to place_one and stops further attempts, which is exactly
  -- what every install did before, so the worst case is no worse than it used
  -- to be.
  local bulk_enabled
  local function bulk_supported()
    if bulk_enabled == nil then
      local f = path.popen("cp --help 2>/dev/null")
      local txt = f and f:read("*a") or ""
      if f then f:close() end
      bulk_enabled = txt:find("--parents", 1, true) ~= nil
    end
    return bulk_enabled
  end

  local function bulk_place(chunk)
    local sh = pick_shadow()
    if not sh then
      bulk_enabled = false
    else
      local rels = {}
      for _, e in ipairs(chunk) do rels[#rels + 1] = path.quote(e.rel) end
      local cmd = "cd " .. path.quote(staging)
        .. " && cp -a --parents " .. table.concat(rels, " ") .. " " .. path.quote(sh)
      if path.run(cmd) then
        -- Swap in, grouped by destination directory.
        local groups, order = {}, {}
        for _, e in ipairs(chunk) do
          local d = path.dirname(path.join(root, e.rel))
          ensure_dir(d)
          local g = groups[d]
          if not g then
            g = { dest = d }
            groups[d] = g
            order[#order + 1] = g
          end
          g[#g + 1] = e
        end
        for _, g in ipairs(order) do
          -- Rename only when source and destination share a filesystem: a
          -- cross-device mv silently degrades to a non-atomic copy, and
          -- mountpoints inside the root (/run, /var/cache on tmpfs) are
          -- exactly where that would bite. Those entries take place_one,
          -- whose temp sits in the destination's own directory.
          local placed = false
          if device_of(g.dest) == shadow_dev then
            local srcs = {}
            for _, e in ipairs(g) do srcs[#srcs + 1] = path.join(sh, e.rel) end
            if have_mv("t") then
              placed = path.run("mv -f -t " .. path.quote(g.dest)
                .. " " .. table.concat(srcs, " "))
            else
              placed = true
              for i, e in ipairs(g) do
                if not path.run("mv -f " .. path.quote(srcs[i]) .. " "
                    .. path.quote(path.join(root, e.rel))) then
                  placed = false
                  break
                end
              end
            end
          end
          if not placed then
            for _, e in ipairs(g) do
              place_one(e, path.join(staging, e.rel), path.join(root, e.rel))
            end
          end
        end
        return
      end
      bulk_enabled = false
    end
    for _, e in ipairs(chunk) do
      place_one(e, path.join(staging, e.rel), path.join(root, e.rel))
    end
  end

  -- Placement runs inside a pcall so the shadow tree is removed on both the
  -- success and the failure path: an error would otherwise strand it at the
  -- root of the system until the next run's sweep.
  local placed_ok, placed_err = pcall(function()
    -- Pass 1: directories are created directly, everything else is queued.
    local place = {}
    for _, e in ipairs(owned) do
      if e.type == "dir" then
        local dest = path.join(root, e.rel)
        ensure_dir(dest)
        dir_count = dir_count + 1
        emit(e, path.join(staging, e.rel), dest)
      else
        place[#place + 1] = e
      end
    end

    -- Pass 2: place the queued entries in chunks. 25 keeps `cp`'s command line
    -- tiny while still collapsing ~1500 shells into a handful, and the counter
    -- still moves visibly between chunks.
    if #place > 0 then path.mkdir_p(root) end
    local CHUNK = 25
    local start = 1
    while start <= #place do
      local stop = math.min(start + CHUNK - 1, #place)
      local chunk = {}
      for k = start, stop do chunk[#chunk + 1] = place[k] end
      start = stop + 1

      if bulk_supported() then
        bulk_place(chunk)
      else
        for _, e in ipairs(chunk) do
          place_one(e, path.join(staging, e.rel), path.join(root, e.rel))
        end
      end

      for _, e in ipairs(chunk) do
        if e.type == "symlink" then
          sym_count = sym_count + 1
        else
          file_count = file_count + 1
        end
        emit(e, path.join(staging, e.rel), path.join(root, e.rel))
      end
    end
  end)
  if shadow then path.run("rm -rf " .. path.quote(shadow)) end
  if not placed_ok then error(placed_err, 0) end

  -- Final count line, replacing the live line in place. Batch mode leaves the
  -- counter to the caller.
  if not batch and not verbose and total > 0 and use_tty then
    local n = paint("green", tostring(total))
    local tot = paint("cyan", tostring(total))
    io.write(("\r\27[K%s - [ provided %s | %s entries ]\n"):format(spinner.next_frame(), n, tot))
    io.flush()
  end

  -- Per-type summary (batch mode: the caller prints one aggregate summary).
  if not batch then
    if file_count > 0 then
      log.info(("- committed %d files to %s"):format(file_count, root))
    end
    if sym_count > 0 then
      log.info(("- committed %d symlinks to %s"):format(sym_count, root))
    end
    if dir_count > 0 then
      log.info(("- committed %d dirs to %s"):format(dir_count, root))
    end
  end

  -- Whether any GSettings schemas shipped (the compile itself is part of the
  -- system ops below).
  local has_schema = false
  for _, e in ipairs(owned) do
    if e.rel:match("^usr/share/glib%-2%.0/schemas/.+%.gschema%.xml$") then
      has_schema = true
      break
    end
  end

  -- System-wide side effects run once per transaction (see run_system_ops);
  -- a pool commit defers them so two workers can never collide.
  if not opts.defer_system then
    commit.run_system_ops({ root = root, isolated = isolated, schemas = has_schema })
  end

  return owned
end

-- run_system_ops(opts) -- opts: { root, isolated, schemas }
--
-- The system-wide side effects of a commit, run ONCE per transaction after
-- every package is in place: the linker cache (ld.so.conf snippet + ldconfig)
-- and GSettings schema compilation. Two concurrent commits must never race on
-- /etc/ld.so.cache~ or gschemas.compiled, so the commit pool defers these
-- here instead of running them per package.
function commit.run_system_ops(opts)
  opts = opts or {}
  local root = opts.root or config.get().root
  -- Normalized root ("/" for the host, absolute path for a ZETA_ROOT tree)
  -- and whether we are touching the real system.
  local r = (root == "") and "/" or root
  local on_host = (r == "/")

  -- Linker cache maintenance only applies to the real system root: an
  -- isolated store never touches the host's ld.so.conf or ld.so.cache (its
  -- binaries resolve libraries through their store RPATHs, with the profile
  -- wrapper's LD_LIBRARY_PATH as fallback).
  if not opts.isolated then
    -- Ensure the top-level ld.so.conf exists. Packages never ship one, so a
    -- deployed tree would only have the orphaned snippet below — and ldconfig
    -- reads ld.so.conf.d exclusively through this file's include directive.
    local topconf = path.join(r, "etc/ld.so.conf")
    if not path.exists(topconf) then
      path.mkdir_p(path.dirname(topconf))
      local f = io.open(topconf, "w")
      if f then
        f:write("include /etc/ld.so.conf.d/*.conf\n")
        f:close()
      end
    end

    -- Ensure the dynamic linker knows about /usr/lib and /lib. The default
    -- ld.so.conf only lists /usr/local/lib and /opt/lib; without these paths
    -- ldconfig cannot populate the cache for libraries installed by ZETA.
    local ldconf = path.join(r, "etc/ld.so.conf.d/00-usr.conf")
    if not path.exists(ldconf) then
      path.mkdir_p(path.dirname(ldconf))
      local f = io.open(ldconf, "w")
      if f then
        f:write("/lib\n/usr/lib\n")
        f:close()
      end
    end

    -- Rebuild the shared library cache so newly installed libraries are found
    -- at runtime. ldconfig is idempotent and fast. For a non-host root this
    -- MUST be rooted: plain ldconfig rewrites the *host's* cache and leaves
    -- the tree with the stale cache shipped inside the glibc payload — inside
    -- a chroot/bwrap nothing in /lib or /usr/lib then resolves (the runtime
    -- system search path only covers /lib64 and /usr/lib64).
    --
    -- On the host the write must be ATOMIC: /etc/ld.so.cache is opened (and
    -- often mmap'd) by every exec and dlopen, and ldconfig rewrites its cache
    -- file in place — truncate first, then write. A process resolving a
    -- library during that window parses a torn cache and segfaults (this is
    -- the `... error 4 in ld-linux-x86-64.so.2` burst right after a huge
    -- transaction). Build into a private file and rename() it into place: a
    -- reader then sees either the old cache or the new one, never a partial.
    -- A non-host store has no live readers, so it keeps plain ldconfig -r.
    local ldcmd = on_host and "ldconfig" or ("ldconfig -r " .. path.quote(r))
    log.step("Regenerating ldconfig cache")
    local ldc_ok
    if on_host then
      local cache = path.join(r, "etc/ld.so.cache")
      local tmpcache = cache .. ".zeta-tmp"
      ldc_ok = path.run(ldcmd .. " -C " .. path.quote(tmpcache))
        and path.run("mv -f " .. path.quote(tmpcache) .. " " .. path.quote(cache))
      if not ldc_ok then os.remove(tmpcache) end
    else
      ldc_ok = path.run(ldcmd)
    end
    if ldc_ok then
      log.ok("ld.so.cache updated")
    else
      log.warn("ldconfig failed (non-fatal, but libraries may not be found at runtime)")
    end

    -- Image-loader / desktop caches, regenerated per install so a fresh
    -- system reaches full icon and menu state without manual steps: only
    -- png/jpeg loaders are builtin to gdk-pixbuf (svg/gif/tiff resolve
    -- through the loaders cache), and desktop/menu association lookups
    -- read the desktop database. Best-effort, like ldconfig above. On a
    -- non-host root the paths are rooted (gdk-pixbuf runs via chroot so
    -- the recorded module paths are the tree's own), and steps whose
    -- inputs are absent from the tree are skipped outright.
    if on_host then
      log.step("Regenerating gdk-pixbuf loaders cache")
      if path.run("gdk-pixbuf-query-loaders --update-cache") then
        log.ok("gdk-pixbuf loaders.cache updated")
      else
        log.warn("gdk-pixbuf-query-loaders failed (non-fatal, dynamic loaders may be unreachable)")
      end

      log.step("Updating desktop database")
      if path.run("update-desktop-database /usr/share/applications") then
        log.ok("desktop database updated")
      else
        log.warn("update-desktop-database failed (non-fatal, menu associations may be stale)")
      end

      log.step("Updating icon theme caches")
      if path.run("for d in /usr/share/icons/*/; do if [ -f \"$d/index.theme\" ]; then gtk-update-icon-cache -q -f -t \"$d\" || true; fi; done") then
        log.ok("icon theme caches updated")
      else
        log.warn("gtk-update-icon-cache failed (non-fatal)")
      end
    else
      if path.exists(path.join(r, "usr/bin/gdk-pixbuf-query-loaders")) then
        log.step("Regenerating gdk-pixbuf loaders cache")
        if path.run("chroot " .. path.quote(r) .. " /usr/bin/gdk-pixbuf-query-loaders --update-cache") then
          log.ok("gdk-pixbuf loaders.cache updated")
        else
          log.warn("gdk-pixbuf-query-loaders failed (non-fatal, dynamic loaders may be unreachable)")
        end
      end

      local appdir = path.join(r, "usr/share/applications")
      if path.exists(appdir) then
        log.step("Updating desktop database")
        if path.run("update-desktop-database " .. path.quote(appdir)) then
          log.ok("desktop database updated")
        else
          log.warn("update-desktop-database failed (non-fatal, menu associations may be stale)")
        end
      end

      local iconroot = path.join(r, "usr/share/icons")
      if path.exists(iconroot) then
        log.step("Updating icon theme caches")
        if path.run("for d in " .. path.quote(iconroot) .. "/*/; do if [ -f \"$d/index.theme\" ]; then gtk-update-icon-cache -q -f -t \"$d\" || true; fi; done") then
          log.ok("icon theme caches updated")
        else
          log.warn("gtk-update-icon-cache failed (non-fatal)")
        end
      end
    end
  end

  -- Auto-compile GSettings schemas if any were installed (rooted at whatever
  -- root is in use, so isolated stores get their own gschemas.compiled).
  if opts.schemas then
    local schemas_dir = root .. "/usr/share/glib-2.0/schemas"
    local compile = "glib-compile-schemas " .. path.quote(schemas_dir)
    log.step("compiling GSettings schemas")
    if path.run(compile) then
      log.ok("gschemas.compiled generated")
    else
      log.warn("glib-compile-schemas failed (non-fatal)")
    end
  end

  -- The distro convention keeps package configs under usr/etc (prefix-owned
  -- tree), but nothing reads them there: XDG, dhcpcd, avahi et al all look
  -- in /etc. Mirror every file from <root>/usr/etc into <root>/etc as a
  -- RELATIVE symlink so isolated stores stay self-contained and package
  -- upgrades take effect through the same path. Never overwrites an
  -- existing /etc file (other packages own those directly), and is
  -- idempotent — it also heals systems installed before this hook existed.
  local usretc = root .. "/usr/etc"
  if path.exists(usretc) then
    log.step("mirroring usr/etc configs into /etc")
    -- Built by concatenation, not string.format: the script contains shell
    -- ${var%pattern} syntax whose bare % breaks Lua's format conversions.
    local mirror = "R=" .. path.quote(root) .. "\n" .. [[R=${R%/}
find "$R/usr/etc" -type f 2>/dev/null | while IFS= read -r f; do
  rel=${f#"$R/usr/etc/"}
  dest="$R/etc/$rel"
  [ -e "$dest" ] && continue
  mkdir -p "$(dirname "$dest")"
  n=$(printf '%s' "$rel" | tr -cd / | wc -c)
  ups="../"
  i=$n
  while [ "$i" -gt 0 ]; do ups="../$ups"; i=$((i-1)); done
  ln -s "${ups}usr/etc/$rel" "$dest" || exit 1
done]]
    if path.run(mirror) then
      log.ok("usr/etc configs linked into /etc (absent files only)")
    else
      log.warn("usr/etc mirroring failed (non-fatal, /etc configs may be absent)")
    end
  end
end

return commit
