-- config.lua -- configuration with layered precedence:
--   1. Environment variables (highest priority)
--   2. /etc/zeta/configuration.lua (config file)
--   3. Built-in defaults (lowest priority)
--
-- ZETA_ROOT is how Zeta stays "rooted" and testable: point it at a scratch
-- directory and every install, database write, and deletion happens under it.
--
-- The client can consult several remote repositories at once. `repos` is the
-- resolved consultation list (first hit wins) and comes from, in order:
-- the ZETA_REPOS env var (space-separated URLs), the ZETA_REPO env var
-- (single URL, kept so existing setups keep working), a `repos = { ... }`
-- table in the config file, or a single `repo = "..."` string there.
-- Defaults to the single zeta-index repository.

local config = {}

local path = require("path")

-- Environment overrides. Tests (and only tests) use config.setenv to inject
-- values portably on Lua 5.1, which has no os.setenv.
local _overrides = {}
local _cfg
local _script_dir
local DEFAULT_CONFIG_FILE = "/etc/zeta/configuration.lua"
local _config_file = DEFAULT_CONFIG_FILE

function config.setenv(k, v)
  _overrides[k] = v
end

-- Tests (and only tests) pick which config file is loaded; nil restores the
-- system default. Mirrors setenv above.
function config.set_config_file(p)
  _config_file = p or DEFAULT_CONFIG_FILE
end

function config.reset()
  _overrides = {}
  _cfg = nil
  _script_dir = nil
  _config_file = DEFAULT_CONFIG_FILE
end

local function getenv(k)
  local v = _overrides[k]
  if v ~= nil then return v end
  return os.getenv(k)
end

-- The machine's core count, for `jobs = nproc`. Probed from `nproc`, then
-- `getconf`, then /proc/cpuinfo; falls back to the default pool size.
local function core_count()
  for _, cmd in ipairs({ "nproc", "getconf _NPROCESSORS_ONLN" }) do
    local f = path.popen(cmd .. " 2>/dev/null")
    if f then
      local n = tonumber(f:read("*l"))
      f:close()
      if n and n >= 1 then return math.floor(n) end
    end
  end
  local f = io.open("/proc/cpuinfo", "rb")
  if f then
    local n = 0
    for line in f:lines() do
      if line:match("^processor%s*:") then n = n + 1 end
    end
    f:close()
    if n >= 1 then return n end
  end
  return 2
end

-- Load a Lua config file that returns a table. Returns the table or nil.
-- While the file runs, the global `nproc` holds the machine's core count so
-- `jobs = nproc` uses every core.
local function load_config_file(filepath)
  local saved_nproc = rawget(_G, "nproc")
  _G.nproc = core_count()
  local ok, result = pcall(dofile, filepath)
  _G.nproc = saved_nproc
  if ok and type(result) == "table" then
    return result
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- Writable temp dir
-- ---------------------------------------------------------------------------
--
-- <root>/var/tmp/zeta is root-owned on a real system, so the read-only
-- commands a normal user runs (-Localize resolving origins, and the manifest
-- prefetch in -Provide before the privilege gate matters) downloaded into a
-- directory they cannot write. The failures were swallowed downstream: origins
-- all resolved to "unknown" and each manifest was fetched twice. Probe with
-- io.open -- no fork, so this costs nothing on the happy path -- and fall back
-- to a private dir under $TMPDIR that is registered for cleanup on exit.
local fallback_tmp
local fallback_hooked = false

local function ensure_dir(dir)
  local d = io.open(dir, "rb")
  if d then d:close() return true end   -- already exists: no fork
  return path.mkdir_p(dir)
end

local function writable_tmp_dir(dir)
  if not dir or dir == "" then return dir end
  ensure_dir(dir)
  local probe = path.join(dir,
    (".zeta-write-%d-%d"):format(os.time(), math.random(10000, 99999)))
  local f = io.open(probe, "wb")
  if f then
    f:close()
    os.remove(probe)
    return dir
  end

  -- Not writable: build a private directory once and reuse it for the life of
  -- this process. Registered exactly once so repeated config.load() calls in
  -- the test harness do not pile up cleanup hooks.
  if fallback_tmp then return fallback_tmp end
  local base = getenv("TMPDIR")
  if not base or base == "" then base = "/tmp" end
  fallback_tmp = path.join(base,
    ("zeta-tmp-%d-%d"):format(os.time(), math.random(10000, 99999)))
  path.mkdir_p(fallback_tmp)
  if not fallback_hooked then
    fallback_hooked = true
    path.on_cleanup(function()
      if fallback_tmp then path.run("rm -rf " .. path.quote(fallback_tmp)) end
    end)
  end
  return fallback_tmp
end

-- Resolve the local package tree. ZETA_LOCAL_PACKAGES is authoritative when
-- set; otherwise the documented default <root>/usr/share/packages wins if it
-- exists, and only then we fall back to <script_dir>/packages so an unpacked
-- checkout works offline with no environment at all.
local function resolve_local_packages(root, under, cfg_file)
  local env = getenv("ZETA_LOCAL_PACKAGES")
  if env then return env end
  if cfg_file and cfg_file.local_packages then return cfg_file.local_packages end
  local sys = under("usr/share/packages")
  if path.exists(sys) then return sys end
  if _script_dir then
    local checkout = path.join(_script_dir, "packages")
    if path.exists(checkout) then return checkout end
  end
  return sys
end

-- Resolve the remote repository list. Precedence:
--   ZETA_REPOS (env, space-separated) > ZETA_REPO (env, single) >
--   config file repos (list) > config file repo (single) > default.
local function resolve_repos(cfg_file)
  local list = getenv("ZETA_REPOS")
  if list and list ~= "" then
    local repos = {}
    for url in list:gmatch("%S+") do
      if url ~= "" then repos[#repos + 1] = url end
    end
    if #repos > 0 then return repos end
  end
  local single = getenv("ZETA_REPO")
  if single and single ~= "" then return { single } end
  if cfg_file then
    if type(cfg_file.repos) == "table" then
      local repos = {}
      for _, url in ipairs(cfg_file.repos) do
        if type(url) == "string" and url ~= "" then repos[#repos + 1] = url end
      end
      if #repos > 0 then return repos end
    end
    if type(cfg_file.repo) == "string" and cfg_file.repo ~= "" then
      return { cfg_file.repo }
    end
  end
  return { "https://github.com/gretagen/zeta-index" }
end

-- Resolve the commit pool size: how many packages may be "provided" at the
-- same time. ZETA_JOBS (env) > config file `jobs` > default 2. The value
-- "nproc" (or the nproc global in the config file) means every core.
local function resolve_jobs(cfg_file)
  local env = getenv("ZETA_JOBS")
  if env == "nproc" then return core_count() end
  local v = tonumber(env) or (cfg_file and tonumber(cfg_file.jobs))
  if v and v >= 1 then return math.floor(v) end
  return 2
end

-- Packages -Solve must never reinstall. Replacing any of these under a running
-- system breaks processes already linked against the old build: reinstalling
-- ncurses, for example, leaves every subsequent shell printing
-- "no version information available" for the rest of the session -- and ZETA
-- shells out for nearly everything (path.run/path.popen -> sh -c), so it ends
-- up flooding its own output.
--
-- Deliberately NOT applied to -ReProvide, -Provide --force or -Transcend:
-- those are updates you asked for, and gating them would freeze glibc/openssl
-- at their current version forever. Isolated solves are exempt too -- they
-- stage into /zeta/reserve/... and never touch the system copy.
--
-- A `do_not_solve = { ... }` table in the config file REPLACES this list (same
-- semantics as `repos`), so extending it means copying these names first.
local DEFAULT_DO_NOT_SOLVE = {
  -- The C runtime: literally every process links it.
  glibc = true,
  -- Terminal library: bash links these directly -- the source of the
  -- "no version information available" flood.
  ncurses = true,
  libtinfo = true,
  -- What ZETA shells out to on every operation.
  bash = true,
  coreutils = true,
  ["uutils-coreutils"] = true,
  -- Toolchain: reinstalling mid-run breaks any build in flight.
  gcc = true,
  ["gcc-libs"] = true,
  ["gcc-minimal"] = true,
  libgcc = true,
  binutils = true,
  -- TLS, for ZETA's own curl/wget downloads.
  openssl = true,
  -- The other half of bash's link chain.
  readline = true,
}

-- Returns the set as { [name] = true }. A config-file list replaces the
-- defaults; anything non-table (or absent) keeps them.
local function resolve_do_not_solve(cfg_file)
  local list = cfg_file and cfg_file.do_not_solve
  if type(list) ~= "table" then return DEFAULT_DO_NOT_SOLVE end
  local set = {}
  for _, n in ipairs(list) do
    if type(n) == "string" and n ~= "" then set[n] = true end
  end
  return set
end

function config.load(script_dir)
  if script_dir then _script_dir = script_dir end

  -- Layer 1: Load config file.
  local cfg_file = load_config_file(_config_file)

  -- Layer 2: Resolve root (env > config file > default).
  local root = getenv("ZETA_ROOT") or (cfg_file and cfg_file.root) or "/"
  if root == "" then root = "/" end
  local function under(p)
    if path.is_abs(p) then return p end
    return path.join(root, p)
  end

  -- Layer 3: Build full config table with env > file > defaults.
  local repos = resolve_repos(cfg_file)
  _cfg = {
    root = root,
    repos = repos,
    repo = repos[1],
    local_packages = resolve_local_packages(root, under, cfg_file),
    cache_dir = getenv("ZETA_CACHE") or (cfg_file and cfg_file.cache_dir) or under("var/cache/zeta"),
    state_dir = getenv("ZETA_STATE") or (cfg_file and cfg_file.state_dir) or under("var/db/zeta"),
    tmp_dir = writable_tmp_dir(getenv("ZETA_TMP") or (cfg_file and cfg_file.tmp_dir) or under("var/tmp/zeta")),
    reserve_dir = getenv("ZETA_RESERVE") or (cfg_file and cfg_file.reserve_dir) or under("zeta/reserve"),
    jobs = resolve_jobs(cfg_file),
    do_not_solve = resolve_do_not_solve(cfg_file),
    verbose = (getenv("ZETA_VERBOSE") == "1" or getenv("ZETA_VERBOSE") == "true")
              or (cfg_file and cfg_file.verbose == true)
              or false,
    quotes = not (
      (getenv("ZETA_QUOTES") == "false" or getenv("ZETA_QUOTES") == "0")
      or (cfg_file and cfg_file.quotes == false)
    ),
  }
  return _cfg
end

function config.get()
  if not _cfg then config.load() end
  return _cfg
end

return config
