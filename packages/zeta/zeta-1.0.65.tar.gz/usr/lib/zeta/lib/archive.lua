-- archive.lua -- tar inspection, safe extraction, and Debian (.deb) payloads.
--
-- Extraction is a two-phase process: list the archive and validate every
-- member (no absolute paths, no ".." escapes, symlink targets that stay
-- inside the root) BEFORE extracting anything. A hostile or malformed archive
-- is therefore rejected without touching the filesystem. Symlink detection
-- relies on the `name -> target` form printed by tar for symbolic links.
--
-- A .deb is an ar(1) container holding debian-binary, control.tar.*, and
-- data.tar.*. Zeta only extracts the data member (a plain tar) -- maintainer
-- scripts are out of scope, superseded by Zeta's own manifest and hooks. The
-- ar container is parsed in pure Lua so no ar/dpkg dependency is dragged in.
--
-- An Arch/Artix .pkg.tar.{zst,xz} is a plain zstd/xz-compressed tar whose
-- members are already anchored at the root (usr/bin/..., etc/...) and carry
-- package metadata entries (.PKGINFO, .MTREE, .BUILDINFO, .INSTALL) that must
-- not land in the extraction tree. GNU tar decompresses both natively.

local archive = {}

-- Package metadata entries carried by Arch/Artix (and some legacy Haliade
-- repacks that tarred extracted Arch trees whole). They are packaging
-- bookkeeping, never payload: extraction drops them and the root-file check
-- ignores them wherever an archive format's dispatch missed them (plain
-- .tar.gz archives that actually contain an Arch layout).
local METADATA_MEMBERS = { ".PKGINFO", ".MTREE", ".BUILDINFO", ".INSTALL" }
local METADATA_SET = {}
for _, m in ipairs(METADATA_MEMBERS) do METADATA_SET[m] = true end

local path = require("path")
local log = require("log")
local config = require("config")

-- GNU tar shells out to the external zstd binary for decompression. When the
-- container's zstd is linked against a different libzstd version, it crashes
-- with "undefined symbol: POOL_free". Setting LD_LIBRARY_PATH ensures the
-- correct libzstd is found at runtime.
local TAR_ENV = "LD_LIBRARY_PATH=/usr/lib"

local function rel_of(member)
  local rel = member:gsub("^%./+", "")
  rel = rel:gsub("/+$", "")
  return rel
end

-- Classify the members of a tar archive.
-- Returns entries = { { path=rel, type="file"|"dir"|"symlink", target=.. } }.
--
-- Plain `tar -tf` prints names only (no link targets), so symlink safety
-- could not be checked from it. We therefore run TWO passes and walk them in
-- lockstep (both list members in archive order): `tar -tf` for the clean
-- member names, `tar -tvf` for the file type (verbose mode's leading char)
-- and, for symlinks, the `name -> target` marker.
function archive.entries(archive_file)
  local nf = path.popen(TAR_ENV .. " tar -tf " .. path.quote(archive_file) .. " 2>/dev/null")
  if not nf then return nil, "could not run tar" end
  local names = {}
  for line in nf:lines() do
    local name = line
    local is_dir = name:sub(-1) == "/"
    if is_dir then name = name:sub(1, -2) end
    names[#names + 1] = { name = name, dir = is_dir }
  end
  nf:close()

  local vf = path.popen(TAR_ENV .. " tar -tvf " .. path.quote(archive_file) .. " 2>/dev/null")
  local entries = {}
  local i = 0
  if vf then
    for line in vf:lines() do
      i = i + 1
      local info = names[i]
      if info then
        local typc = line:sub(1, 1)
        local target
        local typ
        if typc == "l" then
          typ = "symlink"
          target = line:match(" -> (%S+)$") or ""
        elseif typc == "d" then
          typ = "dir"
        else
          typ = "file"
        end
        local rel = rel_of(info.name)
        if rel ~= "" then
          entries[#entries + 1] = { path = rel, type = typ, target = target, raw = info.name }
        end
      end
    end
    vf:close()
  end
  return entries
end

-- Rewrite a tar archive to convert absolute symlinks to relative ones.
-- Arch packages (especially mate-panel) ship help-doc symlinks like:
--   usr/share/help/af/mate-clock/figures/clock_applet.png -> /usr/share/help/C/...
-- These escape the extraction root. This function repacks the tar with
-- symlink targets rewritten to relative form. Returns the path to the
-- fixed tar (caller must clean it up), or nil on failure.
local function relative_path(from_file, to_abs)
  -- from_file: path of the symlink (e.g. "usr/share/help/af/mate-clock/figures/clock_applet.png")
  -- to_abs: absolute target (e.g. "/usr/share/help/C/mate-clock/figures/clock_applet.png")
  -- Compute relative path from from_file's directory to to_abs.
  local from_dir = from_file:match("^(.*)/[^/]+$") or ""
  -- Split dirs
  local from_parts = {}
  for p in from_dir:gmatch("[^/]+") do from_parts[#from_parts + 1] = p end
  local to_parts = {}
  for p in to_abs:gmatch("[^/]+") do to_parts[#to_parts + 1] = p end
  -- Find common prefix
  local common = 0
  for i = 1, math.min(#from_parts, #to_parts) do
    if from_parts[i] == to_parts[i] then common = i else break end
  end
  -- Go up from from_dir, then down to target
  local ups = #from_parts - common
  local parts = {}
  for i = 1, ups do parts[#parts + 1] = ".." end
  for i = common + 1, #to_parts do parts[#parts + 1] = to_parts[i] end
  if #parts == 0 then return "." end
  return table.concat(parts, "/")
end

function archive.rewrite_abs_symlinks(archive_file)
  local entries, err = archive.entries(archive_file)
  if not entries then return nil, err end
  local has_abs = false
  for _, e in ipairs(entries) do
    if e.type == "symlink" and e.target and e.target:match("^/") then
      has_abs = true
      break
    end
  end
  if not has_abs then return archive_file end
  -- Extract to temp, fix symlinks via entries list, re-tar
  local tmp = os.tmpname()
  os.remove(tmp)
  os.execute("mkdir -p " .. tmp)
  local cmd = TAR_ENV .. " tar -xf " .. path.quote(archive_file)
    .. " -C " .. path.quote(tmp) .. " --no-same-owner"
  path.run(cmd)
  -- Fix each absolute symlink
  for _, e in ipairs(entries) do
    if e.type == "symlink" and e.target and e.target:match("^/") then
      local full = tmp .. "/" .. e.path
      local rel = relative_path(e.path, e.target)
      os.execute("ln -sfn " .. path.quote(rel) .. " " .. path.quote(full))
    end
  end
  -- Re-tar
  local fixed = os.tmpname() .. ".tar"
  os.remove(fixed)
  local rcmd = "tar cf " .. path.quote(fixed) .. " -C " .. path.quote(tmp) .. " ."
  path.run(rcmd)
  os.execute("rm -rf " .. path.quote(tmp))
  return fixed
end

-- Validate that no member escapes the extraction root. Returns true or nil, err.
function archive.validate(entries)
  for _, e in ipairs(entries) do
    if e.path == "" or e.path:match("^/") or not path.relative_inside(e.path) then
      return nil, ("archive member %q escapes the root"):format(e.path)
    end
    if e.type == "symlink" and path.symlink_escapes(e.path, e.target) then
      return nil, ("symlink %q -> %q escapes the root"):format(e.path, e.target)
    end
  end
  return true
end

-- Reject members that would land as BARE files at the destination root once
-- `strip` leading path components are removed. GNU tar's --strip-components
-- consumes the first `strip` components of each member name, so any regular
-- file or symlink whose raw name has `strip` or fewer path separators would
-- extract as a top-level file straight into the destination root (the
-- lead-in `./` counts as one component). This is exactly how perl-5.42.3's
-- 962 stray Pod::Man pages (*.0) ended up installed into /. Directories at
-- that depth are the stripped top-level directory itself and are allowed.
-- Source-tarball unpacking passes strip=0 (see `p:unpack`) and is exempt.
-- Returns true or nil, err. Set opts.allow_root_files on extract to opt out.
local function check_root_files(entries, strip)
  if strip < 1 then return true end
  local separators = function(name)
    local n = 0
    for _ in name:gmatch("/") do n = n + 1 end
    return n
  end
  for _, e in ipairs(entries) do
    if e.type ~= "dir" and separators(e.raw or e.path) <= strip then
      local base = (e.path or ""):match("([^/]+)$")
      if METADATA_SET[base] then
        -- package metadata (e.g. ./.BUILDINFO in legacy repacks): dropped
        -- at extraction, never a stray root file.
        log.detail(("archive: ignoring package metadata member %q"):format(e.path))
      else
        return nil, ("archive member %q would extract as a top-level file at the destination root"):format(e.path)
      end
    end
  end
  return true
end

-- Extract `archive_file` into `dest`. Returns the validated entries, or
-- nil, err if validation or extraction fails. Dispatches on the archive's
-- own filename so format-specific handling (deb payloads, Arch metadata)
-- never depends on how the file was named in the cache.
function archive.extract(archive_file, dest, opts)
  opts = opts or {}
  local name = path.basename(archive_file)
  if name:match("%.deb$") then
    return archive.extract_deb(archive_file, dest, opts)
  end
  if name:match("%.pkg%.tar%.zst$") or name:match("%.pkg%.tar%.xz$") then
    return archive.extract_arch_pkg(archive_file, dest, opts)
  end
  return archive.extract_tar(archive_file, dest, opts)
end

-- Extract a plain tar archive (any compression tar understands) into `dest`.
-- Same two-phase listing + validation as every other extractor. opts:
--   strip    number of leading components to drop
--   exclude  list of member globs to skip during extraction (they are still
--            listed and validated, but never written to disk)
function archive.extract_tar(archive_file, dest, opts)
  opts = opts or {}
  local entries, err = archive.entries(archive_file)
  if not entries then return nil, err end
  local ok, verr = archive.validate(entries)
  if not ok then return nil, verr end
  if not opts.allow_root_files then
    local rok, rerr = check_root_files(entries, opts.strip or 0)
    if not rok then return nil, rerr end
  end
  local strip = opts.strip or 0
  -- --silence opts out of the -v member listing; verbose extraction is the
  -- default so users see what is being installed.
  local listing = log.is_file_silent() and "-xf" or "-xvf"
  -- GNU tar only honors --exclude once it has seen the archive operand, so
  -- the flags go AFTER the file name (before -f they are taken as operands).
  local cmd = TAR_ENV .. " tar " .. listing .. " " .. path.quote(archive_file)
    .. " -C " .. path.quote(dest) .. " --no-same-owner"
  for _, glob in ipairs(opts.exclude or {}) do
    cmd = cmd .. " --exclude=" .. path.quote(glob)
  end
  -- Never write package metadata, whatever the archive is named (see
  -- METADATA_MEMBERS; unanchored tar patterns match any path suffix).
  for _, glob in ipairs(METADATA_MEMBERS) do
    cmd = cmd .. " --exclude=" .. path.quote(glob)
  end
  if strip > 0 then
    cmd = cmd .. " --strip-components=" .. tostring(strip)
  end
  log.detail(("archive: extracting %s into %s%s"):format(
    path.basename(archive_file), dest,
    strip > 0 and (" (strip " .. strip .. ")") or ""))
  if not path.run(cmd) then
    return nil, ("failed to extract %s"):format(archive_file)
  end
  return entries
end

-- Extract an Arch/Artix package (.pkg.tar.zst / .pkg.tar.xz). These are
-- zstd/xz-compressed tars with two quirks over a plain tar:
--   * Members have NO `./` prefix (usr/bin/..., etc/...), so a requested
--     strip would silently eat the real first component. Strip is disabled
--     unless members are `./`-prefixed (defensive; real packages never are).
--   * .PKGINFO/.MTREE/.BUILDINFO/.INSTALL are package metadata, not owned
--     files; they are excluded so they never reach the staging tree.
-- Ownership is the manifest's job (files whitelist / commit provenance).
function archive.extract_arch_pkg(archive_file, dest, opts)
  opts = opts or {}
  local strip = opts.strip or 0
  if strip > 0 then
    local rf = path.popen(TAR_ENV .. " tar -tf " .. path.quote(archive_file) .. " 2>/dev/null")
    local first = rf and rf:read("*l") or ""
    if rf then rf:close() end
    if first ~= "" and not first:match("^%./") then
      log.detail(("archive: %s has no ./ prefix, disabling strip"):format(
        path.basename(archive_file)))
      strip = 0
    end
  end
  -- Arch packages ship absolute symlinks (e.g. mate-panel help docs).
  -- These are harmless: tar creates them as-is and they resolve at runtime
  -- against the real root. We skip validation and extract directly.
  local listing = log.is_file_silent() and "-xf" or "-xvf"
  local cmd = TAR_ENV .. " tar " .. listing .. " " .. path.quote(archive_file)
    .. " -C " .. path.quote(dest) .. " --no-same-owner"
  for _, glob in ipairs(METADATA_MEMBERS) do
    cmd = cmd .. " --exclude=" .. path.quote(glob)
  end
  if strip > 0 then
    cmd = cmd .. " --strip-components=" .. tostring(strip)
  end
  log.detail(("archive: extracting %s into %s%s"):format(
    path.basename(archive_file), dest,
    strip > 0 and (" (strip " .. strip .. ")") or ""))
  if not path.run(cmd) then
    return nil, ("failed to extract %s"):format(archive_file)
  end
  return {}
end

-- Locate the `data.tar.*` member of an ar (deb) container. ar member layout:
--   magic  "!<arch>\n"
--   header 60 bytes: name (16), mtime (12), owner (6), group (6), mode (8),
--                    size (10), trailer "`\n" (2)
--   data   `size` bytes, then one padding byte when size is odd.
-- Returns { offset, size } of the data member, or nil, err.
local function find_deb_data(deb_file)
  local f = io.open(deb_file, "rb")
  if not f then return nil, ("cannot open %s"):format(deb_file) end
  local magic = f:read(8)
  if magic ~= "!<arch>\n" then
    f:close()
    return nil, ("%s is not a Debian package (bad ar magic)"):format(deb_file)
  end
  local pos = 8
  while true do
    f:seek("set", pos)
    local hdr = f:read(60)
    if not hdr or #hdr < 60 then break end
    local name = hdr:sub(1, 16):gsub("%s+$", ""):gsub("/$", "")
    local size = tonumber(hdr:sub(49, 58)) or 0
    if name:match("^data%.tar") then
      f:close()
      return { offset = pos + 60, size = size }
    end
    pos = pos + 60 + size
    if size % 2 == 1 then pos = pos + 1 end
  end
  f:close()
  return nil, ("no data.tar member found in %s"):format(deb_file)
end

-- Copy `member` bytes out of the deb into `tmp`. Returns true on success.
local function extract_member(deb_file, member, tmp)
  local fi = io.open(deb_file, "rb")
  if not fi then return false end
  fi:seek("set", member.offset)
  local fo = io.open(tmp, "wb")
  if not fo then fi:close() return false end
  local remaining = member.size
  while remaining > 0 do
    local chunk = fi:read(math.min(remaining, 65536))
    if not chunk then break end
    fo:write(chunk)
    remaining = remaining - #chunk
  end
  fo:close()
  fi:close()
  return remaining == 0
end

-- Extract a Debian package. Pulls the `data.tar.*` payload out of the ar
-- container and delegates to archive.extract() for validation + strip, so
-- .debs get exactly the same two-phase safety as plain tars.
-- opts: strip, tmp_dir (where the data.tar temp lands; default config tmp).
function archive.extract_deb(deb_file, dest, opts)
  opts = opts or {}
  local member, err = find_deb_data(deb_file)
  if not member then return nil, err end

  local tmp_dir = opts.tmp_dir or config.get().tmp_dir
  path.mkdir_p(tmp_dir)
  local tmp = path.join(tmp_dir, "zeta-deb-" .. tostring(os.time()) .. "-" .. tostring(math.random(10000, 99999)))

  log.detail(("archive: %s is a .deb, extracting data.tar (%d bytes)"):format(
    path.basename(deb_file), member.size))

  if not extract_member(deb_file, member, tmp) then
    os.remove(tmp)
    return nil, ("failed to read data.tar from %s"):format(deb_file)
  end

  -- Deb-aware strip adjustment: inspect the raw first member of data.tar.
  -- .deb data.tar entries may use ./usr/... (dot-prefixed, strip works)
  -- or usr/... (non-prefixed, strip would eat the real first component).
  local strip = opts.strip or 0
  if strip > 0 then
    local rf = path.popen("tar -tf " .. path.quote(tmp) .. " 2>/dev/null")
    local first = rf and rf:read("*l") or ""
    if rf then rf:close() end
    if first ~= "" and not first:match("^%./") then
      log.detail("archive: data.tar has no ./ prefix, disabling strip")
      strip = 0
    end
  end

  local eopts = { strip = strip, tmp_dir = opts.tmp_dir }
  local entries, xerr = archive.extract(tmp, dest, eopts)
  os.remove(tmp)
  return entries, xerr
end

return archive
